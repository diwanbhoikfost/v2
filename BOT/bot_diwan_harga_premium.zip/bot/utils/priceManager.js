'use strict';

const fs = require('fs');
const path = require('path');

const RULES_PATH = path.join(__dirname, '../data/priceRules.json');
const OLD_PRICES_PATH = path.join(__dirname, '../data/prices.js');

const PROTOCOLS = ['ssh', 'vmess', 'vless', 'trojan', 'udpzivpn'];

function ensureRules() {
  if (!fs.existsSync(RULES_PATH)) {
    const initial = {
      server: {},      // exact by server IP or server name
      category: {},    // keyword category from server name, e.g. biznet/newmedia
      limitIp: {},     // e.g. "1", "2", "4"
      protocol: {},    // ssh/vmess/vless/trojan/udpzivpn
      combo: {},       // protocol + server/category + limit IP
      fallback: { members: {}, reseller: {} }
    };
    try {
      const old = require(OLD_PRICES_PATH);
      initial.fallback.members = old.members || {};
      initial.fallback.reseller = old.reseller || {};
    } catch (_) {}
    fs.writeFileSync(RULES_PATH, JSON.stringify(initial, null, 2));
  }
}

function loadRules() {
  ensureRules();
  try {
    const raw = fs.readFileSync(RULES_PATH, 'utf8');
    const rules = JSON.parse(raw || '{}');
    return {
      server: rules.server || {},
      category: rules.category || {},
      limitIp: rules.limitIp || {},
      protocol: rules.protocol || {},
      combo: rules.combo || {},
      fallback: rules.fallback || { members: {}, reseller: {} }
    };
  } catch (_) {
    return { server: {}, category: {}, limitIp: {}, protocol: {}, combo: {}, fallback: { members: {}, reseller: {} } };
  }
}

function saveRules(rules) {
  const safe = {
    server: rules.server || {},
    category: rules.category || {},
    limitIp: rules.limitIp || {},
    protocol: rules.protocol || {},
    combo: rules.combo || {},
    fallback: rules.fallback || { members: {}, reseller: {} }
  };
  fs.writeFileSync(RULES_PATH, JSON.stringify(safe, null, 2));
}

function normalizeProtocol(p) {
  const x = String(p || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  if (x === 'zivpn' || x === 'udp' || x === 'udpziv') return 'udpzivpn';
  if (x === 'vme') return 'vmess';
  if (x === 'vle') return 'vless';
  if (x === 'tro') return 'trojan';
  return PROTOCOLS.includes(x) ? x : x;
}

function getServerKey(server) {
  if (!server) return '';
  return String(server.ip || server.name || '').trim();
}

function getLegacyPrice(role, protocol) {
  try {
    const old = require(OLD_PRICES_PATH);
    const r = (role === 'reseller' || role === 'admin') ? 'reseller' : 'members';
    return Number(old?.[r]?.[protocol]?.perDay || 0);
  } catch (_) { return 0; }
}

function resolvePrice({ role = 'members', protocol = 'ssh', server = null, limitIp = null } = {}) {
  const rules = loadRules();
  const proto = normalizeProtocol(protocol);
  const serverKey = getServerKey(server);
  const serverIp = String(server?.ip || '').trim();
  const serverName = String(server?.name || '').trim();

  // Prioritas paling spesifik ke paling umum:
  // 1) Combo protocol+server/kategori+limit IP, 2) server exact, 3) kategori nama server, 4) limit IP, 5) protocol, 6) fallback lama.
  const limit = Number(limitIp || server?.limitIp || server?.ipLimit || 0);
  const lowerName = serverName.toLowerCase();
  const comboRules = rules.combo || {};
  const comboTargets = Object.keys(comboRules).map(k => String(k).split('|')[1]).filter(Boolean);
  const comboCandidates = [serverIp, serverKey, serverName, ...comboTargets].filter(Boolean);
  for (const target of comboCandidates) {
    const targetKey = String(target || '').toLowerCase().trim();
    if (!targetKey) continue;
    const matchServer = targetKey === serverIp.toLowerCase() || targetKey === serverKey.toLowerCase() || targetKey === serverName.toLowerCase() || lowerName.includes(targetKey);
    if (!matchServer) continue;
    const directKey = `${proto}|${targetKey}|${limit}`;
    const anyLimitKey = `${proto}|${targetKey}|*`;
    const comboPrice = Number(comboRules[directKey] || comboRules[anyLimitKey] || 0);
    if (comboPrice > 0) return comboPrice;
  }
  const exact = Number(rules.server?.[serverIp] || rules.server?.[serverKey] || rules.server?.[serverName] || 0);
  if (exact > 0) return exact;

  for (const [category, value] of Object.entries(rules.category || {})) {
    const key = String(category || '').toLowerCase().trim();
    if (key && lowerName.includes(key)) {
      const n = Number(value || 0);
      if (n > 0) return n;
    }
  }

  if (limit > 0) {
    const byLimit = Number(rules.limitIp?.[String(limit)] || 0);
    if (byLimit > 0) return byLimit;
  }

  const byProtocol = Number(rules.protocol?.[proto] || 0);
  if (byProtocol > 0) return byProtocol;

  const r = (role === 'reseller' || role === 'admin') ? 'reseller' : 'members';
  const fallback = Number(rules.fallback?.[r]?.[proto]?.perDay || 0);
  return fallback > 0 ? fallback : getLegacyPrice(role, proto);
}

function formatRp(n) {
  return 'Rp ' + Number(n || 0).toLocaleString('id-ID');
}

module.exports = {
  RULES_PATH,
  PROTOCOLS,
  loadRules,
  saveRules,
  resolvePrice,
  normalizeProtocol,
  formatRp
};
