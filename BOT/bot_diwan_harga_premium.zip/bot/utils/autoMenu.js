// utils/autoMenu.js — kirim quick-action menu setelah akun selesai dibuat
'use strict';

function autoMenu(bot, chatId, delayMs = 2000) {
  setTimeout(() => {
    bot.sendMessage(chatId, '📋 <b>Pilih aksi selanjutnya:</b>', {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '📝 Order Akun Baru', callback_data: 'create_menu' }],
          [{ text: '♻️ Trial Akun Baru', callback_data: 'triall_menu' }],
          [{ text: '🔃 Menu Utama',       callback_data: 'menu_back'   }]
        ]
      }
    }).catch(() => {});
  }, delayMs);
}

module.exports = { autoMenu };
