'use strict';

const fs = require('fs');
const path = require('path');
const db = require('../data/db');

const DATA_DIR = path.join(__dirname, '../data');
const LOG_PATH = path.join(DATA_DIR, 'adminLogs.json');
const SERVER_PATH = path.join(DATA_DIR, 'server.js');
const AVARS_PATH = path.join(DATA_DIR, '.avars.json');

function readJsonSafe(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) { return fallback; }
}

function getOwnerId() {
  const av = readJsonSafe(AVARS_PATH, {});
  return av.owner_id ? String(av.owner_id) : '';
}

function loadServers() {
  try {
    const p = require.resolve('../data/server');
    delete require.cache[p];
    return require('../data/server') || [];
  } catch (_) { return []; }
}

function saveServers(servers) {
  fs.writeFileSync(SERVER_PATH, `const servers = ${JSON.stringify(servers, null, 2)};\n\nmodule.exports = servers;`);
  try { delete require.cache[require.resolve('../data/server')]; } catch (_) {}
}

function formatRp(n) { return 'Rp ' + Number(n || 0).toLocaleString('id-ID'); }

function ensureSchema() {
  db.run(`CREATE TABLE IF NOT EXISTS admin_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT,
    chat_id INTEGER,
    message TEXT,
    created_at TEXT
  )`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_admin_logs_created ON admin_logs(created_at)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_admin_logs_type ON admin_logs(type)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_transactions_history ON transactions(chat_id, created_at)`);
}

function logAdmin(type, chatId, message, bot) {
  ensureSchema();
  const cleanType = String(type || 'INFO').slice(0, 40);
  const cleanMessage = String(message || '').slice(0, 1800);
  db.run(
    "INSERT INTO admin_logs (type, chat_id, message, created_at) VALUES (?, ?, ?, datetime('now','localtime'))",
    [cleanType, chatId || 0, cleanMessage]
  );
  const owner = getOwnerId();
  if (bot && owner && String(chatId) !== owner) {
    bot.sendMessage(owner, `📌 <b>LOG ${cleanType}</b>\n👤 <code>${chatId || '-'}</code>\n${cleanMessage}`, { parse_mode: 'HTML' }).catch(() => {});
  }
}

function formatUserHistory(chatId, limit = 10) {
  ensureSchema();
  return new Promise(resolve => {
    db.all(
      `SELECT created_at, product_type, username, amount, status, expired_at, server_ip
       FROM transactions
       WHERE chat_id=?
       ORDER BY id DESC
       LIMIT ?`,
      [chatId, limit],
      (err, rows) => {
        if (err || !rows || !rows.length) {
          return resolve('📜 <b>RIWAYAT TRANSAKSI</b>\n\nBelum ada transaksi.');
        }
        const servers = loadServers();
        let text = '📜 <b>RIWAYAT TRANSAKSI</b>\n';
        text += '╭────────────────────\n';
        rows.forEach((r, i) => {
          const srv = servers.find(s => s.ip === r.server_ip);
          text += `│ ${i + 1}. <b>${r.product_type || '-'}</b> • ${formatRp(r.amount)}\n`;
          text += `│    👤 ${r.username || '-'}\n`;
          text += `│    🖥 ${srv?.name || r.server_ip || '-'}\n`;
          text += `│    📅 ${(r.created_at || '').slice(0, 16)} • ${r.status || '-'}\n`;
          if (r.expired_at) text += `│    ⏰ Exp: ${(r.expired_at || '').slice(0, 10)}\n`;
          if (i !== rows.length - 1) text += '├────────────────────\n';
        });
        text += '╰────────────────────';
        resolve(text);
      }
    );
  });
}

function formatAdminLogs(limit = 15) {
  ensureSchema();
  return new Promise(resolve => {
    db.all(`SELECT type, chat_id, message, created_at FROM admin_logs ORDER BY id DESC LIMIT ?`, [limit], (err, rows) => {
      if (err || !rows || !rows.length) return resolve('📋 <b>LOG ADMIN</b>\n\nBelum ada log.');
      let text = '📋 <b>LOG ADMIN TERBARU</b>\n╭────────────────────\n';
      rows.forEach((r, i) => {
        text += `│ ${i + 1}. <b>${r.type}</b> • ${(r.created_at || '').slice(0, 16)}\n`;
        text += `│ 👤 <code>${r.chat_id || '-'}</code>\n`;
        text += `│ ${String(r.message || '').replace(/\n/g, ' ').slice(0, 110)}\n`;
        if (i !== rows.length - 1) text += '├────────────────────\n';
      });
      text += '╰────────────────────';
      resolve(text);
    });
  });
}

function toggleMaintenance(index) {
  const servers = loadServers();
  const i = Number(index);
  if (!Number.isInteger(i) || i < 0 || i >= servers.length) return null;
  servers[i].maintenance = !servers[i].maintenance;
  saveServers(servers);
  return servers[i];
}

function formatMaintenancePanel() {
  const servers = loadServers();
  if (!servers.length) return { text: '🛠 <b>MAINTENANCE SERVER</b>\n\nBelum ada server.', keyboard: [] };
  let text = '🛠 <b>MAINTENANCE SERVER</b>\n╭────────────────────\n';
  const keyboard = [];
  servers.forEach((s, i) => {
    const isMaint = !!s.maintenance;
    const used = Number(s.used || 0), limit = Number(s.limit || 0);
    text += `│ ${i + 1}. ${isMaint ? '🔴' : '🟢'} <b>${s.name}</b>\n`;
    text += `│    Slot: ${used}/${limit || '∞'} • ${isMaint ? 'MAINTENANCE' : 'AKTIF'}\n`;
    keyboard.push([{ text: `${isMaint ? '🟢 Aktifkan' : '🔴 Maintenance'} ${s.name}`, callback_data: `adm_toggle_maintenance_${i}` }]);
  });
  text += '╰────────────────────';
  return { text, keyboard };
}

function formatSalesReport() {
  ensureSchema();
  return new Promise(resolve => {
    db.get(`SELECT
      COUNT(CASE WHEN status='completed' AND date(created_at)=date('now','localtime') THEN 1 END) AS trx_today,
      COALESCE(SUM(CASE WHEN status='completed' AND date(created_at)=date('now','localtime') THEN amount END),0) AS inc_today,
      COUNT(CASE WHEN status='completed' AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime') THEN 1 END) AS trx_month,
      COALESCE(SUM(CASE WHEN status='completed' AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime') THEN amount END),0) AS inc_month,
      COUNT(CASE WHEN status='completed' THEN 1 END) AS trx_total,
      COALESCE(SUM(CASE WHEN status='completed' THEN amount END),0) AS inc_total
      FROM transactions`, [], (err, r) => {
      if (err || !r) return resolve('📊 <b>LAPORAN PENJUALAN</b>\n\nGagal membaca data.');
      resolve(`📊 <b>LAPORAN PENJUALAN</b>\n╭────────────────────\n│ Hari ini : ${r.trx_today} trx • <b>${formatRp(r.inc_today)}</b>\n│ Bulan ini: ${r.trx_month} trx • <b>${formatRp(r.inc_month)}</b>\n│ Total    : ${r.trx_total} trx • <b>${formatRp(r.inc_total)}</b>\n╰────────────────────`);
    });
  });
}

function startAutoBackup(bot) {
  const owner = getOwnerId();
  if (!owner || !bot) return;
  const dbPath = path.join(DATA_DIR, 'yanbot.db');
  const sendBackup = () => {
    if (!fs.existsSync(dbPath)) return;
    bot.sendDocument(owner, dbPath, { caption: `💾 Auto Backup Database\n📅 ${new Date().toLocaleString('id-ID')}` }).catch(() => {});
  };
  const intervalMs = Number(process.env.AUTO_BACKUP_INTERVAL_MS || 24 * 60 * 60 * 1000);
  setInterval(sendBackup, intervalMs).unref?.();
}

module.exports = {
  ensureSchema,
  logAdmin,
  formatUserHistory,
  formatAdminLogs,
  toggleMaintenance,
  formatMaintenancePanel,
  formatSalesReport,
  startAutoBackup,
  loadServers,
  saveServers
};
