// cmd/create.js - v5.0 — beautiful output card, ISP+Country, no VPS IP
'use strict';

const db      = require('../data/db');
const path    = require('path');
const fs      = require('fs');
const { executeScriptRemote, increaseServerUsage } = require('../services/ssh-exec');
const { generateQRIS } = require('../services/qris');
const { autoMenu }     = require('../utils/autoMenu');
const { friendlyError } = require('../services/error-messages');

/* ─────────────── PRICES CACHE ─────────────── */
const PRICES_PATH = path.join(__dirname, '../data/prices.js');
let _pricesCache  = null;

function getPrices() {
  if (!_pricesCache) {
    try {
      const p = require.resolve(PRICES_PATH);
      delete require.cache[p];
      _pricesCache = require(PRICES_PATH);
    } catch (e) {
      return { reseller: {}, members: {} };
    }
  }
  return _pricesCache;
}

fs.watchFile(PRICES_PATH, { interval: 5000 }, () => { _pricesCache = null; });

/* ─────────────── DEFAULTS ─────────────── */
const DEFAULT_IP    = 1;
const DEFAULT_QUOTA = 1;

/* ─────────────── CONFIG PER TIPE ─────────────── */
const TYPE_CONFIG = {
  ssh: {
    label: 'SSH / OpenVPN',
    steps: ['username', 'password', 'limitip', 'days'],
    scriptName: 'buatSSH',
    priceKey: 'ssh',
    productType: 'SSH'
  },
  vmess: {
    label: 'xRay VMess',
    steps: ['username', 'limitip', 'quota', 'days'],
    scriptName: 'buatVME',
    priceKey: 'vmess',
    productType: 'VMESS'
  },
  vless: {
    label: 'xRay VLess',
    steps: ['username', 'limitip', 'quota', 'days'],
    scriptName: 'buatVLE',
    priceKey: 'vless',
    productType: 'VLESS'
  },
  trojan: {
    label: 'xRay Trojan',
    steps: ['username', 'limitip', 'quota', 'days'],
    scriptName: 'buatTRO',
    priceKey: 'trojan',
    productType: 'TROJAN'
  },
  zivpn: {
    label: 'UDP ZivPN',
    steps: ['password', 'limitip', 'days'],
    scriptName: 'buatZIVPN',
    priceKey: 'udpzivpn',
    productType: 'ZIVPN'
  }
};

/* ─────────────── HELPERS ─────────────── */
function getServerByIp(serverIp) {
  try {
    const sp = require.resolve('../data/server');
    delete require.cache[sp];
    const servers = require('../data/server');
    return servers.find(s => s.ip === serverIp) || null;
  } catch (e) { return null; }
}

function getPrice(role, priceKey, serverIp) {
  const server = getServerByIp(serverIp);
  const serverPrice = Number(server?.pricePerDay || server?.hargaPerHari || 0);
  if (serverPrice > 0) return serverPrice;

  const prices = getPrices();
  const r = (role === 'reseller' || role === 'admin') ? 'reseller' : 'members';
  return prices[r]?.[priceKey]?.perDay || 0;
}

function formatRp(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }

/* IP charge logic:
   admin:    selalu gratis (0 extra)
   reseller: >4 IP → +500/IP
   members:  >1 IP → +500/IP */
function calcExtraIP(role, limitIp) {
  if (role === 'admin') return 0;
  const freeIPs = role === 'reseller' ? 4 : 1;
  return limitIp > freeIPs ? (limitIp - freeIPs) * 500 : 0;
}

/* Bersihkan noise dari output SSH */
function cleanOutput(raw) {
  return (raw || '')
    .split('\n')
    .filter(l => {
      const t = l.trim();
      if (!t) return false;
      if (/TERM environment/i.test(t)) return false;
      if (/tput:/i.test(t))            return false;
      if (/setlocale/i.test(t))        return false;
      if (/cannot change locale/i.test(t)) return false;
      if (/^bash:.*warning:/i.test(t)) return false;
      return true;
    })
    .join('\n')
    .trim();
}

/* Parse RESULT_START…RESULT_END block dari output script */
function parseResult(raw) {
  const r = {};
  const lines = (raw || '').split('\n');
  let inside = false;
  for (const line of lines) {
    const t = line.trim();
    if (t === 'RESULT_START') { inside = true; continue; }
    if (t === 'RESULT_END')   { inside = false; continue; }
    if (!inside) continue;
    const idx = t.indexOf(':');
    if (idx < 1) continue;
    const key = t.slice(0, idx).trim();
    const val = t.slice(idx + 1).trim();
    r[key] = val;
  }
  return r;
}

function hasResultBlock(raw) {
  return /RESULT_START[\s\S]*RESULT_END/.test(raw || '');
}

/* Kartu hasil pembuatan akun — cantik seperti triall */
function buildResultCard(type, r, st, cfg, pricePerDay, sisaSaldo) {
  const em = { ssh: '⚪', vmess: '🔵', vless: '🟡', trojan: '🟠', zivpn: '🟢' }[type] || '🔵';

  let card = `${em} <b>${cfg.label.toUpperCase()} BERHASIL DIBUAT!</b>\n\n`;
  card += `┌─────────────────────┐\n`;

  if (r.USERNAME) card += `│ 🆔 Username : <code>${r.USERNAME}</code>\n`;
  if (r.PASSWORD) card += `│ 🔑 Password : <code>${r.PASSWORD}</code>\n`;
  if (r.UUID)     card += `│ 🔑 UUID     : <code>${r.UUID.substring(0, 18)}...</code>\n`;
  if (r.DOMAIN)   card += `│ 🌐 Domain   : <code>${r.DOMAIN}</code>\n`;
  if (r.ISP)      card += `│ 🏢 ISP      : ${r.ISP}\n`;
  if (r.COUNTRY)  card += `│ 🌍 Country  : ${r.COUNTRY}\n`;

  if (r.PORT_TLS || r.PORT_HTTP || r.PORT_UDP) {
    card += `├─────────────────────┤\n`;
    if (r.PORT_TLS)  card += `│ 🔌 Port TLS : <b>${r.PORT_TLS}</b>\n`;
    if (r.PORT_HTTP) card += `│ 🔌 Port HTTP: <b>${r.PORT_HTTP}</b>\n`;
    if (r.PORT_UDP)  card += `│ 🔌 Port UDP : <b>${r.PORT_UDP}</b>\n`;
  }

  if (r.LIMIT_IP || r.QUOTA !== undefined) {
    card += `├─────────────────────┤\n`;
    if (r.LIMIT_IP) card += `│ 🔢 Limit IP : <b>${r.LIMIT_IP}</b>\n`;
    if (r.QUOTA !== undefined) {
      card += `│ 💾 Quota    : <b>${r.QUOTA === '0' ? 'Unlimited' : r.QUOTA + ' GB'}</b>\n`;
    }
  }

  card += `├─────────────────────┤\n`;
  card += `│ 📅 Aktif    : <b>${st.data.days} hari</b>\n`;
  if (r.EXPIRED) card += `│ ⏰ Expired  : <b>${r.EXPIRED}</b>\n`;

  card += `├─────────────────────┤\n`;
  if (st.role === 'admin') {
    card += `│ 👑 Dibuat Admin — GRATIS\n`;
  } else {
    card += `│ 💰 ${formatRp(pricePerDay)}/hari × ${st.data.days} hari\n`;
    if (st.extraIPCharge > 0) card += `│ ➕ Extra IP  : +${formatRp(st.extraIPCharge)}\n`;
    card += `│ 🧮 Total    : <b>${formatRp(st.totalHarga)}</b>\n`;
    card += `│ 💳 Saldo    : <b>${formatRp(sisaSaldo)}</b>\n`;
  }
  card += `└─────────────────────┘`;

  if (type === 'ssh' && r.DOMAIN) {
    const domain = r.DOMAIN;
    const payload = `GET / HTTP/1.1[crlf]Host: ${domain}[crlf][crlf]PATCH / HTTP/1.4[crlf]Host: ${domain}[crlf]Upgrade: websocket[crlf][crlf][split]HTTP/ 69[crlf][crlf]`;
    card += `\n\n📦 <b>PAYLOAD SSH</b> <i>(tap untuk copy)</i>\n<code>${payload}</code>`;
  }

  if (r.TLS_LINK || r.WS_LINK || r.GRPC_LINK || r.XHTTP_LINK) {
    card += `\n\n🔗 <b>LINK KONEKSI</b> <i>(tap untuk copy)</i>`;
    if (r.TLS_LINK)   card += `\n\n<b>[TLS]</b>\n<code>${r.TLS_LINK}</code>`;
    if (r.WS_LINK)    card += `\n\n<b>[WS]</b>\n<code>${r.WS_LINK}</code>`;
    if (r.GRPC_LINK)  card += `\n\n<b>[gRPC]</b>\n<code>${r.GRPC_LINK}</code>`;
    if (r.XHTTP_LINK) card += `\n\n<b>[XHTTP]</b>\n<code>${r.XHTTP_LINK}</code>`;
  }

  return card;
}

const STEP_LABEL = {
  username: '🆔 Username',
  password: '🔑 Password',
  limitip:  '🔢 Limit IP',
  quota:    '💾 Quota (GB)',
  days:     '📅 Masa Aktif'
};

function getStepHint(step, role) {
  const maxIP    = role === 'reseller' ? 4 : 1;
  const ipFree   = role === 'reseller' ? '4 IP gratis, lebih: +Rp 500/IP' : '1 gratis, lebih: +Rp 500/IP';
  const ipAdmin  = 'bebas, tanpa biaya tambahan';
  return {
    username: `min 3 karakter, contoh: user123`,
    password: `min 3 karakter, contoh: pass123`,
    limitip:  role === 'admin'
      ? `Limit IP (${ipAdmin})`
      : `default ${DEFAULT_IP}  (${ipFree})`,
    quota:    `dalam GB, default ${DEFAULT_QUOTA}  (0 = unlimited)`,
    days:     `contoh: 30`
  }[step] || '';
}

function buildCard(type, step, data, role, totalEstimate) {
  const cfg         = TYPE_CONFIG[type];
  const pricePerDay = getPrice(role, cfg.priceKey, data?.serverIp);

  let filled = '';
  if (data.username !== undefined) filled += `\n│  🆔 Username : ${data.username}`;
  if (data.password !== undefined) filled += `\n│  🔑 Password : ${data.password}`;
  if (data.limitIp  !== undefined) filled += `\n│  🔢 Limit IP : ${data.limitIp}`;
  if (data.quota    !== undefined) filled += `\n│  💾 Quota    : ${data.quota === 0 ? 'Unlimited' : data.quota + ' GB'}`;
  if (data.days     !== undefined) filled += `\n│  📅 Hari     : ${data.days} hari`;

  const priceShow = role === 'admin' ? `\n│  💰 Harga    : GRATIS (Admin)` : `\n│  💰 Harga    : ${formatRp(pricePerDay)}/hari`;
  const totalShow = (totalEstimate !== undefined && role !== 'admin') ? `\n│  🧮 Total    : ${formatRp(totalEstimate)}` : '';

  const hint   = step ? getStepHint(step, role) : '';
  const prompt = step ? `\n│\n│  ▶ ${STEP_LABEL[step]}\n│    ${hint}` : '';

  return (
    `┌───────────────┐\n` +
    `│  🔰 ORDER ${cfg.label.toUpperCase()}\n` +
    `│  👑 Role   : ${role.toUpperCase()}\n` +
    `│  🖥 Server : ${data.serverIp || '-'}\n` +
    `└───────────────┘` +
    filled + priceShow + totalShow + prompt +
    `\n└───────────────┘`
  );
}

function buildConfirmCard(type, data, role, totalHarga, pricePerDay, extraIPCharge, saldo, serverName) {
  const cfg = TYPE_CONFIG[type];

  const salLabel = role === 'admin'
    ? `👑 Admin — Akun dibuat GRATIS!`
    : saldo >= totalHarga
      ? `✅ Saldo cukup`
      : `⚠️ Kurang ${formatRp(totalHarga - saldo)} → bayar via QRIS`;

  let detail = '';
  if (data.username) detail += `│  👤 Username : ${data.username}\n`;
  if (data.password) detail += `│  🔑 Password : ${data.password}\n`;
  if (data.limitIp)  detail += `│  🔢 Limit IP : ${data.limitIp}\n`;
  if (data.quota !== undefined) detail += `│  💾 Quota    : ${data.quota === 0 ? 'Unlimited' : data.quota + ' GB'}\n`;
  detail += `│  📅 Durasi   : ${data.days} hari\n`;

  let hargaDetail = '';
  if (role === 'admin') {
    hargaDetail = `│  💰 TOTAL    : GRATIS (Admin)\n`;
  } else {
    hargaDetail = `│  💰 ${formatRp(pricePerDay)}/hari × ${data.days} hari\n`;
    if (extraIPCharge > 0) hargaDetail += `│  ➕ Extra IP  : +${formatRp(extraIPCharge)}\n`;
    hargaDetail += `│  🧮 TOTAL    : ${formatRp(totalHarga)}\n`;
  }

  return (
    `┌──────────────┐\n` +
    `│   🀄 KONFIRMASI ORDER 🀄\n` +
    `├──────────────┤\n` +
    `│  Protocol : ${cfg.label}\n` +
    `│  Server   : ${serverName}\n` +
    `│  Role     : ${role.toUpperCase()}\n` +
    `├──────────────┤\n` +
    detail +
    `├──────────────┤\n` +
    hargaDetail +
    `│  ${salLabel}\n` +
    `└──────────────┘\n\n` +
    `Lanjutkan order ini?`
  );
}

/* ─────────────── INIT CREATE ─────────────── */
function initCreate(bot, chatId, userStates, type, menuMsgId) {
  const stateData = userStates.get(chatId);
  const serverIp  = stateData?.serverIp;
  if (!serverIp) return bot.sendMessage(chatId, '❌ Server belum dipilih.');

  const servers = require('../data/server');
  const server  = servers.find(s => s.ip === serverIp);
  if (!server)  return bot.sendMessage(chatId, '❌ Server tidak ditemukan.');

  server.used  = server.used  || 0;
  server.limit = server.limit || 999;
  if (server.used >= server.limit) return bot.sendMessage(chatId, '❌ Server penuh, pilih server lain.');

  if (menuMsgId) bot.deleteMessage(chatId, menuMsgId).catch(() => {});

  db.get('SELECT saldo, role FROM users WHERE chat_id=?', [chatId], async (err, row) => {
    if (!row) return bot.sendMessage(chatId, '❌ User tidak ditemukan. Ketik /start');

    const role      = row.role  || 'members';
    const saldo     = Number(row.saldo) || 0;
    const cfg       = TYPE_CONFIG[type];
    const firstStep = cfg.steps[0];

    const text = buildCard(type, firstStep, { serverIp }, role, undefined);
    const msg  = await bot.sendMessage(chatId, text).catch(() => null);
    if (!msg) return;

    userStates.set(chatId, {
      state:     'create_flow',
      type,
      serverIp,
      msgId:     msg.message_id,
      role,
      saldo,
      data:      { serverIp },
      stepIndex: 0
    });
  });
}

/* ─────────────── HANDLE STEP ─────────────── */
async function handleStep(bot, chatId, text, userStates) {
  const st = userStates.get(chatId);
  if (!st || st.state !== 'create_flow') return;

  const cfg = TYPE_CONFIG[st.type];
  if (!cfg) {
    userStates.delete(chatId);
    return bot.sendMessage(chatId, '❌ Sesi error. Ketik /menu untuk mulai ulang.');
  }

  /* INSTANT FEEDBACK */
  const loadEmoji = st.stepIndex % 2 === 0 ? '⌛' : '⏳';
  await bot.editMessageText(`${loadEmoji} <i>Memproses input...</i>`, {
    chat_id: chatId, message_id: st.msgId, parse_mode: 'HTML'
  }).catch(() => {});

  const currentStep = cfg.steps[st.stepIndex];
  let errMsg = null;

  if (currentStep === 'username' || currentStep === 'password') {
    const clean = (text || '').trim();
    if (clean.length < 5) {
      errMsg = '⚠️ Minimal 5 karakter.';
    } else {
      if (currentStep === 'username') st.data.username = clean.toLowerCase().replace(/[^a-z0-9_]/g, '');
      else                            st.data.password = clean;
    }
  } else if (currentStep === 'limitip') {
    const raw = (text || '').trim();
    if (raw === '' || raw === '0') {
      st.data.limitIp = DEFAULT_IP;
    } else {
      const n = parseInt(raw);
      if (isNaN(n) || n < 1) errMsg = `⚠️ Limit ip invalid (${DEFAULT_IP}).`;
      else st.data.limitIp = n;
    }
  } else if (currentStep === 'quota') {
    const raw = (text || '').trim();
    if (raw === '') {
      st.data.quota = DEFAULT_QUOTA;
    } else {
      const n = parseInt(raw);
      if (isNaN(n) || n < 0) errMsg = `⚠️ Harus Berupa Anggka (${DEFAULT_QUOTA} GB).`;
      else st.data.quota = n;
    }
  } else if (currentStep === 'days') {
    const n = parseInt(text);
    if (isNaN(n) || n < 1) errMsg = '⚠️ Masa aktif, berupa angka, minimal 1';
    else st.data.days = n;
  }

  if (errMsg) {
    return bot.editMessageText(
      buildCard(st.type, currentStep, st.data, st.role) + `\n\n${errMsg}`,
      { chat_id: chatId, message_id: st.msgId }
    ).catch(() => {});
  }

  st.stepIndex++;
  userStates.set(chatId, st);

  if (st.stepIndex < cfg.steps.length) {
    const nextStep = cfg.steps[st.stepIndex];
    return bot.editMessageText(
      buildCard(st.type, nextStep, st.data, st.role),
      { chat_id: chatId, message_id: st.msgId }
    ).catch(() => {});
  }

  await showConfirmCreate(bot, chatId, userStates, st, cfg);
}

/* ─────────────── KONFIRMASI ─────────────── */
async function showConfirmCreate(bot, chatId, userStates, st, cfg) {
  const pricePerDay   = getPrice(st.role, cfg.priceKey, st.serverIp);
  const extraIPCharge = calcExtraIP(st.role, st.data.limitIp || DEFAULT_IP);
  const totalHarga    = st.role === 'admin' ? 0 : pricePerDay * st.data.days + extraIPCharge;

  const servers    = require('../data/server');
  const server     = servers.find(s => s.ip === st.serverIp);
  const serverName = server?.name || st.serverIp;

  const confirmText = buildConfirmCard(
    st.type, st.data, st.role, totalHarga, pricePerDay, extraIPCharge, st.saldo, serverName
  );

  st.state         = 'create_confirm';
  st.totalHarga    = totalHarga;
  st.pricePerDay   = pricePerDay;
  st.extraIPCharge = extraIPCharge;
  userStates.set(chatId, st);

  const opts = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Konfirmasi', callback_data: 'confirm_order' },
          { text: '❌ Batalkan',      callback_data: 'cancel_order'  }
        ]
      ]
    }
  };

  bot.editMessageText(confirmText, { chat_id: chatId, message_id: st.msgId, ...opts })
    .catch(() => bot.sendMessage(chatId, confirmText, opts));
}

/* ─────────────── EKSEKUSI CREATE ─────────────── */
async function executeCreate(bot, chatId, userStates, st) {
  userStates.delete(chatId);

  const cfg        = TYPE_CONFIG[st.type];
  const totalHarga = st.totalHarga;

  /* Admin atau saldo cukup → langsung buat */
  if (st.role === 'admin' || st.saldo >= totalHarga) {
    doCreateAccount(bot, chatId, st, cfg, totalHarga, st.pricePerDay, st.msgId);
  } else {
    bot.editMessageText('⌛ Low balance, create QRIS... ', { chat_id: chatId, message_id: st.msgId }).catch(() => {});
    await generateQRIS(bot, chatId, totalHarga, {
      productName:   `ORDER ${cfg.label}`,
      productType:   cfg.productType,
      accountCreate: {
        type: st.type, serverIp: st.serverIp, data: st.data,
        scriptName: cfg.scriptName, productType: cfg.productType,
        label: cfg.label, role: st.role, totalHarga, pricePerDay: st.pricePerDay
      }
    });
  }
}

/* ─────────────── PROGRESS ANIMATION ─────────────── */
function buildProgress(pct, label) {
  const total  = 10;
  const filled = Math.round(pct / 10);
  const bar    = '▰'.repeat(filled) + '▱'.repeat(total - filled);
  return `${label}\n<code>${bar}</code>  <b>${pct}%</b>`;
}

/* ─────────────── BUAT AKUN ─────────────── */
async function doCreateAccount(bot, chatId, st, cfg, totalHarga, pricePerDay, msgId) {
  await bot.editMessageText(
    buildProgress(0, '⏳ <b>Connecting to server... </b>'),
    { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
  ).catch(() => {});

  let animStep = 1;
  const FRAMES = [
    { pct: 30, label: `🔄 <b>Create an account  ${cfg.label}...</b>` },
    { pct: 60, label: '⚙️ <b>Configuring the protocol... </b>'   },
    { pct: 70, label: '📝 <b>Saving configuration... </b>'     }
  ];

  const animInterval = setInterval(() => {
    if (animStep - 1 < FRAMES.length) {
      const f = FRAMES[animStep - 1];
      bot.editMessageText(buildProgress(f.pct, f.label), {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML'
      }).catch(() => {});
      animStep++;
    }
  }, 2500);

  const limitIp = st.data.limitIp ?? DEFAULT_IP;
  const quota   = st.data.quota   ?? DEFAULT_QUOTA;

  let args = [];
  if (st.type === 'ssh') {
    args = [st.data.username, st.data.password, limitIp, st.data.days];
  } else if (['vmess', 'vless', 'trojan'].includes(st.type)) {
    args = [st.data.username, st.data.days, quota, limitIp];
  } else if (st.type === 'zivpn') {
    args = [st.data.password, st.data.days, limitIp];
  }

  executeScriptRemote(st.serverIp, cfg.scriptName, args, (err, rawOutput) => {
    clearInterval(animInterval);
    const output = cleanOutput(rawOutput);

    if (err) {
      console.error('[doCreateAccount] ❌', err.message);
      const friendly = friendlyError(err.message) || err.message;
      return bot.editMessageText(
        `❌ <b>Gagal membuat akun</b>\n\n${friendly}\n\nSaldo tidak terpotong. Coba lagi.`,
        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
      ).catch(() => bot.sendMessage(chatId, '❌ Gagal: ' + friendly));
    }

    if (!hasResultBlock(output)) {
      const friendly = friendlyError(output);
      const errText = `❌ <b>${cfg.label.toUpperCase()} GAGAL DIBUAT</b>\n\n${friendly || output || 'Output script kosong'}\n\nSaldo tidak terpotong. Hubungi admin untuk tindak lanjut.`;
      if (msgId) bot.editMessageText(errText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }).catch(() => bot.sendMessage(chatId, errText, { parse_mode: 'HTML' }));
      else bot.sendMessage(chatId, errText, { parse_mode: 'HTML' });
      return;
    }

    if (totalHarga > 0) {
      db.run('UPDATE users SET saldo = saldo - ? WHERE chat_id=?', [totalHarga, chatId]);
    }

    const expiredAt = new Date(Date.now() + st.data.days * 86400000)
      .toISOString().slice(0, 19).replace('T', ' ');
    const username = st.data.username || st.data.password || '-';

    db.run(
      "INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type, username, expired_at, server_ip) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), ?, ?, ?, ?)",
      [chatId, `${cfg.productType}-${Date.now()}`, totalHarga, cfg.productType, username, expiredAt, st.serverIp]
    );

    increaseServerUsage(st.serverIp);

    db.get('SELECT saldo FROM users WHERE chat_id=?', [chatId], (err2, row) => {
      const sisaSaldo = row?.saldo || 0;

      const parsed     = parseResult(output);
      const hasResult  = Object.keys(parsed).length > 0;
      const detailText = hasResult
        ? buildResultCard(st.type, parsed, st, cfg, pricePerDay, sisaSaldo)
        : `✅ <b>${cfg.label.toUpperCase()} BERHASIL DIBUAT!</b>\n\n` +
          (output ? `<pre>${output}</pre>\n\n` : '') +
          (st.role !== 'admin'
            ? `💰 Harga/Hari  : ${formatRp(pricePerDay)}\n📅 Masa Aktif  : ${st.data.days} hari\n🧮 Total       : ${formatRp(totalHarga)}\n💳 Sisa Saldo  : ${formatRp(sisaSaldo)}\n\n`
            : `📅 Masa Aktif  : ${st.data.days} hari\n👑 Dibuat oleh Admin (Gratis)\n\n`);

      bot.editMessageText(
        buildProgress(100, `✅ <b>${cfg.label.toUpperCase()} BERHASIL!</b>`),
        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
      ).catch(() => {}).finally(() => {
        setTimeout(() => {
          bot.editMessageText(detailText, {
            chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] }
          }).catch(() => bot.sendMessage(chatId, detailText, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] }
          }));

          autoMenu(bot, chatId, 1500);
        }, 800);
      });
    });
  });
}

module.exports = {
  createSSH:    (bot, chatId, userStates, msgId) => initCreate(bot, chatId, userStates, 'ssh',    msgId),
  createVMess:  (bot, chatId, userStates, msgId) => initCreate(bot, chatId, userStates, 'vmess',  msgId),
  createVLess:  (bot, chatId, userStates, msgId) => initCreate(bot, chatId, userStates, 'vless',  msgId),
  createTrojan: (bot, chatId, userStates, msgId) => initCreate(bot, chatId, userStates, 'trojan', msgId),
  createZivpn:  (bot, chatId, userStates, msgId) => initCreate(bot, chatId, userStates, 'zivpn',  msgId),
  handleStep,
  executeCreate,
  TYPE_CONFIG,
  buildProgress
};
