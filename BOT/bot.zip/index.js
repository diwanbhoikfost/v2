
// Diwan Tunneling Bot - Full Final Features + Backup/Restore JSON
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
global.db = { users: {}, products: {}, servers: {}, pricing: { member: {}, seller: {} } };

const token = 'YOUR_BOT_TOKEN_HERE';
const bot = new TelegramBot(token, { polling: true });

bot.on('message', (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text || '';
    const args = text.split(' ').slice(1);
    const command = text.split(' ')[0].replace('/', '');
    const isAdmin = chatId === 7589800618;
    const isMember = !!global.db.users[chatId];

    switch(command) {
        case 'start':
            bot.sendMessage(chatId, 'Selamat datang di Diwan Tunneling!');
            break;

        case 'perpanjang':
            if(!isAdmin && !isMember) return bot.sendMessage(chatId, 'Kamu belum terdaftar.');
            const targetUser = args[0];
            const tambahHari = parseInt(args[1]) || 1;
            const akun = global.db.users[targetUser];
            if(!akun) return bot.sendMessage(chatId, 'Akun tidak ditemukan.');
            const now = new Date();
            const expiredDate = new Date(akun.expired || now);
            expiredDate.setDate(expiredDate.getDate() + tambahHari);
            akun.expired = expiredDate.toISOString();
            bot.sendMessage(chatId, `✅ Akun ${akun.username || targetUser} berhasil diperpanjang ${tambahHari} hari.`);
            break;

        case 'seller':
            const user = global.db.users[chatId];
            if(!user) return bot.sendMessage(chatId, 'User tidak ditemukan.');
            if(user.saldo>=30000 && !user.isSeller) user.isSeller=true;
            bot.sendMessage(chatId,'🎉 Menu Seller aktif.');
            break;

        case 'setharga':
            if(!isAdmin) return bot.sendMessage(chatId,'Khusus admin.');
            const tipe=args[0], protokol=args[1], harga=parseInt(args[2]);
            if(!['member','seller'].includes(tipe)) return bot.sendMessage(chatId,'Tipe harus member/seller');
            if(!['zivpn','vmess','vless','trojan'].includes(protokol)) return bot.sendMessage(chatId,'Protokol salah');
            global.db.pricing[tipe][protokol]=harga;
            bot.sendMessage(chatId, `✅ Harga ${protokol} untuk ${tipe} diatur Rp${harga}`);
            break;

        case 'cekserver':
            const serverId=args[0];
            const server=global.db.servers[serverId];
            if(!server) return bot.sendMessage(chatId,'Server tidak ditemukan');
            bot.sendMessage(chatId, `📡 Server ${serverId} Status Online`);
            break;

        case 'topproduk':
            const produk=Object.entries(global.db.products).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5);
            let teks='📈 Top Produk Terlaris\n';
            produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`;});
            bot.sendMessage(chatId, teks);
            break;

        case 'addserver':
            if(!isAdmin) return bot.sendMessage(chatId,'Khusus admin');
            const newServerId=args[0], slotInput=parseInt(args[1])||0;
            if(!global.db.servers[newServerId]) global.db.servers[newServerId]={slot:0,users:[]};
            const serverObj=global.db.servers[newServerId];
            const currentUsers=Object.values(global.db.users).filter(u=>u.server===newServerId);
            serverObj.slot=Math.max(slotInput,currentUsers.length);
            serverObj.users=currentUsers.map(u=>u.username);
            bot.sendMessage(chatId,`✅ Server ${newServerId} ditambahkan dengan slot ${serverObj.slot}`);
            break;

        case 'backup':
            if(!isAdmin) return bot.sendMessage(chatId,'Khusus admin');
            const backupDir='./data/backup';
            if(!fs.existsSync(backupDir)) fs.mkdirSync(backupDir,{recursive:true});
            const backupFile=`${backupDir}/backup-${Date.now()}.json`;
            fs.writeFileSync(backupFile, JSON.stringify(global.db,null,2));
            bot.sendMessage(chatId, `✅ Backup berhasil: ${backupFile}`);
            break;

        case 'restore':
            if(!isAdmin) return bot.sendMessage(chatId,'Khusus admin');
            const restoreFile=args[0];
            if(!restoreFile) return bot.sendMessage(chatId,'Masukkan nama file backup.');
            const restorePath=`./data/backup/${restoreFile}`;
            if(!fs.existsSync(restorePath)) return bot.sendMessage(chatId,'File backup tidak ditemukan');
            global.db=JSON.parse(fs.readFileSync(restorePath));
            bot.sendMessage(chatId, `✅ Restore berhasil dari ${restoreFile}`);
            break;

        default:
            bot.sendMessage(chatId,'Command tidak dikenali');
            break;
    }
});

// Anti Multi Login
function checkMultiLogin(userId, ip) {
    const akun=global.db.users[userId];
    if(!akun) return false;
    if(!akun.ipList) akun.ipList=[];
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip);
    if(akun.ipList.length>1) bot.sendMessage(userId, `⚠️ Multi Login terdeteksi: ${akun.ipList.join(', ')}`);
    return akun.ipList.length>1;
}
