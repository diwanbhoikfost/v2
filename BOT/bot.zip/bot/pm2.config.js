// pm2.config.js — Konfigurasi PM2 untuk production
// Cara pakai:
//   pm2 start pm2.config.js
//   pm2 save
//   pm2 startup

module.exports = {
  apps: [
    {
      name: 'diwan-tunneling-bot',
      script: 'index.js',
      cwd: __dirname,

      // Restart otomatis jika crash
      autorestart: true,
      watch: false,

      // Restart jika memory > 400MB (mencegah memory leak)
      max_memory_restart: '400M',

      // Delay restart 3 detik jika crash berulang
      restart_delay: 3000,

      // Jangan restart lebih dari 10x dalam 1 menit
      max_restarts: 10,
      min_uptime: '10s',

      // Log
      out_file: './logs/out.log',
      error_file: './logs/error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      merge_logs: true,

      // Environment production
      env: {
        NODE_ENV: 'production'
      }
    }
  ]
};
