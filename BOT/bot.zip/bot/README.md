# ⚡ Diwan Tunneling Bot

Bot Telegram auto order VPN (SSH, VMess, VLess, Trojan, UDP ZivPN) dengan sistem pembayaran QRIS otomatis.

---

## 🚀 Fitur

- ✅ **Auto create akun** SSH, xRay VMess, VLess, Trojan, UDP ZivPN
- ✅ **Bayar QRIS otomatis** via Pakasir — akun langsung dibuat setelah bayar
- ✅ **Trial gratis 30 menit** (1x per 24 jam untuk members)
- ✅ **Extend / renew akun** via saldo atau QRIS
- ✅ **Sistem Reseller** — harga lebih murah, upgrade otomatis setelah top up ≥ Rp 30.000
- ✅ **Voucher saldo** — admin bisa generate kode diskon
- ✅ **Promo top up** — admin bisa aktifkan bonus persentase
- ✅ **Auto-delete akun expired** — hapus otomatis dari VPS setiap 6 jam
- ✅ **Notif expired** — peringatan H-3 dan H-1 sebelum akun habis
- ✅ **Server health check** — notif admin otomatis jika server down/up
- ✅ **Laporan harian** ke admin (income + jumlah transaksi)
- ✅ **Admin panel lengkap** — broadcast, kelola server, backup DB, set harga, dll
- ✅ **Sync scripts ke VPS** — upload shell script ke semua VPS via API
- ✅ **Remote install API** — install VPS API server otomatis dari bot

---

## 📋 Prasyarat

- Node.js v18+
- PM2 (untuk production): `npm install -g pm2`
- Akun [Pakasir](https://app.pakasir.com) untuk QRIS
- VPS dengan script VPN (SSH/Xray/ZivPN) sudah terinstall

---

## ⚙️ Setup

### 1. Clone & install

```bash
git clone https://github.com/username/repo.git
cd bot
npm install
```

### 2. Buat file konfigurasi

Buat file `data/.avars.json`:

```json
{
  "token": "BOT_TOKEN_DARI_BOTFATHER",
  "owner_id": 123456789,
  "bot_name": "DIWAN TUNNELING",
  "pakasir_slug": "nama-project-pakasir",
  "pakasir_api_key": "api-key-dari-pakasir"
}
```

| Key | Keterangan |
|-----|-----------|
| `token` | Token bot dari [@BotFather](https://t.me/BotFather) |
| `owner_id` | Telegram ID kamu (cek via [@userinfobot](https://t.me/userinfobot)) |
| `bot_name` | Nama bot (tampil di log) |
| `pakasir_slug` | Slug project Pakasir (di dashboard Pakasir) |
| `pakasir_api_key` | API key dari dashboard Pakasir |

### 3. Tambah server VPS

Buat file `data/server.js`:

```js
const servers = [
  {
    name: "SG Premium",
    ip: "103.x.x.x",
    country: "Singapore",
    location: "Singapore",
    limit: 90,
    used: 0,
    apiUrl: "http://103.x.x.x:3456",
    apiToken: "token-rahasia-kamu"
  }
];

module.exports = servers;
```

> 💡 Atau tambah server via `/admin` → **Add Server** langsung dari bot (auto-install API).

### 4. Jalankan bot

**Development:**
```bash
node index.js
```

**Production (dengan PM2):**
```bash
pm2 start pm2.config.js
pm2 save
pm2 startup
```

---

## 📁 Struktur File

```
bot/
├── index.js              # Entry point
├── handler.js            # Main message & callback handler
├── pm2.config.js         # Konfigurasi PM2
├── cmd/
│   ├── admin.js          # Panel admin
│   ├── create.js         # Buat akun VPN
│   ├── renew.js          # Extend akun
│   ├── triall.js         # Trial gratis
│   ├── myaccount.js      # Info akun user
│   ├── trx.js            # Riwayat transaksi
│   ├── cekstatus.js      # Status akun
│   └── menu_deposit.js   # Menu top up
├── data/
│   ├── db.js             # Database SQLite (sql.js)
│   ├── prices.js         # Harga per protokol
│   ├── promo.json        # Status & setting promo
│   ├── server.js         # Daftar server VPS (buat manual)
│   └── .avars.json       # Config sensitif (JANGAN push ke GitHub!)
├── services/
│   ├── paymentChecker.js # Cek status QRIS otomatis
│   ├── qris.js           # Generate QR code QRIS
│   ├── expiredNotif.js   # Notif akun mau expired
│   ├── autoDelete.js     # Hapus akun expired dari VPS
│   ├── serverHealthCheck.js # Monitor server up/down
│   ├── report.js         # Laporan harian ke admin
│   ├── promo.js          # Manajemen promo
│   ├── voucher.js        # Generate & claim voucher
│   ├── ssh-exec.js       # Eksekusi script di VPS (API + SSH fallback)
│   ├── sync-scripts.js   # Sync shell script ke semua VPS
│   └── remote-install.js # Install VPS API server via SSH
├── shell_script/         # Shell scripts untuk manajemen akun VPN
└── utils/
    ├── autoMenu.js       # Auto-send menu setelah transaksi
    └── helpers.js        # Shared helper functions
```

---

## 🔧 Perintah Admin

| Perintah | Fungsi |
|---------|--------|
| `/admin` | Buka panel admin |
| `/cancel` | Batalkan proses aktif |

**Via panel admin:**
- 📢 Broadcast pesan ke semua user
- 📌 Tambah server VPS baru
- 👑 Set reseller / tambah saldo user
- 💾 Backup & restore database
- 🔥 Aktifkan/matikan promo
- 🎟 Generate voucher saldo
- 💲 Set harga VPN per protokol
- 🔄 Sync scripts ke semua VPS
- 📊 Statistik per server

---

## 🔐 Keamanan

- File `data/.avars.json` dan database `data/*.db` sudah di-ignore via `.gitignore`
- Jangan pernah push credential ke GitHub
- Gunakan `pm2` dengan user non-root jika memungkinkan
- Ganti `apiToken` VPS secara berkala

---

## 📞 Kontak

- Telegram: [@diwanvpn](https://t.me/diwanvpn)
- WhatsApp: [+6281312868913](https://wa.me/6281312868913)
