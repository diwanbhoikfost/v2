// services/referral.js — Sistem Referral
// User dapat kode unik, bagikan ke teman.
// Jika teman top up pertama kali pakai kode ini → referrer dapat bonus 10%
'use strict';

const db   = require('../data/db');
const crypto = require('crypto');

const BONUS_PCT   = 10;   // bonus referral 10% dari nilai top up
const MIN_TOPUP   = 5000; // minimum top up agar referral bonus aktif

/* ══════════════════════════════════════════
   INIT TABLE
══════════════════════════════════════════ */
function initReferralTables() {
  db.run(`CREATE TABLE IF NOT EXISTS referral_codes (
    chat_id  INTEGER PRIMARY KEY,
    code     TEXT UNIQUE NOT NULL,
    total_used    INTEGER DEFAULT 0,
    total_earned  INTEGER DEFAULT 0,
    created_at    TEXT
  )`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_ref_code ON referral_codes(code)`);

  db.run(`CREATE TABLE IF NOT EXISTS referral_uses (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    referrer_id INTEGER NOT NULL,
    user_id     INTEGER UNIQUE NOT NULL,
    bonus_amount INTEGER DEFAULT 0,
    created_at  TEXT
  )`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_ref_user ON referral_uses(user_id)`);
}

/* ══════════════════════════════════════════
   GENERATE / GET KODE
══════════════════════════════════════════ */
function generateCode(chatId, callback) {
  /* Cek apakah sudah punya kode */
  db.get('SELECT code FROM referral_codes WHERE chat_id=?', [chatId], (err, row) => {
    if (row) return callback(null, row.code);

    /* Generate kode unik 6 char */
    const code = 'REF_' + crypto.randomBytes(3).toString('hex').toUpperCase();
    db.run(
      "INSERT OR IGNORE INTO referral_codes (chat_id, code, total_used, total_earned, created_at) VALUES (?, ?, 0, 0, datetime('now','localtime'))",
      [chatId, code],
      (err2) => {
        if (err2) {
          /* Collision — retry */
          return generateCode(chatId, callback);
        }
        callback(null, code);
      }
    );
  });
}

/* ══════════════════════════════════════════
   CLAIM REFERRAL
══════════════════════════════════════════ */
function claimReferral(userId, code, callback) {
  /* callback(err, result) — result: 'ok' | 'already_claimed' | 'own_code' | 'invalid' | 'has_topup' */

  /* Pastikan user belum pernah claim referral */
  db.get('SELECT id FROM referral_uses WHERE user_id=?', [userId], (err, use) => {
    if (use) return callback(null, 'already_claimed');

    /* Pastikan user belum pernah top up (referral hanya untuk user baru) */
    db.get(
      "SELECT COUNT(*) as cnt FROM transactions WHERE chat_id=? AND status='completed' AND (product_type='TOPUP' OR order_id GLOB '[0-9]*')",
      [userId],
      (err2, row) => {
        if ((row?.cnt || 0) > 0) return callback(null, 'has_topup');

        /* Cari referrer by code */
        db.get('SELECT chat_id FROM referral_codes WHERE code=?', [code.toUpperCase()], (err3, ref) => {
          if (!ref) return callback(null, 'invalid');
          if (String(ref.chat_id) === String(userId)) return callback(null, 'own_code');

          /* Simpan pending claim */
          db.run(
            "INSERT OR IGNORE INTO referral_uses (referrer_id, user_id, bonus_amount, created_at) VALUES (?, ?, 0, datetime('now','localtime'))",
            [ref.chat_id, userId],
            (err4) => callback(err4 || null, err4 ? 'error' : 'ok')
          );
        });
      }
    );
  });
}

/* ══════════════════════════════════════════
   PROSES BONUS (dipanggil saat top up berhasil)
══════════════════════════════════════════ */
function processReferralBonus(bot, userId, topupAmount, callback) {
  if (topupAmount < MIN_TOPUP) return callback && callback();

  /* Cek apakah ini top up PERTAMA user ini */
  db.get(
    "SELECT COUNT(*) as cnt FROM transactions WHERE chat_id=? AND status='completed' AND (product_type='TOPUP' OR order_id GLOB '[0-9]*')",
    [userId],
    (err, row) => {
      /* cnt=1 artinya ini tepat top up pertama yang baru saja masuk */
      if ((row?.cnt || 0) !== 1) return callback && callback();

      /* Ambil referral use (bonus belum diberikan / bonus=0) */
      db.get(
        'SELECT id, referrer_id FROM referral_uses WHERE user_id=? AND bonus_amount=0',
        [userId],
        (err2, use) => {
          if (!use) return callback && callback();

          const bonus = Math.floor(topupAmount * BONUS_PCT / 100);
          if (bonus <= 0) return callback && callback();

          /* Tambah saldo referrer */
          db.run('UPDATE users SET saldo = saldo + ? WHERE chat_id=?', [bonus, use.referrer_id], () => {
            /* Tandai bonus sudah diberikan */
            db.run('UPDATE referral_uses SET bonus_amount=? WHERE id=?', [bonus, use.id]);
            /* Update statistik kode */
            db.run(
              'UPDATE referral_codes SET total_used=total_used+1, total_earned=total_earned+? WHERE chat_id=?',
              [bonus, use.referrer_id]
            );

            /* Notif ke referrer */
            if (bot) {
              bot.sendMessage(use.referrer_id,
`🎉 <b>BONUS REFERRAL MASUK!</b>

Temanmu berhasil melakukan top up pertama.
💰 Bonus   : <b>Rp ${bonus.toLocaleString('id-ID')}</b>
📊 Dari    : ${BONUS_PCT}% top up Rp ${topupAmount.toLocaleString('id-ID')}

Saldo kamu sudah bertambah otomatis! 🚀`,
                { parse_mode: 'HTML' }
              ).catch(() => {});
            }

            callback && callback(bonus);
          });
        }
      );
    }
  );
}

/* ══════════════════════════════════════════
   INFO REFERRAL USER
══════════════════════════════════════════ */
function getReferralInfo(chatId, callback) {
  generateCode(chatId, (err, code) => {
    if (err) return callback(err, null);
    db.get('SELECT total_used, total_earned FROM referral_codes WHERE chat_id=?', [chatId], (err2, ref) => {
      db.get('SELECT referrer_id FROM referral_uses WHERE user_id=?', [chatId], (err3, use) => {
        callback(null, {
          code,
          totalUsed:   ref?.total_used   || 0,
          totalEarned: ref?.total_earned || 0,
          claimedFrom: use?.referrer_id  || null
        });
      });
    });
  });
}

module.exports = { initReferralTables, generateCode, claimReferral, processReferralBonus, getReferralInfo, BONUS_PCT };
