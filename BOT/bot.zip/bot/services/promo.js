// services/promo.js — v2.0 — termasuk promoBlast ke semua user
'use strict';

const fs   = require('fs');
const path = require('path');
const db   = require('../data/db');

const file   = path.join(__dirname, '../data/promo.json');
let _cache   = null;

function getPromo() {
  if (!_cache) {
    try { _cache = JSON.parse(fs.readFileSync(file, 'utf8')); }
    catch (e) { _cache = { active: false, bonus: 20, min: 15000 }; }
  }
  return _cache;
}

function setPromo(status) {
  const data  = getPromo();
  data.active = status;
  _cache      = data;
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function updatePromo(bonus, min) {
  const data = getPromo();
  data.bonus = bonus;
  data.min   = min;
  _cache     = data;
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function calculateBonus(amount) {
  const promo = getPromo();
  if (!promo.active) return amount;
  const min      = Number(promo.min) || 0;
  const bonusPct = Number(promo.bonus) || 0;
  if (amount < min) return amount;
  const bonus = Math.floor(amount * bonusPct / 100);
  return amount + bonus;
}

/**
 * Blast notifikasi promo ke semua user aktif.
 * Dipanggil dari admin ketika mengaktifkan promo.
 * @param {object} bot
 * @param {function} [onDone] - callback(sent, failed)
 */
function promoBlast(bot, onDone) {
  const promo = getPromo();
  if (!promo.active) return onDone && onDone(0, 0);

  /* Ambil semua user yang pernah aktif (ada transaksi) */
  db.all(
    "SELECT DISTINCT chat_id FROM users WHERE is_banned IS NOT 1",
    [],
    (err, rows) => {
      if (err || !rows?.length) return onDone && onDone(0, 0);

      const msg =
`🔥 <b>PROMO SPESIAL AKTIF!</b>

Dapatkan bonus <b>${promo.bonus}%</b> untuk setiap top up minimal <b>Rp ${Number(promo.min).toLocaleString('id-ID')}</b>!

⏰ Promo berlaku sekarang — jangan sampai ketinggalan!

💰 Klik tombol di bawah untuk top up sekarang.`;

      let sent = 0;
      let failed = 0;
      let idx = 0;

      function sendNext() {
        if (idx >= rows.length) {
          return onDone && onDone(sent, failed);
        }
        const row = rows[idx++];
        bot.sendMessage(row.chat_id, msg, {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '💰 Top Up Sekarang', callback_data: 'menu_deposit' }]
            ]
          }
        }).then(() => { sent++; }).catch(() => { failed++; }).finally(() => {
          /* Delay antar pesan agar tidak kena rate limit Telegram */
          setTimeout(sendNext, 50);
        });
      }

      sendNext();
    }
  );
}

module.exports = { getPromo, setPromo, updatePromo, calculateBonus, promoBlast };
