// services/weeklyReport.js — Laporan mingguan ke owner setiap Minggu 23:59
'use strict';

const db   = require('../data/db');
const fs   = require('fs');
const path = require('path');

let avars = {};
try { avars = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8')); } catch (_) {}

const OWNER_ID = Number(avars.owner_id) || 0;
const BOT_NAME = avars.bot_name || 'BOT';

function sendWeeklyReport(bot) {
  if (!OWNER_ID) return;

  /* Income minggu ini vs minggu lalu */
  db.get(`
    SELECT
      COALESCE(SUM(CASE WHEN strftime('%Y-%W', created_at) = strftime('%Y-%W', 'now','localtime')
        AND order_id NOT LIKE 'TOPUP%' THEN amount END), 0) AS income_week,
      COALESCE(SUM(CASE WHEN strftime('%Y-%W', created_at) = strftime('%Y-%W', date('now','localtime','-7 days'))
        AND order_id NOT LIKE 'TOPUP%' THEN amount END), 0) AS income_lastweek,
      COUNT(CASE WHEN strftime('%Y-%W', created_at) = strftime('%Y-%W', 'now','localtime')
        AND status='completed' THEN 1 END)                  AS trx_week,
      COUNT(CASE WHEN strftime('%Y-%W', created_at) = strftime('%Y-%W', 'now','localtime')
        AND status='completed' AND product_type NOT IN ('','TOPUP') THEN 1 END) AS akun_week
    FROM transactions WHERE status='completed'
  `, [], (err, row) => {
    if (err || !row) return;

    /* Protokol terlaris minggu ini */
    db.all(`
      SELECT product_type, COUNT(*) as cnt
      FROM transactions
      WHERE status='completed'
        AND strftime('%Y-%W', created_at) = strftime('%Y-%W', 'now','localtime')
        AND product_type NOT IN ('','TOPUP')
        AND product_type NOT LIKE 'TRIAL%'
      GROUP BY product_type ORDER BY cnt DESC LIMIT 3
    `, [], (err2, protos) => {

      /* User baru bergabung minggu ini */
      db.get(`
        SELECT COUNT(*) as new_users
        FROM users
        WHERE strftime('%Y-%W', created_at) = strftime('%Y-%W', 'now','localtime')
      `, [], (err3, userRow) => {

        const incomeWeek     = Number(row.income_week || 0);
        const incomeLastWeek = Number(row.income_lastweek || 0);
        const diff           = incomeWeek - incomeLastWeek;
        const diffSign       = diff >= 0 ? '📈 +' : '📉 ';
        const diffPct        = incomeLastWeek > 0
          ? ` (${diffSign}${Math.abs(Math.round(diff / incomeLastWeek * 100))}%)`
          : '';

        const protoLines = (protos || []).map((p, i) =>
          `│ ${i + 1}. <b>${p.product_type}</b> — ${p.cnt} akun`
        ).join('\n') || '│ Belum ada data';

        const weekLabel = new Date().toLocaleDateString('id-ID', {
          timeZone: 'Asia/Jakarta', year: 'numeric', month: 'long', day: 'numeric'
        });

        const msg =
`📊 <b>LAPORAN MINGGUAN</b>

📅 Per ${weekLabel}

┌─────────────────┐
│ 💰 INCOME
│ Minggu ini   : <b>Rp ${incomeWeek.toLocaleString('id-ID')}</b>
│ Minggu lalu  : <b>Rp ${incomeLastWeek.toLocaleString('id-ID')}</b>
│ Perubahan    : <b>${diffSign}Rp ${Math.abs(diff).toLocaleString('id-ID')}${diffPct}</b>
├─────────────────┤
│ 📦 TRANSAKSI
│ Total trx    : <b>${row.trx_week || 0}</b>
│ Akun dijual  : <b>${row.akun_week || 0}</b>
│ User baru    : <b>${userRow?.new_users || 0}</b>
├─────────────────┤
│ 🏆 TOP PROTOKOL
${protoLines}
└─────────────────┘

${diff >= 0 ? '🔥 Pertahankan performa!' : '💪 Semangat minggu depan!'}`;

        bot.sendMessage(OWNER_ID, msg, { parse_mode: 'HTML' }).catch(() => {});
      });
    });
  });
}

function startWeeklyReport(bot) {
  if (!OWNER_ID) return;

  function scheduleNext() {
    const now  = new Date();
    /* Cari hari Minggu berikutnya jam 23:59 */
    const next = new Date();
    next.setHours(23, 59, 0, 0);
    /* getDay() 0=Minggu */
    const daysUntilSunday = (7 - now.getDay()) % 7 || 7;
    next.setDate(next.getDate() + daysUntilSunday);
    if (next <= now) next.setDate(next.getDate() + 7);

    setTimeout(() => {
      sendWeeklyReport(bot);
      scheduleNext();
    }, next - now);
  }

  scheduleNext();
  console.log(`[${BOT_NAME}] ✅ Weekly report aktif (setiap Minggu 23:59)`);
}

module.exports = { startWeeklyReport };
