// services/autoRenew.js — Auto-renew akun H-1 sebelum expired
// Jika user aktifkan auto_renew=1 dan saldo cukup → otomatis perpanjang
'use strict';

const db   = require('../data/db');
const fs   = require('fs');
const path = require('path');

let avars = {};
try { avars = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8')); } catch (_) {}

const BOT_NAME = avars.bot_name || 'BOT';

/* Diperlukan untuk bisa perpanjang */
function getAutoRenewPrice(productType, role) {
  try {
    const p = require.resolve('../data/prices');
    delete require.cache[p];
    const prices = require('../data/prices');
    const r      = (role === 'reseller' || role === 'admin') ? 'reseller' : 'members';
    const keyMap = {
      SSH: 'ssh', VMESS: 'vmess', VLESS: 'vless', TROJAN: 'trojan', ZIVPN: 'udpzivpn'
    };
    const k = keyMap[productType];
    return k ? (prices[r]?.[k]?.perDay || 0) : 0;
  } catch (e) { return 0; }
}

/* Cek dan eksekusi auto-renew */
function runAutoRenew(bot) {
  const sql = `
    SELECT t.id, t.chat_id, t.order_id, t.product_type, t.username, t.server_ip,
           t.expired_at, t.auto_renew_days,
           u.saldo, u.role
    FROM transactions t
    JOIN users u ON u.chat_id = t.chat_id
    WHERE t.status = 'completed'
      AND t.auto_renew = 1
      AND t.product_type NOT IN ('', 'TOPUP')
      AND t.product_type NOT LIKE 'TRIAL%'
      AND date(t.expired_at) = date('now', 'localtime', '+1 days')
  `;

  db.all(sql, [], (err, rows) => {
    if (err || !rows?.length) return;

    rows.forEach((row, i) => {
      setTimeout(() => processAutoRenew(bot, row), i * 3000);
    });
  });
}

async function processAutoRenew(bot, row) {
  const days     = row.auto_renew_days || 30;
  const priceDay = getAutoRenewPrice(row.product_type, row.role);
  const total    = priceDay * days;

  /* Cek saldo cukup */
  if (total <= 0 || row.saldo < total) {
    bot.sendMessage(row.chat_id,
`⚠️ <b>AUTO-RENEW GAGAL!</b>

Akun <b>${row.product_type}</b> (<code>${row.username || '-'}</code>) akan expired besok.

❌ Saldo tidak cukup untuk auto-renew.
💰 Dibutuhkan : <b>Rp ${total.toLocaleString('id-ID')}</b>
💳 Saldo kamu : <b>Rp ${Number(row.saldo).toLocaleString('id-ID')}</b>

Segera top up dan perpanjang manual!`,
      {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [
          [{ text: '💰 Top Up', callback_data: 'menu_deposit' }],
          [{ text: '🔄 Extend Manual', callback_data: 'renew_menu' }]
        ]}
      }
    ).catch(() => {});
    return;
  }

  /* Coba jalankan script renew */
  try {
    const { executeScriptRemote } = require('./ssh-exec');
    const scriptMap = {
      SSH: 'sshRENEW', VMESS: 'vmeRENEW', VLESS: 'vleRENEW',
      TROJAN: 'troRENEW', ZIVPN: 'zivRENEW'
    };
    const scriptName = scriptMap[row.product_type];
    if (!scriptName || !row.server_ip) return;

    executeScriptRemote(row.server_ip, scriptName, [row.username, days], (err, output) => {
      if (err) {
        console.error('[autoRenew] ❌ Script error:', err.message);
        bot.sendMessage(row.chat_id,
          `❌ <b>Auto-renew gagal</b>\n\nAkun ${row.product_type} <code>${row.username}</code>\nError: ${err.message}\n\nSaldo tidak terpotong.`,
          { parse_mode: 'HTML' }
        ).catch(() => {});
        return;
      }

      /* Potong saldo */
      db.run('UPDATE users SET saldo = saldo - ? WHERE chat_id=?', [total, row.chat_id]);

      /* Update expired_at */
      const newExpired = new Date(new Date(row.expired_at).getTime() + days * 86400000)
        .toISOString().slice(0, 19).replace('T', ' ');
      db.run('UPDATE transactions SET expired_at=? WHERE id=?', [newExpired, row.id]);

      /* Catat transaksi renew */
      db.run(
        "INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type, username, expired_at, server_ip) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), ?, ?, ?, ?)",
        [row.chat_id, `RENEW-AUTO-${Date.now()}`, total, `RENEW ${row.product_type}`, row.username, newExpired, row.server_ip]
      );

      bot.sendMessage(row.chat_id,
`✅ <b>AUTO-RENEW BERHASIL!</b>

Akun <b>${row.product_type}</b> (<code>${row.username || '-'}</code>) diperpanjang otomatis.

📅 Diperpanjang : +${days} hari
📅 Expired baru : <b>${newExpired.slice(0, 10)}</b>
💰 Terpotong    : <b>Rp ${total.toLocaleString('id-ID')}</b>`,
        { parse_mode: 'HTML' }
      ).catch(() => {});
    });
  } catch (e) {
    console.error('[autoRenew] ❌', e.message);
  }
}

/* Schedule check setiap hari jam 07:00 */
function startAutoRenew(bot) {
  /* Tambah kolom auto_renew jika belum ada */
  try {
    db.run('ALTER TABLE transactions ADD COLUMN auto_renew INTEGER DEFAULT 0');
  } catch (_) {}
  try {
    db.run('ALTER TABLE transactions ADD COLUMN auto_renew_days INTEGER DEFAULT 30');
  } catch (_) {}

  function scheduleNext() {
    const now  = new Date();
    const next = new Date();
    next.setHours(7, 0, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);
    const delay = next - now;
    setTimeout(() => {
      runAutoRenew(bot);
      scheduleNext();
    }, delay);
  }

  scheduleNext();
  console.log(`[${BOT_NAME}] ✅ Auto-renew scheduler aktif (cek tiap hari 07:00)`);
}

module.exports = { startAutoRenew };
