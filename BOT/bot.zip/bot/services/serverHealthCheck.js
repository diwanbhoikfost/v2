// services/serverHealthCheck.js — Auto-notif admin jika server down/up
// Cek setiap 30 menit, notif jika status berubah
'use strict';

const fs   = require('fs');
const path = require('path');

let avars = {};
try {
  avars = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8'));
} catch (e) {
  console.warn('[serverHealth] .avars.json tidak ditemukan.');
}

const OWNER_ID       = Number(avars.owner_id) || 0;
const BOT_NAME       = avars.bot_name || 'BOT';
const CHECK_INTERVAL = 30 * 60 * 1000; // 30 menit
const FIRST_CHECK_MS = 5 * 60 * 1000;  // pertama kali 5 menit setelah startup

// Map untuk track status sebelumnya: serverIp → 'online' | 'offline' | 'unknown'
const previousStatus = new Map();

function getServers() {
  try {
    const p = require.resolve('../data/server');
    delete require.cache[p];
    return require('../data/server');
  } catch (e) { return []; }
}

function checkServerStatus(serverConfig) {
  return new Promise(resolve => {
    try {
      const { getServerStatus } = require('./ssh-exec');
      getServerStatus(serverConfig).then(info => resolve(info)).catch(() => resolve({ online: false }));
    } catch (e) {
      resolve({ online: false, reason: e.message });
    }
  });
}

async function runHealthCheck(bot) {
  if (!OWNER_ID) return;

  const servers = getServers();
  if (!servers.length) return;

  for (const srv of servers) {
    if (!srv.ip || (!srv.apiUrl && !srv.apiToken)) continue; // skip jika belum ada API

    const info   = await checkServerStatus(srv);
    const isOnline = !!info?.online;
    const current  = isOnline ? 'online' : 'offline';
    const prev     = previousStatus.get(srv.ip);

    // Notif hanya jika status berubah (atau pertama kali offline)
    if (prev === current) continue;

    previousStatus.set(srv.ip, current);

    // Pertama kali check — jangan notif jika online (normal)
    if (prev === undefined && isOnline) continue;

    const waktu = new Date().toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta',
      hour12: false
    });

    if (!isOnline) {
      // Server baru offline
      const msg =
        `🔴 <b>SERVER DOWN!</b>\n\n` +
        `🖥 Server  : <b>${srv.name || srv.ip}</b>\n` +
        `🌐 IP      : <code>${srv.ip}</code>\n` +
        `⏰ Waktu   : ${waktu} WIB\n` +
        (info?.reason ? `❗ Alasan  : ${info.reason}\n` : '') +
        `\n<i>Periksa server segera agar tidak mengganggu layanan.</i>`;

      bot.sendMessage(OWNER_ID, msg, { parse_mode: 'HTML' }).catch(() => {});
      console.warn(`[serverHealth] ⚠️ Server DOWN: ${srv.name || srv.ip} (${srv.ip})`);

    } else {
      // Server kembali online setelah sebelumnya offline
      const msg =
        `🟢 <b>SERVER KEMBALI ONLINE</b>\n\n` +
        `🖥 Server  : <b>${srv.name || srv.ip}</b>\n` +
        `🌐 IP      : <code>${srv.ip}</code>\n` +
        `⏰ Waktu   : ${waktu} WIB\n` +
        `\n✅ Server sudah kembali normal.`;

      bot.sendMessage(OWNER_ID, msg, { parse_mode: 'HTML' }).catch(() => {});
      console.log(`[serverHealth] ✅ Server kembali online: ${srv.name || srv.ip} (${srv.ip})`);
    }

    // Delay antar server agar tidak flood
    await new Promise(r => setTimeout(r, 500));
  }
}

function startServerHealthCheck(bot) {
  if (!OWNER_ID) {
    console.warn('[serverHealth] owner_id tidak diset, health check dinonaktifkan.');
    return;
  }

  // Pertama kali cek setelah 5 menit (beri waktu bot startup)
  setTimeout(() => runHealthCheck(bot), FIRST_CHECK_MS);

  // Selanjutnya setiap 30 menit
  setInterval(() => runHealthCheck(bot), CHECK_INTERVAL);

  console.log(`[${BOT_NAME}] ✅ Server health check aktif (cek tiap 30 menit)`);
}

module.exports = { startServerHealthCheck };
