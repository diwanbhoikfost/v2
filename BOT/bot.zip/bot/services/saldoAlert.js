// services/saldoAlert.js — Notif saldo hampir habis
// Kirim peringatan ke user jika saldo > 0 tapi tidak cukup beli akun apapun
'use strict';

const db   = require('../data/db');
const fs   = require('fs');
const path = require('path');

let avars = {};
try { avars = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8')); } catch (_) {}

const BOT_NAME = avars.bot_name || 'BOT';

function getMinPrice() {
  try {
    const p = require.resolve('../data/prices');
    delete require.cache[p];
    const prices = require('../data/prices');
    /* Ambil harga terendah dari semua protokol members */
    const all = Object.values(prices.members || {}).map(v => v.perDay || 99999);
    return Math.min(...all) || 5000;
  } catch (e) { return 5000; }
}

function runSaldoCheck(bot) {
  const minPrice = getMinPrice();

  /* User yang: saldo > 0, saldo < harga termurah, pernah beli akun sebelumnya */
  const sql = `
    SELECT DISTINCT u.chat_id, u.saldo
    FROM users u
    WHERE u.saldo > 0 AND u.saldo < ?
      AND EXISTS (
        SELECT 1 FROM transactions t
        WHERE t.chat_id = u.chat_id
          AND t.status = 'completed'
          AND t.product_type NOT IN ('', 'TOPUP')
      )
      AND u.is_banned IS NOT 1
  `;

  db.all(sql, [minPrice * 30], (err, rows) => {
    if (err || !rows?.length) return;

    rows.forEach((row, i) => {
      setTimeout(() => {
        bot.sendMessage(row.chat_id,
`💰 <b>SALDO HAMPIR HABIS!</b>

Saldo kamu saat ini: <b>Rp ${Number(row.saldo).toLocaleString('id-ID')}</b>

Saldo tidak cukup untuk membuat akun baru.
Segera top up agar layanan tidak terganggu! 🚀`,
          {
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [
                [{ text: '💰 Top Up Sekarang', callback_data: 'menu_deposit' }],
                [{ text: '🎁 Claim Voucher',   callback_data: 'menu_claim_voucher' }]
              ]
            }
          }
        ).catch(() => {});
      }, i * 1000);
    });
  });
}

/* Tambah kolom is_banned jika belum ada */
function initBanColumn() {
  try { db.run('ALTER TABLE users ADD COLUMN is_banned INTEGER DEFAULT 0'); } catch (_) {}
  try { db.run('ALTER TABLE users ADD COLUMN ban_reason TEXT DEFAULT ""'); } catch (_) {}
}

/* Schedule jam 09:00 setiap hari */
function startSaldoAlert(bot) {
  initBanColumn();

  function scheduleNext() {
    const now  = new Date();
    const next = new Date();
    next.setHours(9, 0, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);
    setTimeout(() => {
      runSaldoCheck(bot);
      scheduleNext();
    }, next - now);
  }

  scheduleNext();
  console.log(`[${BOT_NAME}] ✅ Saldo alert aktif (cek tiap hari 09:00)`);
}

module.exports = { startSaldoAlert, initBanColumn };
