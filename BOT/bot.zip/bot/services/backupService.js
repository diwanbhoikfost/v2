// services/backupService.js — Backup database otomatis ke Telegram
// Kirim file .db ke owner setiap hari jam 03:00
'use strict';

const fs   = require('fs');
const path = require('path');

let avars = {};
try { avars = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8')); } catch (_) {}

const OWNER_ID = Number(avars.owner_id) || 0;
const BOT_NAME = avars.bot_name || 'BOT';
const DB_PATH  = path.join(__dirname, '../data/yanbot.db');

async function sendBackup(bot) {
  if (!OWNER_ID) return;

  /* Save dulu sebelum backup */
  try {
    const db = require('../data/db');
    db.saveDb();
    await new Promise(r => setTimeout(r, 500)); // tunggu write selesai
  } catch (_) {}

  if (!fs.existsSync(DB_PATH)) {
    return bot.sendMessage(OWNER_ID, '⚠️ Backup gagal: file database tidak ditemukan.').catch(() => {});
  }

  const tanggal = new Date().toLocaleDateString('id-ID', {
    timeZone: 'Asia/Jakarta',
    year: 'numeric', month: '2-digit', day: '2-digit'
  }).replace(/\//g, '-');

  const size = (fs.statSync(DB_PATH).size / 1024).toFixed(1);

  try {
    await bot.sendDocument(OWNER_ID,
      DB_PATH,
      {
        caption:
`💾 <b>BACKUP DATABASE OTOMATIS</b>

📅 Tanggal : ${tanggal}
📦 Ukuran  : ${size} KB
🤖 Bot     : ${BOT_NAME}

<i>Simpan file ini di tempat aman!</i>`,
        parse_mode: 'HTML'
      },
      {
        filename: `yanbot_backup_${tanggal}.db`,
        contentType: 'application/octet-stream'
      }
    );

    console.log(`[backup] ✅ Backup berhasil dikirim ke owner (${size} KB)`);
  } catch (err) {
    console.error('[backup] ❌ Gagal kirim backup:', err.message);
    bot.sendMessage(OWNER_ID, `❌ Backup gagal: ${err.message}`).catch(() => {});
  }
}

function startBackupService(bot) {
  if (!OWNER_ID) {
    console.warn('[backup] ⚠️ owner_id tidak diset, backup dinonaktifkan.');
    return;
  }

  function scheduleNext() {
    const now  = new Date();
    const next = new Date();
    next.setHours(3, 0, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);
    setTimeout(() => {
      sendBackup(bot);
      scheduleNext();
    }, next - now);
  }

  scheduleNext();
  console.log(`[${BOT_NAME}] ✅ Auto backup aktif (kirim ke owner jam 03:00)`);
}

module.exports = { startBackupService, sendBackup };
