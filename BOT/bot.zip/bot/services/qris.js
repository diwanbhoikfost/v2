// services/qris.js - v4.0 — 10min countdown live seconds, cancel button
'use strict';

const axios  = require('axios');
const QRCode = require('qrcode');
const fs     = require('fs');
const path   = require('path');
const db     = require('../data/db');

let avars = {};
try {
  avars = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8'));
} catch (e) {
  console.warn('[qris] .avars.json tidak ditemukan.');
}

const QRIS_EXPIRY_MS  = 10 * 60 * 1000;  // 10 menit
const UPDATE_INTERVAL = 10 * 1000;        // update tiap 10 detik (countdown terlihat berjalan)

/* Map untuk menyimpan countdown intervals agar bisa di-cancel saat bayar */
const countdownIntervals = new Map();

function clearCountdown(orderId) {
  const iv = countdownIntervals.get(orderId);
  if (iv) { clearInterval(iv); countdownIntervals.delete(orderId); }
}

module.exports.clearQrisCountdown = clearCountdown;

async function generateQRIS(bot, chatId, amount, pendingInfo = {}) {
  const orderId = `${chatId}_${Date.now()}`;

  const apiKey = process.env.PAKASIR_API_KEY || avars.pakasir_api_key;
  if (!avars.pakasir_slug || !apiKey) {
    return bot.sendMessage(chatId, '❌ Konfigurasi payment belum lengkap. Hubungi admin.');
  }

  try {
    const createRes = await axios.post('https://app.pakasir.com/api/transactioncreate/qris', {
      project:  avars.pakasir_slug,
      order_id: orderId,
      amount,
      api_key:  apiKey
    }, { timeout: 15000 });

    const txData = createRes.data;
    if (!txData.payment?.payment_number) throw new Error('Gagal dapat QR string dari Pakasir');

    const qrBuffer = await QRCode.toBuffer(txData.payment.payment_number, { width: 350 });

    const productType = pendingInfo.productType || '';
    db.run(
      "INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type) VALUES (?, ?, ?, 'pending', datetime('now','localtime'), ?)",
      [chatId, orderId, amount, productType]
    );

    const isCreate = !!pendingInfo.accountCreate;
    const isRenew  = !!pendingInfo.accountRenew;

    function buildCaption(remainingMs) {
  const totalSecs = Math.max(0, Math.floor(remainingMs / 1000));
  const mm = String(Math.floor(totalSecs / 60)).padStart(2, "0");
  const ss = String(totalSecs % 60).padStart(2, "0");

  const percent = remainingMs / QRIS_EXPIRY_MS;

  const bar =
    percent >= 0.9 ? "🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩" :
    percent >= 0.8 ? "🟩🟩🟩🟩🟩🟩🟩🟩🟩⬜" :
    percent >= 0.7 ? "🟩🟩🟩🟩🟩🟩🟩🟩⬜⬜" :
    percent >= 0.6 ? "🟩🟩🟩🟩🟩🟩🟩⬜⬜⬜" :
    percent >= 0.5 ? "🟨🟨🟨🟨🟨🟨⬜⬜⬜⬜" :
    percent >= 0.4 ? "🟨🟨🟨🟨🟨⬜⬜⬜⬜⬜" :
    percent >= 0.3 ? "🟧🟧🟧🟧⬜⬜⬜⬜⬜⬜" :
    percent >= 0.2 ? "🟥🟥🟥⬜⬜⬜⬜⬜⬜⬜" :
                     "🟥⬜⬜⬜⬜⬜⬜⬜⬜⬜";

  let title = "💳 <b>PEMBAYARAN</b>";

  if (isCreate)
    title = `🚀 <b>ORDER ${pendingInfo.productName}</b>`;

  if (isRenew)
    title = `♻️ <b>RENEW ${pendingInfo.productName}</b>`;

  return `
╔════════════════════════════╗
║      👑 <b>DIWAN TUNNELING</b>
╚════════════════════════════╝

${title}

━━━━━━━━━━━━━━━━━━━━━━
💰 <b>Nominal</b>

<b>Rp ${amount.toLocaleString("id-ID")}</b>

━━━━━━━━━━━━━━━━━━━━━━
🧾 <b>Order ID</b>

<code>${orderId}</code>

━━━━━━━━━━━━━━━━━━━━━━
⏳ <b>Sisa Waktu</b>

${bar}

<b>${mm}:${ss}</b>

━━━━━━━━━━━━━━━━━━━━━━
✅ Setelah pembayaran berhasil

${isCreate
  ? "• Akun dibuat otomatis\n• Masa aktif langsung dimulai"
  : isRenew
    ? "• Masa aktif diperpanjang otomatis"
    : "• Saldo masuk otomatis"}

━━━━━━━━━━━━━━━━━━━━━━
📱 Scan QR menggunakan

• DANA
• OVO
• GoPay
• ShopeePay
• Mobile Banking

━━━━━━━━━━━━━━━━━━━━━━
⚠️ QRIS akan otomatis kadaluarsa
setelah <b>10 menit</b>.
`;
}