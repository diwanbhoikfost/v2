
// ====== Diwan Tunneling Bot - Sempurna Version ======
const { Telegraf, Markup } = require('telegraf');
const fs = require('fs');
const os = require('os');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const BOT_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN';
const BACKUP_DIR = path.join(__dirname, 'backup');
const DB_FILE = path.join(__dirname, 'data', 'db.sqlite3');
const MAX_SLOT_DEFAULT = 100;

if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
if (!fs.existsSync(path.dirname(DB_FILE))) fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });

const bot = new Telegraf(BOT_TOKEN);

function openDatabase(file = DB_FILE) {
    if (!fs.existsSync(file)) {
        console.error('Database file not found:', file);
        throw new Error('Database file not found');
    }
    const db = new sqlite3.Database(file, (err) => {
        if (err) console.error('Failed to open database:', err.message);
    });
    return db;
}

function backupDatabase() {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupFile = path.join(BACKUP_DIR, `backup_${timestamp}.db`);
    fs.copyFileSync(DB_FILE, backupFile);
    return backupFile;
}

function restoreDatabase(file) {
    if (!fs.existsSync(file)) throw new Error('Backup file not found');
    const dbTest = new sqlite3.Database(file);
    dbTest.get("PRAGMA integrity_check;", (err, row) => {
        if (err || row.integrity_check !== 'ok') throw new Error('Backup file corrupt');
    });
    fs.copyFileSync(file, DB_FILE);
}

function getServerStatus() {
    const cpuLoad = os.loadavg()[0].toFixed(2);
    const freeMem = (os.freemem() / (1024 * 1024)).toFixed(2);
    const totalMem = (os.totalmem() / (1024 * 1024)).toFixed(2);
    const db = openDatabase();
    let slotUsed = 0;
    db.all("SELECT COUNT(*) as count FROM accounts", (err, rows) => {
        if (!err && rows && rows[0]) slotUsed = rows[0].count;
    });
    return `CPU Load: ${cpuLoad}\nRAM: ${freeMem} MB / ${totalMem} MB\nServer Slots: ${slotUsed}/${MAX_SLOT_DEFAULT}`;
}

bot.start((ctx) => {
    ctx.reply('Selamat datang di Diwan Tunneling Bot!', Markup.inlineKeyboard([
        [Markup.button.callback('📝 Orders', 'ORDERS')],
        [Markup.button.callback('♻️ Create Trial', 'TRIAL')],
        [Markup.button.callback('👤 My Account', 'MYACCOUNT')],
        [Markup.button.callback('💎 Reseller Menu', 'RESELLER')],
        [Markup.button.callback('🎁 Claim Saldo Gratis', 'CLAIM')],
        [Markup.button.callback('🔄 Perpanjang Akun', 'RENEW')],
        [Markup.button.callback('📊 Server Monitoring', 'MONITOR')],
        [Markup.button.callback('💾 Backup DB', 'BACKUP')],
        [Markup.button.callback('♻️ Restore DB', 'RESTORE')]
    ]))
});

bot.action('MONITOR', async (ctx) => ctx.reply(getServerStatus()));
bot.action('RENEW', async (ctx) => ctx.reply('Silakan pilih akun dan durasi perpanjangan.'));
bot.action('BACKUP', (ctx) => {
    try {
        const backupFile = backupDatabase();
        ctx.reply(`Backup berhasil dibuat: ${backupFile}`);
    } catch (err) {
        ctx.reply(`Backup gagal: ${err.message}`);
    }
});
bot.action('RESTORE', (ctx) => ctx.reply('Silakan kirim nama file backup yang ingin direstore.'));
bot.action('ORDERS', (ctx) => ctx.reply('Daftar orders dan status akun ditampilkan di sini.'));
bot.action('TRIAL', (ctx) => ctx.reply('Buat akun trial baru.'));
bot.action('MYACCOUNT', (ctx) => ctx.reply('Informasi akunmu.'));
bot.action('RESELLER', (ctx) => ctx.reply('Menu reseller.'));
bot.action('CLAIM', (ctx) => ctx.reply('Claim saldo gratis.'));

setInterval(() => {
    try { backupDatabase(); console.log('Auto backup berhasil'); }
    catch (err) { console.error('Auto backup error:', err.message); }
}, 24*60*60*1000);

bot.launch();
console.log('Diwan Tunneling Bot running - versi sempurna');
