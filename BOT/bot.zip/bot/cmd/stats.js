// cmd/stats.js — Dashboard statistik personal user
'use strict';

const db = require('../data/db');

function dbGet(sql, params = []) {
  return new Promise((res, rej) =>
    db.get(sql, params, (err, row) => err ? rej(err) : res(row || {}))
  );
}

module.exports = async function statsCmd(bot, chatId, msgId) {
  try {
    const [user, txStat, favProto, activeAcc, totalSpend] = await Promise.all([

      /* Info dasar user */
      dbGet('SELECT saldo, role, created_at FROM users WHERE chat_id=?', [chatId]),

      /* Ringkasan transaksi */
      dbGet(`
        SELECT
          COUNT(CASE WHEN status='completed' AND date(created_at)=date('now','localtime') THEN 1 END)                                AS tx_today,
          COUNT(CASE WHEN status='completed' AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime') THEN 1 END)       AS tx_month,
          COUNT(CASE WHEN status='completed' THEN 1 END)                                                                             AS tx_total,
          COUNT(CASE WHEN status='completed' AND product_type NOT IN ('','TOPUP') THEN 1 END)                                       AS akun_total,
          COUNT(CASE WHEN status='completed' AND product_type NOT IN ('','TOPUP') AND date(created_at)=date('now','localtime') THEN 1 END) AS akun_today
        FROM transactions WHERE chat_id=?
      `, [chatId]),

      /* Protokol favorit */
      dbGet(`
        SELECT product_type, COUNT(*) as cnt
        FROM transactions
        WHERE chat_id=? AND status='completed'
          AND product_type NOT IN ('','TOPUP')
          AND product_type NOT LIKE 'TRIAL%'
          AND product_type NOT LIKE 'RENEW%'
        GROUP BY product_type ORDER BY cnt DESC LIMIT 1
      `, [chatId]),

      /* Akun masih aktif */
      dbGet(`
        SELECT COUNT(*) as cnt
        FROM transactions
        WHERE chat_id=? AND status='completed'
          AND product_type NOT IN ('','TOPUP')
          AND expired_at > datetime('now','localtime')
      `, [chatId]),

      /* Total pengeluaran */
      dbGet(`
        SELECT COALESCE(SUM(amount),0) as total
        FROM transactions
        WHERE chat_id=? AND status='completed'
          AND product_type NOT IN ('','TOPUP')
      `, [chatId])
    ]);

    const saldo    = Number(user.saldo) || 0;
    const role     = (user.role || 'members').toUpperCase();
    const joinDate = user.created_at ? user.created_at.slice(0, 10) : '-';

    const PROTO_LABEL = {
      SSH: '⚪ SSH', VMESS: '🔵 VMess', VLESS: '🟡 VLess',
      TROJAN: '🟠 Trojan', ZIVPN: '🟢 ZivPN'
    };

    const fav = favProto?.product_type
      ? `${PROTO_LABEL[favProto.product_type] || favProto.product_type} (${favProto.cnt}x)`
      : '-';

    const text =
`┌─────────────────────┐
│  📊 STATISTIK AKUNMU
└─────────────────────┘

👤 <b>Profil</b>
├ Role       : <b>${role}</b>
├ Chat ID    : <code>${chatId}</code>
├ Join       : ${joinDate}
└ Saldo      : <b>Rp ${saldo.toLocaleString('id-ID')}</b>

📦 <b>Akun VPN</b>
├ Akun aktif   : <b>${activeAcc.cnt || 0} akun</b>
├ Total dibuat : <b>${txStat.akun_total || 0} akun</b>
└ Protokol fav : <b>${fav}</b>

🧾 <b>Transaksi</b>
├ Hari ini  : <b>${txStat.tx_today || 0}</b>
├ Bulan ini : <b>${txStat.tx_month || 0}</b>
└ All time  : <b>${txStat.tx_total || 0}</b>

💰 <b>Pengeluaran</b>
└ Total spend : <b>Rp ${Number(totalSpend.total || 0).toLocaleString('id-ID')}</b>`;

    bot.editMessageText(text, {
      chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '📜 Riwayat Transaksi', callback_data: 'menu_history' }],
          [{ text: '🔃 Kembali ke Menu',   callback_data: 'menu_back'    }]
        ]
      }
    }).catch(() => {});

  } catch (err) {
    console.error('[stats]', err.message);
    bot.editMessageText('❌ Gagal memuat statistik. Coba lagi.', {
      chat_id: chatId, message_id: msgId,
      reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
    }).catch(() => {});
  }
};
