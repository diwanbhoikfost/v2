// cmd/trx.js - Riwayat Transaksi dengan Pagination
'use strict';

const db = require('../data/db');

const PAGE_SIZE = 8;

const STATUS_ICON = { completed: '✅', pending: '⏳', canceled: '❌', expired: '❌' };

module.exports = function trxCmd(bot, chatId, msgId, page = 0) {
  const safePage = Math.max(0, page);
  const offset   = safePage * PAGE_SIZE;

  /* Hitung total dulu, lalu ambil halaman ini */
  db.get(
    "SELECT COUNT(*) as total FROM transactions WHERE chat_id=?",
    [chatId],
    (err, countRow) => {
      const total   = countRow?.total || 0;
      const maxPage = Math.max(0, Math.ceil(total / PAGE_SIZE) - 1);
      const curPage = Math.min(safePage, maxPage);

      db.all(
        "SELECT product_type, amount, status, created_at, username FROM transactions WHERE chat_id=? ORDER BY created_at DESC LIMIT ? OFFSET ?",
        [chatId, PAGE_SIZE, curPage * PAGE_SIZE],
        (err2, rows) => {
          if (err2) {
            return bot.editMessageText('❌ Gagal load riwayat.', {
              chat_id: chatId, message_id: msgId,
              reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
            }).catch(() => {});
          }

          const pageLabel = total > 0
            ? `Hal ${curPage + 1}/${Math.ceil(total / PAGE_SIZE)} (${total} total)`
            : 'Kosong';

          let text = `┌─────────────────┐\n│  📜 RIWAYAT TRANSAKSI\n│  ${pageLabel}\n└─────────────────┘\n\n`;

          if (!rows?.length) {
            text += '📭 Belum ada transaksi.';
          } else {
            rows.forEach((r, i) => {
              const ico    = STATUS_ICON[r.status] || '❓';
              const date   = r.created_at ? r.created_at.slice(0, 16) : '-';
              const user   = r.username ? ` • ${r.username}` : '';
              const no     = curPage * PAGE_SIZE + i + 1;
              text += `${no}. ${ico} <b>${r.product_type || '-'}</b>${user}\n`;
              text += `   💰 Rp ${Number(r.amount).toLocaleString('id-ID')}  📅 ${date}\n\n`;
            });
          }

          /* Tombol navigasi */
          const navRow = [];
          if (curPage > 0)         navRow.push({ text: '◀️ Sebelumnya', callback_data: `trx_p_${curPage - 1}` });
          if (curPage < maxPage)   navRow.push({ text: '▶️ Berikutnya', callback_data: `trx_p_${curPage + 1}` });

          const keyboard = [];
          if (navRow.length) keyboard.push(navRow);
          keyboard.push([{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]);

          bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard }
          }).catch(() => {});
        }
      );
    }
  );
};
