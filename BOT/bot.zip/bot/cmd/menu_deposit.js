// cmd/menu_deposit.js
'use strict';

module.exports = function menuDepositCmd(bot, chatId, msgId) {

const text = `
╭━━━━━━━━━━━━━━━━━━━━━━╮
┃      💳 <b>TOP UP SALDO</b>
╰━━━━━━━━━━━━━━━━━━━━━━╯

Isi saldo dengan mudah melalui
<b>QRIS Otomatis</b>.

━━━━━━━━━━━━━━━━━━

💰 <b>Minimal Top Up</b>
Rp 10.000

👑 <b>Upgrade Reseller</b>
Minimal saldo Rp 25.000

⚡ Pembayaran akan diverifikasi
secara otomatis setelah QRIS
berhasil dibayar.

━━━━━━━━━━━━━━━━━━

👇 <b>Pilih nominal top up</b>
`;

const keyboard = {
inline_keyboard: [

[
{ text: "💵 10K", callback_data: "deposit_10000" },
{ text: "💵 20K", callback_data: "deposit_20000" }
],

[
{ text: "💎 30K", callback_data: "deposit_30000" },
{ text: "💎 40K", callback_data: "deposit_40000" }
],

[
{ text: "🚀 50K", callback_data: "deposit_50000" },
{ text: "🚀 60K", callback_data: "deposit_60000" }
],

[
{ text: "🔥 70K", callback_data: "deposit_70000" },
{ text: "🔥 80K", callback_data: "deposit_80000" }
],

[
{ text: "⭐ 90K", callback_data: "deposit_90000" },
{ text: "👑 100K", callback_data: "deposit_100000" }
],

[
{ text: "✍️ Nominal Lain", callback_data: "deposit_custom" }
],

[
{ text: "🏠 Kembali ke Menu", callback_data: "menu_back" }
]

]
};

bot.editMessageText(text, {
chat_id: chatId,
message_id: msgId,
parse_mode: "HTML",
reply_markup: keyboard
}).catch(() => {});

};