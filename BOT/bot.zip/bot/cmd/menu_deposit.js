// cmd/menu_deposit.js - Premium Deposit Menu
'use strict';

module.exports = function menuDepositCmd(bot, chatId, msgId) {
  const text = `
╔══════════════════════════════╗
║        💎 TOP UP SALDO        ║
╚══════════════════════════════╝

✨ <b>Top Up Saldo Diwan Tunneling</b>

Saldo digunakan untuk pembelian produk
serta <b>upgrade menjadi Reseller</b>.

━━━━━━━━━━━━━━━━━━━━━━
💎 <b>Minimal Upgrade Reseller</b>
└ Rp30.000

💳 <b>Metode Pembayaran</b>
└ QRIS (Semua E-Wallet & Mobile Banking)

⚡ <b>Proses Otomatis 24/7</b>
└ Saldo akan masuk setelah pembayaran
   berhasil dikonfirmasi.

📝 Anda dapat memilih nominal di bawah
atau menggunakan <b>Nominal Bebas</b>
(minimal Rp30.000).

━━━━━━━━━━━━━━━━━━━━━━
👇 <b>PILIH NOMINAL DEPOSIT</b>
━━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: '💎 Rp30K', callback_data: 'deposit_30000' },
        { text: '💰 Rp50K', callback_data: 'deposit_50000' }
      ],
      [
        { text: '🚀 Rp75K', callback_data: 'deposit_75000' },
        { text: '👑 Rp100K', callback_data: 'deposit_100000' }
      ],
      [
        { text: '✨ Nominal Bebas', callback_data: 'deposit_custom' }
      ],
      [
        { text: '🏠 Menu Utama', callback_data: 'menu_back' }
      ]
    ]
  };

  bot.editMessageText(text, {
    chat_id: chatId,
    message_id: msgId,
    parse_mode: 'HTML',
    reply_markup: keyboard
  }).catch(() => {});
};