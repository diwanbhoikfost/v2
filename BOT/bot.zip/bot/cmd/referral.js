// cmd/referral.js — Tampilan menu referral untuk user
'use strict';

const { getReferralInfo, BONUS_PCT } = require('../services/referral');

module.exports = function referralCmd(bot, chatId, msgId) {
  getReferralInfo(chatId, (err, info) => {
    if (err || !info) {
      return bot.editMessageText('❌ Gagal memuat info referral. Coba lagi.', {
        chat_id: chatId, message_id: msgId,
        reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
      }).catch(() => {});
    }

    const { code, totalUsed, totalEarned, claimedFrom } = info;

    const claimedLine = claimedFrom
      ? `✅ Kamu sudah claim kode referral orang lain\n`
      : `📥 Belum claim referral? Klik tombol di bawah\n`;

    const text =
`┌─────────────────────┐
│  🔗 PROGRAM REFERRAL
└─────────────────────┘

<b>Kode Referralmu:</b>
<code>${code}</code>

Bagikan kode ini ke temanmu!
Jika mereka top up pertama kali, kamu dapat
bonus <b>${BONUS_PCT}%</b> dari nilai top up mereka.

📊 <b>Statistik Referralmu:</b>
├ Teman join  : <b>${totalUsed} orang</b>
└ Total bonus : <b>Rp ${totalEarned.toLocaleString('id-ID')}</b>

${claimedLine}
⚠️ <i>Bonus hanya untuk top up pertama temanmu</i>`;

    const keyboard = [];

    if (!claimedFrom) {
      keyboard.push([{ text: '📥 Claim Kode Referral', callback_data: 'referral_claim' }]);
    }

    keyboard.push([{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]);

    bot.editMessageText(text, {
      chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    }).catch(() => {});
  });
};
