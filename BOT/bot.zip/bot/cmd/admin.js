// cmd/admin.js - v4.0 — full beautify, kelola server, hapus profit, pagination semua user
'use strict';

const db   = require('../data/db');
const fs   = require('fs');
const path = require('path');

const avars = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8'));
const { calculateBonus, setPromo, getPromo, updatePromo } = require('../services/promo');
const { createVoucher, listVouchers, deactivateVoucher } = require('../services/voucher');
const { syncToAllServers, readAllScripts } = require('../services/sync-scripts');
const { installApiRemote } = require('../services/remote-install');

const OWNER_ID   = Number(avars.owner_id);
const serverPath = path.join(__dirname, '../data/server.js');

const sessions = {};

/* ── DB promise helpers ── */
function runAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) { if (err) return reject(err); resolve(this); });
  });
}
function allAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => { if (err) return reject(err); resolve(rows || []); });
  });
}
function getAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => { if (err) return reject(err); resolve(row || null); });
  });
}

/* ══════════════════════════════════════════
   HELPERS
══════════════════════════════════════════ */
function mainKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: '📢 Broadcast',              callback_data: 'adm_broadcast'        },
        { text: '📌 Add Server',             callback_data: 'adm_server'           }
      ],
      [{ text: '👑 Set Reseller / Tambah Saldo', callback_data: 'adm_set'         }],
      [
        { text: '👥 Daftar Members',         callback_data: 'adm_members_p_0'      },
        { text: '💎 Daftar Reseller',        callback_data: 'adm_reseller'         }
      ],
      [
        { text: '📊 Top Saldo',              callback_data: 'adm_top'              },
        { text: '🔍 Cari User',              callback_data: 'adm_search'           }
      ],
      [
        { text: '💾 Backup DB',              callback_data: 'adm_backup'           },
        { text: '📥 Restore DB',             callback_data: 'adm_restore'          }
      ],
      [
        { text: '🖥 Kelola Server',          callback_data: 'adm_list_server'      },
        { text: '📊 Statistik Server',       callback_data: 'adm_statistik_server' }
      ],
      [{ text: '💰 Statistik Income',        callback_data: 'adm_income'           }],
      [
        { text: '🔥 Promo ON',               callback_data: 'adm_promo_on'         },
        { text: '❌ Promo OFF',              callback_data: 'adm_promo_off'        }
      ],
      [{ text: '⚙️ Atur Promo',              callback_data: 'adm_atur_promo'       }],
      [{ text: '🎟 Generate Voucher',        callback_data: 'adm_gen_voucher'      }],
      [{ text: '💲 Set Harga VPN',           callback_data: 'adm_set_harga'        }],
      [{ text: '🔄 Sync Scripts ke VPS',    callback_data: 'adm_sync_scripts'     }]
    ]
  };
}

function backKeyboard() {
  return {
    inline_keyboard: [
      [{ text: '🔙 Kembali ke Menu Admin', callback_data: 'adm_back' }]
    ]
  };
}

function formatRupiah(value) {
  return `Rp ${Number(value || 0).toLocaleString('id-ID')}`;
}

function makeBar(percent) {
  const safe = Math.max(0, Math.min(100, Number(percent || 0)));
  const filled = Math.round(safe / 10);
  return '█'.repeat(filled) + '░'.repeat(10 - filled);
}

async function editMsg(bot, chatId, msgId, text, opts = {}) {
  return bot.editMessageText(text, {
    chat_id: chatId, message_id: msgId, ...opts
  }).catch(err => {
    if (!err.message?.includes('message is not modified')) {
      console.error('[admin editMsg]', err.message);
    }
  });
}

async function buildAdminHeader() {
  const [uRow, incRow] = await Promise.all([
    getAsync("SELECT COUNT(*) as n FROM users"),
    getAsync(`SELECT
      COUNT(*) as today_tx,
      COALESCE(SUM(CASE WHEN order_id GLOB '[0-9]*' THEN amount END), 0) as today_inc
      FROM transactions
      WHERE status='completed' AND date(created_at)=date('now','localtime')`)
  ]);

  const totalUsers  = uRow?.n           || 0;
  const todayTx     = incRow?.today_tx  || 0;
  const todayInc    = incRow?.today_inc || 0;

  const promo       = getPromo();
  const promoStatus = promo.active
    ? `🟢 ON  (Bonus ${promo.bonus}%, Min Rp ${Number(promo.min).toLocaleString('id-ID')})`
    : `🔴 OFF`;

  return (
    `┌──────────────┐\n` +
    `│            🀄 𝗔𝗗𝗠𝗜𝗡 𝗣𝗔𝗡𝗘𝗟 🀄\n` +
    `├──────────────┤\n` +
    `│ 👥 Total User  : <b>${totalUsers}</b>\n` +
    `│ 📦 Order Hari Ini : <b>${todayTx}</b>\n` +
    `│ 💰 Income Hari Ini: <b>${formatRupiah(todayInc)}</b>\n` +
    `│ 🎁 Status Promo   : ${promoStatus}\n` +
    `└─────────────────────┘\n\n` +
    `Pilih menu di bawah ini:`
  );
}

/* ══════════════════════════════════════════
   NON-BLOCKING BROADCAST
══════════════════════════════════════════ */
async function broadcastToAll(bot, text) {
  return new Promise(resolve => {
    db.all('SELECT chat_id FROM users', [], (err, rows) => {
      if (err || !rows?.length) return resolve(0);
      let sent = 0, idx = 0;
      function sendNext() {
        if (idx >= rows.length) return resolve(sent);
        const row = rows[idx++];
        bot.sendMessage(row.chat_id, text, { parse_mode: 'HTML' })
          .then(() => { sent++; }).catch(() => {}).finally(() => setImmediate(sendNext));
      }
      setImmediate(sendNext);
    });
  });
}

/* ══════════════════════════════════════════
   AKSI LANGSUNG
══════════════════════════════════════════ */
async function handleInstant(bot, chatId, msgId, mode, extra = {}) {

  /* ── DAFTAR MEMBERS (dengan pagination) ── */
  if (mode === 'members_p') {
    const PAGE_SIZE = 10;
    const page      = extra.page || 0;
    const offset    = page * PAGE_SIZE;

    await editMsg(bot, chatId, msgId, '⏳ <i>Memuat daftar members...</i>', { parse_mode: 'HTML' });

    const [totalRow, rows] = await Promise.all([
      getAsync("SELECT COUNT(*) as n FROM users WHERE role='members'"),
      allAsync(`
        SELECT u.chat_id, u.saldo, u.created_at,
               COUNT(t.id) as total_order
        FROM users u
        LEFT JOIN transactions t ON t.chat_id = u.chat_id AND t.status='completed'
        WHERE u.role='members'
        GROUP BY u.chat_id
        ORDER BY u.created_at DESC
        LIMIT ? OFFSET ?
      `, [PAGE_SIZE, offset])
    ]);

    const total     = totalRow?.n || 0;
    const totalPage = Math.ceil(total / PAGE_SIZE) || 1;

    let txt = `┌─────────────────────┐\n`;
    txt    += `│ 👥 DAFTAR MEMBERS  [${page + 1}/${totalPage}]\n`;
    txt    += `│ Total: ${total} members\n`;
    txt    += `└─────────────────────┘\n\n`;

    if (!rows?.length) {
      txt += '❌ Tidak ada members.';
    } else {
      rows.forEach((u, i) => {
        const no     = offset + i + 1;
        const saldo  = Number(u.saldo).toLocaleString('id-ID');
        const joined = (u.created_at || '').slice(0, 10) || '-';
        const orders = u.total_order || 0;
        txt += `${no}. 👤 <code>${u.chat_id}</code>\n`;
        txt += `    💰 Rp ${saldo}  📦 ${orders} order\n`;
        txt += `    📅 Join: ${joined}\n\n`;
      });
    }

    const navButtons = [];
    if (page > 0)              navButtons.push({ text: '◀️ Prev', callback_data: `adm_members_p_${page - 1}` });
    navButtons.push({ text: `${page + 1}/${totalPage}`, callback_data: 'adm_noop' });
    if (page < totalPage - 1)  navButtons.push({ text: 'Next ▶️', callback_data: `adm_members_p_${page + 1}` });

    const kb = { inline_keyboard: [] };
    if (total > PAGE_SIZE) kb.inline_keyboard.push(navButtons);
    kb.inline_keyboard.push([{ text: '🔙 Kembali ke Menu Admin', callback_data: 'adm_back' }]);

    await editMsg(bot, chatId, msgId, txt, { parse_mode: 'HTML', reply_markup: kb });
    return;
  }

  if (mode === 'reseller') {
    await editMsg(bot, chatId, msgId, '⏳ <i>Memuat data reseller...</i>', { parse_mode: 'HTML' });
    const rows = await allAsync("SELECT u.chat_id, u.saldo, u.created_at, COUNT(t.id) as total_order FROM users u LEFT JOIN transactions t ON t.chat_id=u.chat_id AND t.status='completed' WHERE u.role='reseller' GROUP BY u.chat_id ORDER BY u.saldo DESC LIMIT 25");

    let txt = `┌─────────────────────┐\n│ 💎 DAFTAR RESELLER\n│ Total: ${rows.length} reseller\n└─────────────────────┘\n\n`;
    if (!rows.length) {
      txt += '❌ Belum ada reseller.';
    } else {
      rows.forEach((u, i) => {
        const joined = (u.created_at || '').slice(0, 10) || '-';
        txt += `${i + 1}. 💎 <code>${u.chat_id}</code>\n`;
        txt += `    💰 Rp ${Number(u.saldo).toLocaleString('id-ID')}  📦 ${u.total_order || 0} order\n`;
        txt += `    📅 Join: ${joined}\n\n`;
      });
    }
    await editMsg(bot, chatId, msgId, txt, { parse_mode: 'HTML', reply_markup: backKeyboard() });
    return;
  }

  if (mode === 'top') {
    await editMsg(bot, chatId, msgId, '⏳ <i>Memuat top saldo...</i>', { parse_mode: 'HTML' });
    const rows = await allAsync('SELECT chat_id, saldo, role FROM users ORDER BY saldo DESC LIMIT 10');
    const roleIcon = { admin: '👑', reseller: '💎', members: '👤' };
    let txt = `┌─────────────────────┐\n│ 📊 TOP 10 SALDO\n└─────────────────────┘\n\n`;
    rows.forEach((u, i) => {
      const medal = ['🥇','🥈','🥉'][i] || `${i + 1}.`;
      const icon  = roleIcon[u.role] || '👤';
      txt += `${medal} ${icon} <code>${u.chat_id}</code>\n`;
      txt += `    💰 Rp ${Number(u.saldo).toLocaleString('id-ID')}\n\n`;
    });
    await editMsg(bot, chatId, msgId, txt, { parse_mode: 'HTML', reply_markup: backKeyboard() });
    return;
  }

  /* ── BACKUP ── */
  if (mode === 'backup') {
    const dbPath    = path.join(__dirname, '../data/yanbot.db');
    const backupDir = path.join(__dirname, '../backup');
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir);

    const dateStr  = new Date().toISOString().slice(0, 10);
    const fileName = `backup-${dateStr}-${Date.now()}.db`;
    const dest     = path.join(backupDir, fileName);

    await editMsg(bot, chatId, msgId, '⏳ <b>Membuat backup database...</b>', { parse_mode: 'HTML' });

    db.run('PRAGMA wal_checkpoint(TRUNCATE)', [], async () => {
      try {
        fs.copyFileSync(dbPath, dest);

        const [uRow, tRow] = await Promise.all([
          getAsync('SELECT COUNT(*) as n FROM users'),
          getAsync('SELECT COUNT(*) as n FROM transactions')
        ]);
        const userCount = uRow?.n || 0;
        const txCount   = tRow?.n || 0;

        await editMsg(bot, chatId, msgId,
          `✅ <b>BACKUP BERHASIL</b>\n\n` +
          `┌─────────────────────┐\n` +
          `│ 📁 ${fileName}\n` +
          `│ 👥 Users    : <b>${userCount}</b>\n` +
          `│ 📦 Transaksi: <b>${txCount}</b>\n` +
          `└─────────────────────┘\n\n<i>File dikirim di bawah ini.</i>`,
          { parse_mode: 'HTML', reply_markup: backKeyboard() }
        );
        bot.sendDocument(chatId, dest, {
          caption: `📦 Backup DB — ${userCount} users, ${txCount} transaksi`
        }).catch(err => console.error('[backup] sendDocument:', err.message));

      } catch (err) {
        console.error('[backup]', err.message);
        await editMsg(bot, chatId, msgId,
          `❌ <b>Backup gagal!</b>\n\n<code>${err.message}</code>`,
          { parse_mode: 'HTML', reply_markup: backKeyboard() }
        );
      }
    });
    return;
  }

  /* ── KELOLA SERVER (list + delete) ── */
  if (mode === 'list_server') {
    let servers = [];
    try { servers = require('../data/server'); } catch (e) {}

    if (!servers.length) {
      await editMsg(bot, chatId, msgId,
        `┌─────────────────────┐\n│ 🖥 DAFTAR SERVER\n└─────────────────────┘\n\n❌ Belum ada server terdaftar.\n\nKlik <b>Add Server</b> untuk menambah.`,
        { parse_mode: 'HTML', reply_markup: {
          inline_keyboard: [
            [{ text: '📌 Add Server', callback_data: 'adm_server' }],
            [{ text: '🔙 Kembali ke Menu Admin', callback_data: 'adm_back' }]
          ]
        }}
      );
      return;
    }

    let txt = `┌─────────────────────┐\n│ 🖥 DAFTAR SERVER\n│ Total: ${servers.length} server\n└─────────────────────┘\n\n`;
    const delButtons = [];

    servers.forEach((s, i) => {
      const used  = s.used  || 0;
      const limit = s.limit || 0;
      const pct   = limit > 0 ? Math.round((used / limit) * 100) : 0;
      const bar   = '█'.repeat(Math.round(pct / 10)) + '░'.repeat(10 - Math.round(pct / 10));
      const status = (limit > 0 && used >= limit) ? '🔴 PENUH' : '🟢 Online';
      const mode = s.apiUrl ? '📡 API' : '🔌 SSH';
      txt += `${i + 1}. <b>${s.name}</b> ${status} ${mode}\n`;
      txt += `   🌐 <code>${s.ip}</code>\n`;
      txt += `   [${bar}] ${used}/${limit} (${pct}%)\n\n`;
      delButtons.push([{ text: `🗑 Hapus: ${s.name}`, callback_data: `adm_del_server_${i}` }]);
    });

    await editMsg(bot, chatId, msgId, txt, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          ...delButtons,
          [{ text: '📌 Add Server', callback_data: 'adm_server' }],
          [{ text: '🔙 Kembali ke Menu Admin', callback_data: 'adm_back' }]
        ]
      }
    });
    return;
  }

  /* ── DELETE SERVER ── */
  if (mode === 'del_server') {
    const idx = extra.idx;
    let servers = [];
    try { servers = require('../data/server'); } catch (e) {}

    if (idx < 0 || idx >= servers.length) {
      return editMsg(bot, chatId, msgId, '❌ Server tidak ditemukan.', { reply_markup: backKeyboard() });
    }

    const deleted = servers.splice(idx, 1)[0];
    fs.writeFileSync(serverPath, `const servers = ${JSON.stringify(servers, null, 2)};\n\nmodule.exports = servers;`);
    const resolved = require.resolve('../data/server');
    delete require.cache[resolved];

    await editMsg(bot, chatId, msgId,
      `✅ <b>Server dihapus!</b>\n\n🖥 Nama : ${deleted.name}\n🌐 IP   : ${deleted.ip}\n\nSisa server: ${servers.length}`,
      { parse_mode: 'HTML', reply_markup: backKeyboard() }
    );
    return;
  }

  /* ── STATISTIK INCOME ── */
  if (mode === 'income') {
    await editMsg(bot, chatId, msgId, '⏳ <i>Memuat dashboard income...</i>', { parse_mode: 'HTML' });

    try {
      const [today, month, total, orders, users] = await Promise.all([
        getAsync(`
          SELECT COUNT(*) as tx, COALESCE(SUM(amount),0) as income
          FROM transactions
          WHERE status='completed'
            AND date(created_at)=date('now','localtime')
            AND COALESCE(product_type,'') != 'TOPUP'
        `),
        getAsync(`
          SELECT COUNT(*) as tx, COALESCE(SUM(amount),0) as income
          FROM transactions
          WHERE status='completed'
            AND strftime('%Y-%m', created_at)=strftime('%Y-%m','now','localtime')
            AND COALESCE(product_type,'') != 'TOPUP'
        `),
        getAsync(`
          SELECT COUNT(*) as tx, COALESCE(SUM(amount),0) as income
          FROM transactions
          WHERE status='completed'
            AND COALESCE(product_type,'') != 'TOPUP'
        `),
        getAsync(`
          SELECT COUNT(*) as akun
          FROM transactions
          WHERE status='completed'
            AND COALESCE(product_type,'') NOT IN ('', 'TOPUP')
            AND product_type NOT LIKE 'TRIAL%'
        `),
        getAsync(`SELECT COUNT(*) as total FROM users`)
      ]);

      const txt =
`╭────────────────────⬣
│        📊 DIWAN TUNNELING PANEL
╰────────────────────⬣

💸 Income Hari Ini
└ ${formatRupiah(today?.income)}

📆 Income Bulanan
└ ${formatRupiah(month?.income)}

🏦 Total Income
└ ${formatRupiah(total?.income)}

📦 Total Order
└ ${orders?.akun || 0} Transaksi

👥 User Aktif
└ ${users?.total || 0} User

🟢 Status Bot
└ Online & Stabil

────────────────────
🤖 Powered By Diwantunneling`;

      await editMsg(bot, chatId, msgId, txt, { reply_markup: backKeyboard() });
    } catch (err) {
      console.error('[income dashboard]', err.message);
      await editMsg(bot, chatId, msgId,
        `❌ <b>Gagal memuat statistik income.</b>\n\n<code>${err.message}</code>`,
        { parse_mode: 'HTML', reply_markup: backKeyboard() }
      );
    }
    return;
  }

  /* ── STATISTIK SERVER ── */
  if (mode === 'statistik_server') {
    await editMsg(bot, chatId, msgId, '⏳ <i>Memuat statistik server...</i>', { parse_mode: 'HTML' });
    let servers = [];
    try { servers = require('../data/server'); } catch (e) {}

    db.all(`
      SELECT
        server_ip,
        COUNT(*) as total_akun,
        COUNT(CASE WHEN expired_at > datetime('now','localtime') THEN 1 END) as akun_aktif,
        COUNT(CASE WHEN expired_at <= datetime('now','localtime') THEN 1 END) as akun_expired,
        COUNT(CASE WHEN product_type='SSH'    THEN 1 END) as ssh,
        COUNT(CASE WHEN product_type='VMESS'  THEN 1 END) as vmess,
        COUNT(CASE WHEN product_type='VLESS'  THEN 1 END) as vless,
        COUNT(CASE WHEN product_type='TROJAN' THEN 1 END) as trojan,
        COUNT(CASE WHEN product_type='ZIVPN'  THEN 1 END) as zivpn
      FROM transactions
      WHERE status='completed'
        AND expired_at IS NOT NULL AND expired_at != ''
        AND product_type NOT IN ('', 'TOPUP')
        AND product_type NOT LIKE 'TRIAL%'
        AND product_type NOT LIKE 'RENEW%'
      GROUP BY server_ip
    `, [], async (err, rows) => {
      let txt = `┌─────────────────────┐\n│  📊 STATISTIK PER SERVER\n└─────────────────────┘`;
      if (!rows?.length) {
        txt += '\n\n❌ Belum ada data akun.';
      } else {
        rows.forEach(row => {
          const srv   = servers.find(s => s.ip === row.server_ip);
          const nama  = srv ? srv.name : row.server_ip || 'Unknown';
          const limit = srv?.limit || 0;
          const fill  = limit > 0 ? Math.round((row.akun_aktif / limit) * 100) : 0;
          const bar   = '█'.repeat(Math.round(fill / 10)) + '░'.repeat(10 - Math.round(fill / 10));
          txt +=
`\n\n🖥 <b>${nama}</b>
🌐 <code>${row.server_ip}</code>
[${bar}] ${fill}%
✅ Aktif  : <b>${row.akun_aktif}</b> / ${limit || '∞'}
❌ Expired: <b>${row.akun_expired}</b>  📦 Total: <b>${row.total_akun}</b>
⚪ SSH:${row.ssh} 🔵 VMess:${row.vmess} 🟡 VLess:${row.vless} 🟠 Trojan:${row.trojan} 🟢 ZivPN:${row.zivpn}
${'─'.repeat(30)}`;
        });
      }
      await editMsg(bot, chatId, msgId, txt, { parse_mode: 'HTML', reply_markup: backKeyboard() });
    });
    return;
  }

  /* ── ATUR PROMO ── */
  if (mode === 'atur_promo') {
    const promo = getPromo();
    await editMsg(bot, chatId, msgId,
      `┌─────────────────────┐\n` +
      `│  ⚙️ ATUR PROMO\n` +
      `└─────────────────────┘\n\n` +
      `Status saat ini: ${promo.active ? '🟢 <b>AKTIF</b>' : '🔴 <b>MATI</b>'}\n` +
      `Bonus    : <b>${promo.bonus}%</b>\n` +
      `Min Top Up: <b>Rp ${Number(promo.min).toLocaleString('id-ID')}</b>\n\n` +
      `Ketik nilai baru dengan format:\n` +
      `<code>bonus:20 min:15000</code>\n\n` +
      `<i>Contoh: <code>bonus:30 min:20000</code></i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[{ text: '🔙 Kembali ke Menu Admin', callback_data: 'adm_back' }]]
        }
      }
    );
    sessions[chatId].mode = 'atur_promo';
    sessions[chatId].step = 1;
    return;
  }

  /* ── LIST VOUCHER ── */
  if (mode === 'gen_voucher') {
    await editMsg(bot, chatId, msgId, '⏳ <i>Memuat data voucher...</i>', { parse_mode: 'HTML' });
    const vouchers = await listVouchers();

    let txt =
      `┌─────────────────────┐\n` +
      `│  🎟 VOUCHER SALDO\n` +
      `└─────────────────────┘\n\n`;

    if (!vouchers.length) {
      txt += '📭 Belum ada voucher.\n\n';
    } else {
      vouchers.slice(0, 10).forEach((v, i) => {
        const status = v.is_active ? '🟢' : '🔴';
        txt += `${i + 1}. ${status} <code>${v.code}</code>\n`;
        txt += `    💰 Rp ${Number(v.saldo).toLocaleString('id-ID')}  👥 ${v.claimed_count}/${v.max_claims}\n`;
        txt += `    📅 ${(v.created_at || '').slice(0, 16)}\n\n`;
      });
    }

    txt += `Klik <b>Generate Baru</b> untuk buat voucher.\n<i>Atau klik kode voucher untuk nonaktifkan.</i>`;

    const deactButtons = vouchers.filter(v => v.is_active).slice(0, 5).map(v => ([
      { text: `❌ Nonaktifkan ${v.code}`, callback_data: `adm_deact_voucher_${v.code}` }
    ]));

    await editMsg(bot, chatId, msgId, txt, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          ...deactButtons,
          [{ text: '➕ Generate Voucher Baru', callback_data: 'adm_do_gen_voucher' }],
          [{ text: '🔙 Kembali ke Menu Admin', callback_data: 'adm_back' }]
        ]
      }
    });
    return;
  }

  /* ── NONAKTIFKAN VOUCHER ── */
  if (mode === 'deact_voucher') {
    const code = extra.code;
    await deactivateVoucher(code);
    await editMsg(bot, chatId, msgId,
      `✅ Voucher <code>${code}</code> berhasil dinonaktifkan.`,
      { parse_mode: 'HTML', reply_markup: backKeyboard() }
    );
    return;
  }

  if (mode === 'sync_scripts') {
    await editMsg(bot, chatId, msgId,
      '⏳ <b>Meng-sync scripts ke semua VPS...</b>\n\n<i>Mohon tunggu sebentar...</i>',
      { parse_mode: 'HTML' }
    );

    const scripts = readAllScripts();
    const result = await syncToAllServers();

    if (!result.success) {
      await editMsg(bot, chatId, msgId,
        `❌ <b>Sync Gagal</b>\n\n${result.message}\n\n<i>Pastikan server sudah dikonfigurasi dengan apiUrl dan apiToken di data/server.js</i>`,
        { parse_mode: 'HTML', reply_markup: backKeyboard() }
      );
      return;
    }

    let txt = `┌─────────────────────┐\n│  🔄 SYNC SCRIPTS\n│  📁 ${scripts.length} scripts\n└─────────────────────┘\n\n`;

    for (const r of result.results) {
      if (r.status === 'ok') {
        txt += `✅ <b>${r.server}</b> (${r.ip})\n`;
        txt += `    📤 Berhasil: ${r.synced}  ❌ Gagal: ${r.failed}\n\n`;
      } else {
        txt += `❌ <b>${r.server}</b> (${r.ip})\n`;
        txt += `    Error: ${r.message}\n\n`;
      }
    }

    const allOk = result.results.every(r => r.status === 'ok');
    txt += allOk ? '✅ <b>Semua VPS berhasil di-sync!</b>' : '⚠️ <b>Ada VPS yang gagal, cek detail di atas.</b>';

    await editMsg(bot, chatId, msgId, txt, { parse_mode: 'HTML', reply_markup: backKeyboard() });
    return;
  }

  if (mode === 'promo_on') {
    setPromo(true);
    const promo = getPromo();
    const bonus = promo.bonus || 0;
    const min   = promo.min   || 0;
    const textPromo =
`🔥 <b>PROMO SPESIAL HARI INI!</b> 🔥

💰 Bonus Top Up <b>${bonus}%</b>
📌 Minimal Top Up Rp ${min.toLocaleString('id-ID')}

💸 15K → ${(15000 * (1 + bonus / 100)).toLocaleString('id-ID')}
💸 20K → ${(20000 * (1 + bonus / 100)).toLocaleString('id-ID')}
💸 50K → ${(50000 * (1 + bonus / 100)).toLocaleString('id-ID')}

⚡ Buruan sebelum promo habis!`;

    await editMsg(bot, chatId, msgId,
      `📢 <b>Mengirim broadcast promo ke semua user...</b>\n\n<i>Proses ini berjalan di background.</i>`,
      { parse_mode: 'HTML' }
    );
    broadcastToAll(bot, textPromo).then(sent => {
      console.log(`[admin] Broadcast promo selesai: ${sent} pesan terkirim`);
    });
    setTimeout(() => {
      editMsg(bot, chatId, msgId,
        `✅ <b>PROMO DIAKTIFKAN</b>\n\n🎁 Bonus: <b>${bonus}%</b>\n📌 Minimal: Rp ${min.toLocaleString('id-ID')}\n\n<i>Broadcast sedang berjalan di background.</i>`,
        { parse_mode: 'HTML', reply_markup: backKeyboard() }
      );
    }, 1000);
    return;
  }

  if (mode === 'promo_off') {
    setPromo(false);
    await editMsg(bot, chatId, msgId,
      `❌ <b>PROMO DIMATIKAN</b>\n\nTop up kembali normal, tanpa bonus tambahan.`,
      { parse_mode: 'HTML', reply_markup: backKeyboard() }
    );
    return;
  }
}

/* ══════════════════════════════════════════
   UPDATE STEP (prompt input)
══════════════════════════════════════════ */
function updateStep(bot, chatId) {
  const session = sessions[chatId];
  if (!session) return;
  const { mode, step, data } = session;

  const PROTO_LABEL = {
    ssh: 'SSH/OpenVPN', vmess: 'xRay VMess', vless: 'xRay VLess',
    trojan: 'xRay Trojan', udpzivpn: 'UDP ZivPN'
  };

  let text = '';

  if (mode === 'broadcast') {
    text =
      `┌─────────────────────┐\n` +
      `│  📢 BROADCAST PESAN\n` +
      `└─────────────────────┘\n\n` +
      `Ketik pesan yang ingin dikirim ke <b>SEMUA USER</b>.\n\n` +
      `📝 <i>HTML didukung:</i>\n` +
      `├ <code>&lt;b&gt;tebal&lt;/b&gt;</code>\n` +
      `├ <code>&lt;i&gt;miring&lt;/i&gt;</code>\n` +
      `└ <code>&lt;code&gt;kode&lt;/code&gt;</code>`;
  }

  if (mode === 'add' || mode === 'set') {
    if (step === 1) {
      text =
        `┌─────────────────────┐\n` +
        `│  ${mode === 'add' ? '💰 TAMBAH SALDO' : '👑 SET RESELLER'}\n` +
        `└─────────────────────┘\n\n` +
        `Langkah 1/2\n\n🆔 Masukkan <b>Chat ID</b> user:`;
    }
    if (step === 2) {
      text =
        `┌─────────────────────┐\n` +
        `│  ${mode === 'add' ? '💰 TAMBAH SALDO' : '👑 SET RESELLER'}\n` +
        `└─────────────────────┘\n\n` +
        `Langkah 2/2\n\n🆔 User: <code>${data.userId}</code>\n\n💰 Masukkan <b>jumlah saldo</b> (Rp):`;
    }
  }

  if (mode === 'search') {
    text =
      `┌─────────────────────┐\n` +
      `│  🔍 CARI USER\n` +
      `└─────────────────────┘\n\n` +
      `Masukkan <b>Chat ID</b> user yang ingin dicari:`;
  }

  if (mode === 'restore') {
    text =
      `┌─────────────────────┐\n` +
      `│  📥 RESTORE DATABASE\n` +
      `└─────────────────────┘\n\n` +
      `Kirim file backup <b>.db</b> yang ingin dipulihkan.\n\n` +
      `⚠️ <b>Peringatan:</b>\n` +
      `├ Data users (saldo, role) akan diganti dari backup\n` +
      `└ Transaksi akan di-merge (tidak ada yang hilang)`;
  }

  if (mode === 'server') {
    const steps = [
      { label: 'IP VPS VPN',       hint: 'contoh: 203.194.113.167',       emoji: '🌐' },
      { label: 'Password Root',    hint: 'password SSH root VPS VPN',     emoji: '🔑' },
      { label: 'Nama Server',      hint: 'contoh: SG / ID / JP',          emoji: '🏷' },
      { label: 'Limit Akun',       hint: 'contoh: 90  (maks akun aktif)', emoji: '📦' }
    ];
    const s = steps[step - 1];
    let filled = '';
    if (data.ip)   filled += `\n│  🌐 IP    : ${data.ip}`;
    if (data.name) filled += `\n│  🏷 Nama  : ${data.name}`;

    text =
      `┌─────────────────────┐\n` +
      `│  📌 ADD SERVER (${step}/4)\n` +
      `└─────────────────────┘` +
      filled + `\n\n` +
      `${s.emoji} <b>${s.label}:</b>\n<i>${s.hint}</i>`;

    if (step === 1) {
      text += `\n\n💡 <i>Bot akan otomatis:\n├ Install API di VPS VPN\n├ Generate token\n└ Sync scripts</i>`;
    }
  }

  if (mode === 'gen_voucher_flow') {
    if (step === 1) {
      text =
        `┌─────────────────────┐\n` +
        `│  🎟 GENERATE VOUCHER\n` +
        `└─────────────────────┘\n\n` +
        `Langkah 1/2\n\n💰 Masukkan <b>jumlah saldo</b> voucher (Rp):\n<i>contoh: 4000</i>`;
    }
    if (step === 2) {
      text =
        `┌─────────────────────┐\n` +
        `│  🎟 GENERATE VOUCHER\n` +
        `└─────────────────────┘\n\n` +
        `Langkah 2/2\n\n💰 Saldo  : <b>Rp ${Number(data.saldo).toLocaleString('id-ID')}</b>\n\n` +
        `👥 Untuk berapa <b>user/ID</b> voucher ini berlaku?\n<i>contoh: 2  (artinya hanya 2 user yg bisa claim)</i>`;
    }
  }

  if (mode === 'atur_promo') {
    text =
      `┌─────────────────────┐\n` +
      `│  ⚙️ ATUR PROMO\n` +
      `└─────────────────────┘\n\n` +
      `Ketik nilai baru dengan format:\n` +
      `<code>bonus:20 min:15000</code>\n\n` +
      `<i>bonus = persen bonus (misal 20 = 20%)\nmin = minimal top up (misal 15000)</i>`;
  }

  if (mode === 'set_harga') {
    let prices = {};
    try { prices = require('../data/prices'); } catch (e) {}
    const fR = k => prices.reseller?.[k]?.perDay ? `Rp ${Number(prices.reseller[k].perDay).toLocaleString('id-ID')}` : '-';
    const fM = k => prices.members?.[k]?.perDay  ? `Rp ${Number(prices.members[k].perDay).toLocaleString('id-ID')}`  : '-';

    if (step === 1) {
      text =
        `┌─────────────────────┐\n` +
        `│  💲 SET HARGA VPN\n` +
        `└─────────────────────┘\n\n` +
        `Harga saat ini (per hari):\n` +
        `<code>Protokol  Reseller    Members\n` +
        `SSH       ${fR('ssh').padEnd(11)} ${fM('ssh')}\n` +
        `VMess     ${fR('vmess').padEnd(11)} ${fM('vmess')}\n` +
        `VLess     ${fR('vless').padEnd(11)} ${fM('vless')}\n` +
        `Trojan    ${fR('trojan').padEnd(11)} ${fM('trojan')}\n` +
        `ZivPN     ${fR('udpzivpn').padEnd(11)} ${fM('udpzivpn')}</code>\n\n` +
        `Ketik nama protokol yang mau diubah:\n<b>ssh / vmess / vless / trojan / zivpn</b>`;
    }
    if (step === 2) {
      text =
        `┌─────────────────────┐\n` +
        `│  💲 SET HARGA VPN\n` +
        `└─────────────────────┘\n\n` +
        `Protokol: <b>${PROTO_LABEL[data.protocol] || data.protocol}</b>\n\n` +
        `👑 Harga <b>RESELLER</b> (per hari):\n<i>contoh: 200</i>`;
    }
    if (step === 3) {
      text =
        `┌─────────────────────┐\n` +
        `│  💲 SET HARGA VPN\n` +
        `└─────────────────────┘\n\n` +
        `Protokol  : <b>${PROTO_LABEL[data.protocol] || data.protocol}</b>\n` +
        `Reseller  : Rp ${Number(data.hargaReseller).toLocaleString('id-ID')}/hari\n\n` +
        `👤 Harga <b>MEMBERS</b> (per hari):\n<i>contoh: 205</i>`;
    }
  }

  bot.editMessageText(text, {
    chat_id: chatId,
    message_id: session.msgId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [[{ text: '❌ Batal', callback_data: 'adm_back' }]]
    }
  }).catch(err => console.error('[updateStep]', err.message));
}

/* ══════════════════════════════════════════
   RESTORE DB
══════════════════════════════════════════ */
async function doRestore(bot, chatId, msgId, filePath) {
  try {
    await runAsync(`ATTACH DATABASE ? AS bk`, [filePath]);
    const users = await allAsync(`SELECT * FROM bk.users`);
    let   txs   = [];
    try { txs = await allAsync(`SELECT * FROM bk.transactions`); } catch (_) {}
    await runAsync(`DETACH DATABASE bk`);

    await runAsync(`BEGIN TRANSACTION`);
    try {
      await runAsync(`DELETE FROM users`);
      for (const u of users) {
        await runAsync(
          `INSERT OR REPLACE INTO users (chat_id, saldo, role, created_at) VALUES (?,?,?,?)`,
          [u.chat_id, u.saldo || 0, u.role || 'members', u.created_at]
        );
      }
      for (const t of txs) {
        await runAsync(
          `INSERT OR IGNORE INTO transactions (id, chat_id, order_id, amount, status, created_at, product_type, username, expired_at, server_ip) VALUES (?,?,?,?,?,?,?,?,?,?)`,
          [t.id, t.chat_id, t.order_id, t.amount || 0, t.status || 'pending', t.created_at,
           t.product_type || '', t.username || '', t.expired_at || '', t.server_ip || '']
        );
      }
      await runAsync(`COMMIT`);
    } catch (innerErr) {
      await runAsync(`ROLLBACK`).catch(() => {});
      throw innerErr;
    }

    db.run(`UPDATE users SET role='admin' WHERE chat_id=?`, [OWNER_ID]);
    try { fs.unlinkSync(filePath); } catch (_) {}

    await editMsg(bot, chatId, msgId,
      `✅ <b>RESTORE BERHASIL!</b>\n\n` +
      `┌─────────────────────┐\n` +
      `│ 👥 Users dipulihkan : <b>${users.length}</b>\n` +
      `│ 📦 Transaksi merge  : <b>${txs.length}</b>\n` +
      `└─────────────────────┘\n\n` +
      `Semua saldo dan data user sudah kembali.`,
      { parse_mode: 'HTML', reply_markup: backKeyboard() }
    );

  } catch (err) {
    console.error('[restore] ❌', err.message);
    try { await runAsync(`ROLLBACK`); } catch (_) {}
    try { fs.unlinkSync(filePath); } catch (_) {}
    await editMsg(bot, chatId, msgId,
      `❌ <b>Restore gagal!</b>\n\n<code>${err.message}</code>\n\nPastikan file adalah backup .db yang valid.`,
      { parse_mode: 'HTML', reply_markup: backKeyboard() }
    );
  }
}

/* ══════════════════════════════════════════
   MAIN EXPORT
══════════════════════════════════════════ */
module.exports = (bot) => {

  bot.onText(/\/admin/, async (msg) => {
    const chatId = msg.chat.id;
    if (chatId !== OWNER_ID) return;

    bot.deleteMessage(chatId, msg.message_id).catch(() => {});

    const headerText = await buildAdminHeader().catch(() =>
      `┌─────────────────────┐\n│   🀄 𝗔𝗗𝗠𝗜𝗡 𝗣𝗔𝗡𝗘𝗟 🀄\n└─────────────────────┘\n\nPilih menu di bawah ini:`
    );

    const sent = await bot.sendMessage(chatId, headerText, {
      parse_mode: 'HTML',
      reply_markup: mainKeyboard()
    }).catch(err => { console.error('[/admin]', err.message); return null; });

    if (!sent) return;
    sessions[chatId] = { step: 0, data: {}, msgId: sent.message_id };
  });

  bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    const data   = query.data;

    if (chatId !== OWNER_ID) return;
    if (!data.startsWith('adm_')) return;

    bot.answerCallbackQuery(query.id).catch(() => {});

    const mode  = data.replace('adm_', '');
    const msgId = query.message.message_id;

    /* noop (no-action, e.g. page indicator button) */
    if (mode === 'noop') return;

    /* ── BACK ── */
    if (mode === 'back') {
      delete sessions[chatId];
      sessions[chatId] = { step: 0, data: {}, msgId };

      const headerText = await buildAdminHeader().catch(() =>
        `┌─────────────────────┐\n│   🀄 𝗔𝗗𝗠𝗜𝗡 𝗣𝗔𝗡𝗘𝗟 🀄\n└─────────────────────┘\n\nPilih menu di bawah ini:`
      );
      return editMsg(bot, chatId, msgId, headerText, {
        parse_mode: 'HTML',
        reply_markup: mainKeyboard()
      });
    }

    /* ── PAGINATION DAFTAR MEMBERS adm_members_p_N ── */
    if (mode.startsWith('members_p_')) {
      const page = parseInt(mode.replace('members_p_', '')) || 0;
      sessions[chatId] = { step: 0, data: {}, msgId, mode: 'members_p' };
      return handleInstant(bot, chatId, msgId, 'members_p', { page });
    }

    /* ── DELETE SERVER adm_del_server_N ── */
    if (mode.startsWith('del_server_')) {
      const idx = parseInt(mode.replace('del_server_', ''));
      sessions[chatId] = { step: 0, data: {}, msgId, mode: 'del_server' };
      return handleInstant(bot, chatId, msgId, 'del_server', { idx });
    }

    sessions[chatId] = { step: 0, data: {}, msgId, mode };

    const instantModes = ['reseller', 'top', 'backup', 'income', 'statistik_server', 'list_server', 'promo_on', 'promo_off', 'atur_promo', 'gen_voucher', 'sync_scripts'];
    if (instantModes.includes(mode)) return handleInstant(bot, chatId, msgId, mode);

    /* ── START GENERATE VOUCHER FLOW ── */
    if (mode === 'do_gen_voucher') {
      sessions[chatId] = { step: 1, data: {}, msgId, mode: 'gen_voucher_flow' };
      return updateStep(bot, chatId);
    }

    /* ── DEACTIVATE VOUCHER ── */
    if (mode.startsWith('deact_voucher_')) {
      const code = mode.replace('deact_voucher_', '');
      sessions[chatId] = { step: 0, data: {}, msgId, mode: 'deact_voucher' };
      return handleInstant(bot, chatId, msgId, 'deact_voucher', { code });
    }

    const inputModes = ['broadcast', 'server', 'set', 'search', 'set_harga', 'restore'];
    if (inputModes.includes(mode)) {
      sessions[chatId].step = 1;
      return updateStep(bot, chatId);
    }
  });

  bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    if (chatId !== OWNER_ID) return;

    const session = sessions[chatId];
    if (!session?.mode) return;

    const { mode, step, data, msgId } = session;

    bot.deleteMessage(chatId, msg.message_id).catch(() => {});

    /* ── RESTORE: terima file .db ── */
    if (mode === 'restore') {
      if (!msg.document) {
        bot.sendMessage(chatId, '❌ Kirim file backup <b>.db</b>, bukan teks.', { parse_mode: 'HTML' }).catch(() => {});
        return;
      }

      const fileId    = msg.document.file_id;
      const fileName  = msg.document.file_name || 'restore.db';
      const backupDir = path.join(__dirname, '../backup');
      if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir);

      delete sessions[chatId];

      await editMsg(bot, chatId, msgId,
        `⏳ <b>Mengunduh file backup...</b>\n\n<i>${fileName}</i>`,
        { parse_mode: 'HTML' }
      );

      try {
        const dlPath = await bot.downloadFile(fileId, backupDir);
        await editMsg(bot, chatId, msgId, '⏳ <b>Memulihkan data database...</b>', { parse_mode: 'HTML' });
        await doRestore(bot, chatId, msgId, dlPath);
      } catch (err) {
        console.error('[restore download]', err.message);
        await editMsg(bot, chatId, msgId,
          `❌ <b>Gagal unduh file!</b>\n\n<code>${err.message}</code>`,
          { parse_mode: 'HTML', reply_markup: backKeyboard() }
        );
      }
      return;
    }

    const text = msg.text?.trim() || '';
    if (!text) return;

    /* ── BROADCAST ── */
    if (mode === 'broadcast') {
      delete sessions[chatId];
      await editMsg(bot, chatId, msgId,
        `📢 <b>Mengirim broadcast ke semua user...</b>\n\n<i>Proses berjalan di background.</i>`,
        { parse_mode: 'HTML' }
      );
      broadcastToAll(bot, text).then(sent => {
        console.log(`[admin] Broadcast selesai: ${sent} pesan terkirim`);
        editMsg(bot, chatId, msgId,
          `✅ <b>Broadcast Selesai!</b>\n\n📨 Berhasil dikirim ke <b>${sent}</b> user.`,
          { parse_mode: 'HTML', reply_markup: backKeyboard() }
        );
      });
      return;
    }

    /* ── ADD SALDO / SET RESELLER ── */
    if (mode === 'add' || mode === 'set') {
      if (step === 1) {
        const userId = parseInt(text);
        if (isNaN(userId)) return bot.sendMessage(chatId, '❌ Chat ID tidak valid.').catch(() => {});
        sessions[chatId].data.userId = userId;
        sessions[chatId].step = 2;
        return updateStep(bot, chatId);
      }
      if (step === 2) {
        const amount = parseInt(text);
        if (isNaN(amount) || amount <= 0) return bot.sendMessage(chatId, '❌ Jumlah tidak valid.').catch(() => {});
        const userId = data.userId;
        delete sessions[chatId];

        db.run("INSERT OR IGNORE INTO users (chat_id, saldo, role, created_at) VALUES (?, 0, 'members', datetime('now','localtime'))", [userId]);

        if (mode === 'add') {
          db.run('UPDATE users SET saldo = saldo + ? WHERE chat_id=?', [amount, userId], async function(err) {
            if (err || this.changes === 0) {
              return editMsg(bot, chatId, msgId, `❌ User <code>${userId}</code> tidak ditemukan.`, { parse_mode: 'HTML', reply_markup: backKeyboard() });
            }
            db.get('SELECT saldo FROM users WHERE chat_id=?', [userId], async (e, row) => {
              await editMsg(bot, chatId, msgId,
                `✅ <b>Saldo Ditambahkan!</b>\n\n` +
                `┌─────────────────────┐\n` +
                `│ 🆔 User   : <code>${userId}</code>\n` +
                `│ ➕ Tambah : +Rp ${amount.toLocaleString('id-ID')}\n` +
                `│ 💳 Saldo  : Rp ${Number(row?.saldo || 0).toLocaleString('id-ID')}\n` +
                `└─────────────────────┘`,
                { parse_mode: 'HTML', reply_markup: backKeyboard() }
              );
              bot.sendMessage(userId,
                `💰 Saldo kamu ditambahkan sebesar <b>Rp ${amount.toLocaleString('id-ID')}</b> oleh admin.\nSaldo sekarang: <b>Rp ${Number(row?.saldo || 0).toLocaleString('id-ID')}</b>`,
                { parse_mode: 'HTML' }
              ).catch(() => {});
            });
          });
        } else {
          db.run("UPDATE users SET role='reseller', saldo=saldo+? WHERE chat_id=?", [amount, userId], async function(err) {
            if (err || this.changes === 0) {
              return editMsg(bot, chatId, msgId, `❌ User <code>${userId}</code> tidak ditemukan.`, { parse_mode: 'HTML', reply_markup: backKeyboard() });
            }
            await editMsg(bot, chatId, msgId,
              `✅ <b>Set Reseller Berhasil!</b>\n\n` +
              `┌─────────────────────┐\n` +
              `│ 🆔 User   : <code>${userId}</code>\n` +
              `│ 👑 Role   : RESELLER\n` +
              `│ ➕ Saldo  : +Rp ${amount.toLocaleString('id-ID')}\n` +
              `└─────────────────────┘`,
              { parse_mode: 'HTML', reply_markup: backKeyboard() }
            );
            bot.sendMessage(userId,
              `👑 Selamat! Kamu telah diupgrade menjadi <b>RESELLER</b>!\n💰 Saldo +Rp ${amount.toLocaleString('id-ID')}`,
              { parse_mode: 'HTML' }
            ).catch(() => {});
          });
        }
        return;
      }
    }

    /* ── SEARCH USER ── */
    if (mode === 'search') {
      const userId = parseInt(text);
      delete sessions[chatId];
      if (isNaN(userId)) return editMsg(bot, chatId, msgId, '❌ Chat ID tidak valid.', { reply_markup: backKeyboard() });

      db.get('SELECT chat_id, saldo, role, created_at FROM users WHERE chat_id=?', [userId], async (err, row) => {
        if (!row) return editMsg(bot, chatId, msgId,
          `❌ User <code>${userId}</code> tidak ditemukan.`,
          { parse_mode: 'HTML', reply_markup: backKeyboard() }
        );
        db.get("SELECT COUNT(*) as total, COALESCE(SUM(amount),0) as total_spend FROM transactions WHERE chat_id=? AND status='completed'", [userId], async (e2, trx) => {
          const roleIcon = { admin: '👑', reseller: '💎', members: '👤' }[row.role] || '👤';
          await editMsg(bot, chatId, msgId,
            `┌─────────────────────┐\n` +
            `│  🔍 INFO USER\n` +
            `└─────────────────────┘\n\n` +
            `${roleIcon} <b>${(row.role || '').toUpperCase()}</b>\n` +
            `🆔 Chat ID   : <code>${row.chat_id}</code>\n` +
            `💰 Saldo     : <b>Rp ${Number(row.saldo).toLocaleString('id-ID')}</b>\n` +
            `📦 Total Order : <b>${trx?.total || 0}</b>\n` +
            `💸 Total Spend : <b>Rp ${Number(trx?.total_spend || 0).toLocaleString('id-ID')}</b>\n` +
            `📅 Bergabung : <b>${(row.created_at || '-').slice(0, 10)}</b>`,
            { parse_mode: 'HTML', reply_markup: backKeyboard() }
          );
        });
      });
      return;
    }

    /* ── ADD SERVER (auto-install API via SSH) ── */
    if (mode === 'server') {
      if (step >= 1 && step <= 4) {
        const fields = ['ip', 'pass', 'name', 'limit'];
        const field  = fields[step - 1];
        if (field === 'limit') {
          const n = parseInt(text);
          data[field] = isNaN(n) ? 90 : n;
        } else {
          data[field] = text.trim();
        }

        if (step === 2) {
          try { await bot.deleteMessage(chatId, msg.message_id); } catch {}
        }

        if (step < 4) {
          sessions[chatId].step++;
          return updateStep(bot, chatId);
        }

        delete sessions[chatId];

        const crypto = require('crypto');
        const apiToken = crypto.randomBytes(24).toString('hex');
        const apiPort = 3456;

        await editMsg(bot, chatId, msgId,
          `⏳ <b>Menginstall API Server di ${data.ip}...</b>\n\n` +
          `┌─────────────────────┐\n` +
          `│ 🌐 IP    : ${data.ip}\n` +
          `│ 🏷 Nama  : ${data.name}\n` +
          `│ 📦 Limit : ${data.limit}\n` +
          `└─────────────────────┘\n\n` +
          `🔄 Connecting via SSH...\n` +
          `<i>Ini bisa memakan waktu 1-2 menit</i>`,
          { parse_mode: 'HTML' }
        );

        try {
          const result = await installApiRemote(data.ip, data.pass, apiToken, apiPort, async (progress) => {
            try {
              await editMsg(bot, chatId, msgId,
                `⏳ <b>Menginstall API di ${data.ip}...</b>\n\n${progress}`,
                { parse_mode: 'HTML' }
              );
            } catch {}
          });

          if (!result.success) {
            let debugInfo = '';
            if (result.output) {
              const lines = result.output.split('\n').filter(l => l.trim()).slice(-15);
              debugInfo = `\n\n<b>Log:</b>\n<code>${lines.join('\n').slice(0, 1500)}</code>`;
            }
            await editMsg(bot, chatId, msgId,
              `❌ <b>Gagal install API di ${data.ip}</b>\n\n` +
              `<i>API service tidak bisa start.</i>${debugInfo}\n\n` +
              `<i>Cek manual:\nssh root@${data.ip}\njournalctl -u vps-api -n 20</i>`,
              { parse_mode: 'HTML', reply_markup: backKeyboard() }
            );
            return;
          }

          const newServer = {
            name: data.name,
            ip: data.ip,
            username: 'root',
            pass: '',
            apiUrl: `http://${data.ip}:${apiPort}`,
            apiToken: apiToken,
            limit: data.limit,
            used: 0
          };

          let servers = [];
          try { servers = require('../data/server'); } catch (e) {}
          servers.push(newServer);
          fs.writeFileSync(serverPath, `const servers = ${JSON.stringify(servers, null, 2)};\n\nmodule.exports = servers;`);

          const resolvedPath = require.resolve('../data/server');
          delete require.cache[resolvedPath];

          await editMsg(bot, chatId, msgId,
            `✅ <b>API Terinstall!</b> Syncing scripts...`,
            { parse_mode: 'HTML' }
          );

          let syncResult = '';
          try {
            const scripts = readAllScripts();
            if (scripts.length > 0) {
              const axios = require('axios');
              const resp = await axios.post(`${newServer.apiUrl}/api/sync`, { scripts }, {
                headers: { 'X-Api-Token': apiToken },
                timeout: 30000
              });
              if (resp.data?.success) {
                syncResult = `\n│ 🔄 Scripts : ${resp.data.synced} synced ✔`;
              } else {
                syncResult = `\n│ 🔄 Scripts : ⚠️ Sync gagal`;
              }
            } else {
              syncResult = `\n│ 🔄 Scripts : 0 (kosong)`;
            }
          } catch (e) {
            syncResult = `\n│ 🔄 Scripts : ⚠️ ${e.message}`;
          }

          await editMsg(bot, chatId, msgId,
            `✅ <b>Server Berhasil Ditambahkan!</b>\n\n` +
            `┌─────────────────────┐\n` +
            `│ 🏷 Nama  : ${data.name}\n` +
            `│ 🌐 IP    : <code>${data.ip}</code>\n` +
            `│ 📦 Limit : ${data.limit} akun\n` +
            `│ 📡 API   : 🟢 Online` +
            syncResult + `\n` +
            `└─────────────────────┘\n\n` +
            `Total server: ${servers.length}\n\n` +
            `🔑 <i>Token otomatis di-generate & disimpan.</i>\n` +
            `<i>Password SSH tidak disimpan.</i>`,
            { parse_mode: 'HTML', reply_markup: backKeyboard() }
          );

        } catch (err) {
          let errMsg = err.message || 'Unknown error';
          if (errMsg.includes('Authentication')) errMsg = 'Password root salah';
          else if (errMsg.includes('Timeout') || errMsg.includes('timeout')) errMsg = 'Timeout — VPS tidak merespon';
          else if (errMsg.includes('ECONNREFUSED')) errMsg = 'Koneksi ditolak — cek IP & port 22';
          else if (errMsg.includes('EHOSTUNREACH')) errMsg = 'VPS tidak bisa dijangkau';

          await editMsg(bot, chatId, msgId,
            `❌ <b>Gagal install API di ${data.ip}</b>\n\n` +
            `Error: ${errMsg}\n\n` +
            `<i>Pastikan:\n├ IP benar\n├ Password root benar\n├ Port 22 (SSH) terbuka\n└ VPS bisa diakses</i>`,
            { parse_mode: 'HTML', reply_markup: backKeyboard() }
          );
        }
      }
      return;
    }

    /* ── ATUR PROMO ── */
    if (mode === 'atur_promo') {
      delete sessions[chatId];
      const match = text.match(/bonus:(\d+)\s+min:(\d+)/i);
      if (!match) {
        return bot.sendMessage(chatId,
          `❌ Format salah.\nGunakan: <code>bonus:20 min:15000</code>`,
          { parse_mode: 'HTML' }
        ).catch(() => {});
      }
      const bonus = parseInt(match[1]);
      const min   = parseInt(match[2]);
      if (bonus < 0 || bonus > 200) {
        return bot.sendMessage(chatId, '❌ Bonus harus antara 0-200%').catch(() => {});
      }
      updatePromo(bonus, min);

      await editMsg(bot, chatId, msgId,
        `✅ <b>Pengaturan Promo Disimpan!</b>\n\n` +
        `┌─────────────────────┐\n` +
        `│ 🎁 Bonus    : <b>${bonus}%</b>\n` +
        `│ 💰 Min Top Up: <b>Rp ${Number(min).toLocaleString('id-ID')}</b>\n` +
        `└─────────────────────┘\n\n` +
        `Gunakan tombol <b>Promo ON/OFF</b> untuk mengaktifkan.`,
        { parse_mode: 'HTML', reply_markup: backKeyboard() }
      );
      return;
    }

    /* ── GENERATE VOUCHER FLOW ── */
    if (mode === 'gen_voucher_flow') {
      if (step === 1) {
        const saldo = parseInt(text);
        if (isNaN(saldo) || saldo <= 0) {
          return bot.sendMessage(chatId, '❌ Masukkan angka saldo yang valid.').catch(() => {});
        }
        sessions[chatId].data.saldo = saldo;
        sessions[chatId].step = 2;
        return updateStep(bot, chatId);
      }
      if (step === 2) {
        const maxClaims = parseInt(text);
        if (isNaN(maxClaims) || maxClaims <= 0) {
          return bot.sendMessage(chatId, '❌ Masukkan jumlah user yang valid.').catch(() => {});
        }
        const { saldo } = data;
        delete sessions[chatId];

        try {
          const code = await createVoucher(saldo, maxClaims);
          await editMsg(bot, chatId, msgId,
            `✅ <b>Voucher Berhasil Dibuat!</b>\n\n` +
            `┌─────────────────────┐\n` +
            `│ 🎟 Kode  : <code>${code}</code>\n` +
            `│ 💰 Saldo : <b>Rp ${Number(saldo).toLocaleString('id-ID')}</b>\n` +
            `│ 👥 Max   : <b>${maxClaims} user</b>\n` +
            `└─────────────────────┘\n\n` +
            `Bagikan kode voucher di atas kepada user.\nUser bisa claim di menu <b>Claim Saldo Gratis</b>.`,
            { parse_mode: 'HTML', reply_markup: backKeyboard() }
          );
        } catch (err) {
          await editMsg(bot, chatId, msgId,
            `❌ Gagal generate voucher: ${err.message}`,
            { parse_mode: 'HTML', reply_markup: backKeyboard() }
          );
        }
        return;
      }
    }

    /* ── SET HARGA ── */
    if (mode === 'set_harga') {
      if (step === 1) {
        const protoMap = { ssh: 'ssh', vmess: 'vmess', vless: 'vless', trojan: 'trojan', zivpn: 'udpzivpn' };
        const protocol = protoMap[text.toLowerCase()];
        if (!protocol) return bot.sendMessage(chatId, '❌ Protokol tidak valid. Pilih: ssh / vmess / vless / trojan / zivpn').catch(() => {});
        sessions[chatId].data.protocol = protocol;
        sessions[chatId].step = 2;
        return updateStep(bot, chatId);
      }
      if (step === 2) {
        const harga = parseInt(text);
        if (isNaN(harga) || harga < 0) return bot.sendMessage(chatId, '❌ Harga tidak valid.').catch(() => {});
        sessions[chatId].data.hargaReseller = harga;
        sessions[chatId].step = 3;
        return updateStep(bot, chatId);
      }
      if (step === 3) {
        const harga = parseInt(text);
        if (isNaN(harga) || harga < 0) return bot.sendMessage(chatId, '❌ Harga tidak valid.').catch(() => {});

        const protocol = data.protocol;
        let prices = {};
        try {
          const pPath = require.resolve('../data/prices');
          delete require.cache[pPath];
          prices = require('../data/prices');
        } catch (e) {}

        prices.reseller = prices.reseller || {};
        prices.members  = prices.members  || {};
        prices.reseller[protocol] = { perDay: data.hargaReseller };
        prices.members[protocol]  = { perDay: harga };

        const pricesPath = path.join(__dirname, '../data/prices.js');
        fs.writeFileSync(pricesPath, `module.exports = ${JSON.stringify(prices, null, 2)};\n`);

        const rPath = require.resolve('../data/prices');
        delete require.cache[rPath];

        delete sessions[chatId];

        const PROTO_LABEL = { ssh: 'SSH', vmess: 'VMess', vless: 'VLess', trojan: 'Trojan', udpzivpn: 'ZivPN' };
        await editMsg(bot, chatId, msgId,
          `✅ <b>Harga Berhasil Diupdate!</b>\n\n` +
          `┌─────────────────────┐\n` +
          `│ 💲 ${PROTO_LABEL[protocol] || protocol}\n` +
          `│ 👑 Reseller : Rp ${data.hargaReseller.toLocaleString('id-ID')}/hari\n` +
          `│ 👤 Members  : Rp ${harga.toLocaleString('id-ID')}/hari\n` +
          `└─────────────────────┘`,
          { parse_mode: 'HTML', reply_markup: backKeyboard() }
        );
      }
      return;
    }
  });
};
