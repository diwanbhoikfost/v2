// utils/logger.js — Structured logger (file + console)
// Gantikan semua console.log/warn/error dengan logger ini
'use strict';

const fs   = require('fs');
const path = require('path');

const LOG_DIR  = path.join(__dirname, '../logs');
const LOG_FILE = path.join(LOG_DIR, 'bot.log');
const ERR_FILE = path.join(LOG_DIR, 'error.log');
const MAX_SIZE = 5 * 1024 * 1024; // 5MB per file

/* Buat folder logs jika belum ada */
try { fs.mkdirSync(LOG_DIR, { recursive: true }); } catch (_) {}

function timestamp() {
  return new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hour12: false
  }).replace(/(\d+)\/(\d+)\/(\d+),/, '$3-$2-$1');
}

function rotate(file) {
  try {
    if (fs.existsSync(file) && fs.statSync(file).size > MAX_SIZE) {
      fs.renameSync(file, file + '.old');
    }
  } catch (_) {}
}

function write(file, line) {
  rotate(file);
  try { fs.appendFileSync(file, line + '\n'); } catch (_) {}
}

function format(level, tag, ...args) {
  const parts = args.map(a => (typeof a === 'object' ? JSON.stringify(a) : String(a)));
  return `[${timestamp()}] [${level}] [${tag}] ${parts.join(' ')}`;
}

const logger = {
  info(tag, ...args) {
    const line = format('INFO ', tag, ...args);
    console.log(line);
    write(LOG_FILE, line);
  },
  warn(tag, ...args) {
    const line = format('WARN ', tag, ...args);
    console.warn(line);
    write(LOG_FILE, line);
  },
  error(tag, ...args) {
    const line = format('ERROR', tag, ...args);
    console.error(line);
    write(LOG_FILE, line);
    write(ERR_FILE, line);
  },
  debug(tag, ...args) {
    if (process.env.NODE_ENV === 'production') return;
    const line = format('DEBUG', tag, ...args);
    console.log(line);
  }
};

module.exports = logger;
