// utils/encrypt.js — AES-256-CBC enkripsi/dekripsi untuk data sensitif
// Digunakan untuk mengenkripsi password/apiToken server di server.js
'use strict';

const crypto = require('crypto');

const ALGO    = 'aes-256-cbc';
const KEY_LEN = 32;
const IV_LEN  = 16;

/**
 * Ambil encryption key dari env var.
 * Set di .avars.json: "encrypt_key": "32-char-random-string"
 * Atau env: ENCRYPT_KEY=...
 */
function getKey() {
  let raw = process.env.ENCRYPT_KEY;
  if (!raw) {
    try {
      const fs   = require('fs');
      const path = require('path');
      const cfg  = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8'));
      raw = cfg.encrypt_key;
    } catch (_) {}
  }
  if (!raw) {
    /* Fallback: derive dari bot token (tidak ideal, tapi lebih baik dari plain) */
    try {
      const fs   = require('fs');
      const path = require('path');
      const cfg  = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8'));
      raw = cfg.token || 'default-fallback-key-change-this!!';
    } catch (_) {
      raw = 'default-fallback-key-change-this!!';
    }
  }
  /* Pad / trim ke 32 byte */
  return Buffer.from(raw.padEnd(KEY_LEN, '0').slice(0, KEY_LEN));
}

/**
 * Enkripsi string → "iv:encrypted" (hex format)
 * @param {string} plaintext
 * @returns {string}
 */
function encrypt(plaintext) {
  try {
    const key = getKey();
    const iv  = crypto.randomBytes(IV_LEN);
    const cipher = crypto.createCipheriv(ALGO, key, iv);
    const enc = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
    return iv.toString('hex') + ':' + enc.toString('hex');
  } catch (e) {
    console.error('[encrypt] ❌ Gagal enkripsi:', e.message);
    return plaintext; // fallback plain
  }
}

/**
 * Dekripsi "iv:encrypted" → string asli
 * @param {string} ciphertext — format "iv:encrypted"
 * @returns {string}
 */
function decrypt(ciphertext) {
  if (!ciphertext || !ciphertext.includes(':')) return ciphertext;
  try {
    const key  = getKey();
    const [ivHex, encHex] = ciphertext.split(':');
    const iv      = Buffer.from(ivHex, 'hex');
    const encBuf  = Buffer.from(encHex, 'hex');
    const decipher = crypto.createDecipheriv(ALGO, key, iv);
    return Buffer.concat([decipher.update(encBuf), decipher.final()]).toString('utf8');
  } catch (e) {
    console.error('[encrypt] ❌ Gagal dekripsi:', e.message);
    return ciphertext; // return as-is jika gagal
  }
}

/**
 * Cek apakah string sudah terenkripsi (format iv:hex)
 * @param {string} str
 * @returns {boolean}
 */
function isEncrypted(str) {
  if (!str || typeof str !== 'string') return false;
  const parts = str.split(':');
  return parts.length === 2 && parts[0].length === 32 && /^[0-9a-f]+$/.test(parts[0]);
}

/**
 * Enkripsi hanya jika belum terenkripsi
 */
function encryptIfNeeded(str) {
  if (!str || isEncrypted(str)) return str;
  return encrypt(str);
}

/**
 * Dekripsi hanya jika memang terenkripsi
 */
function decryptIfNeeded(str) {
  if (!str || !isEncrypted(str)) return str;
  return decrypt(str);
}

module.exports = { encrypt, decrypt, isEncrypted, encryptIfNeeded, decryptIfNeeded };
