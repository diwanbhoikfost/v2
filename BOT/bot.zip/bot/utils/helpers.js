// utils/helpers.js — Shared helper functions
// Dipakai oleh: create.js, renew.js, triall.js, ssh-exec.js
'use strict';

/**
 * Bersihkan noise dari output SSH (warning locale, tput, dsb)
 * @param {string} raw
 * @returns {string}
 */
function cleanOutput(raw) {
  return (raw || '')
    .split('\n')
    .filter(l => {
      const t = l.trim();
      if (!t) return false;
      if (/TERM environment/i.test(t)) return false;
      if (/tput:/i.test(t))            return false;
      if (/setlocale/i.test(t))        return false;
      if (/cannot change locale/i.test(t)) return false;
      if (/^bash:.*warning:/i.test(t)) return false;
      return true;
    })
    .join('\n')
    .trim();
}

/**
 * Progress bar untuk animasi pembuatan akun
 * @param {number} pct - 0 sampai 100
 * @param {string} label - teks di atas progress bar (HTML)
 * @returns {string}
 */
function buildProgress(pct, label) {
  const total  = 10;
  const filled = Math.max(0, Math.min(total, Math.round(pct / 10)));
  const bar    = '▰'.repeat(filled) + '▱'.repeat(total - filled);
  return `${label}\n<code>${bar}</code>  <b>${pct}%</b>`;
}

/**
 * Format angka ke format Rupiah
 * @param {number} n
 * @returns {string}
 */
function formatRp(n) {
  return 'Rp ' + Number(n).toLocaleString('id-ID');
}

module.exports = { cleanOutput, buildProgress, formatRp };
