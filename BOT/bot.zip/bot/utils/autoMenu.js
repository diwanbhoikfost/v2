// utils/autoMenu.js — Premium Auto Menu UI
'use strict';

function autoMenu(bot, chatId, delayMs = 2000) {
  setTimeout(() => {
    bot.sendMessage(
      chatId,
`╭─────────────────────────────╮
│      ⚡ DIWAN TUNNELING      
│     PREMIUM VPN SERVICE     
╰─────────────────────────────╯

✅ <b>Akun berhasil dibuat!</b>

Terima kasih telah menggunakan
<b>Diwan Tunneling</b>.

🚀 High Speed Connection
🔒 Private & Secure
📡 Stable 24/7
🎮 Gaming Optimized
🌍 SG & ID Premium Server

━━━━━━━━━━━━━━━━━━━━━━
👇 <b>Pilih menu di bawah</b>
━━━━━━━━━━━━━━━━━━━━━━`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '📝 Order Akun',
                callback_data: 'create_menu'
              },
              {
                text: '🎁 Trial',
                callback_data: 'triall_menu'
              }
            ],
            [
              {
                text: '🇸🇬 Singapore',
                callback_data: 'server_sg'
              },
              {
                text: '🇮🇩 Indonesia',
                callback_data: 'server_id'
              }
            ],
            [
              {
                text: '🎮 Gaming',
                callback_data: 'gaming_info'
              },
              {
                text: '📱 Sosial Media',
                callback_data: 'sosmed_info'
              }
            ],
            [
              {
                text: '🏠 Menu Utama',
                callback_data: 'menu_back'
              }
            ]
          ]
        }
      }
    ).catch(() => {});
  }, delayMs);
}

module.exports = { autoMenu };