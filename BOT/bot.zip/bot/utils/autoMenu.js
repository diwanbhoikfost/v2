// utils/autoMenu.js — Premium Auto Menu UI
'use strict';

function autoMenu(bot, chatId, delayMs = 2000) {
  setTimeout(() => {
    bot.sendMessage(
      chatId,
`╔══════════════════════════════╗
║      ⚡ PT DN TUNNELING ⚡     ║
╠══════════════════════════════╣
║  ✅ Akun berhasil dibuat!     ║
║                              ║
║  🌍 Server SG & ID Premium   ║
║  🎮 Support Gaming           ║
║  📱 Support Sosmed           ║
║  🔒 Fast • Stable • Secure   ║
╚══════════════════════════════╝

📋 <b>Pilih menu berikutnya:</b>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '📝 Order Akun Baru',
                callback_data: 'create_menu'
              }
            ],
            [
              {
                text: '🎁 Trial Gratis',
                callback_data: 'triall_menu'
              }
            ],
            [
              {
                text: '🌐 Server Singapore',
                callback_data: 'server_sg'
              },
              {
                text: '🇮🇩 Server Indonesia',
                callback_data: 'server_id'
              }
            ],
            [
              {
                text: '🎮 Support Gaming',
                callback_data: 'gaming_info'
              },
              {
                text: '📱 Support Sosmed',
                callback_data: 'sosmed_info'
              }
            ],
            [
              {
                text: '🏠 Menu Utama',
                callback_data: 'menu_back'
              }
            ]
          ]
        }
      }
    ).catch(() => {});
  }, delayMs);
}

module.exports = { autoMenu };
