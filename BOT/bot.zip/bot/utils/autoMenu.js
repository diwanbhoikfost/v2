// utils/autoMenu.js — kirim quick-action menu setelah akun selesai dibuat
'use strict';

function autoMenu(bot, chatId, delayMs = 2000) {
  setTimeout(() => {
    bot.sendMessage(chatId, '🔥 <b>Order berhasil diproses!</b>\n\nSilakan pilih menu berikut:', {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🛒 Order Lagi', callback_data: 'create_menu' }],
          [{ text: '🎁 Trial Gratis', callback_data: 'triall_menu' }],
          [{ text: '🏠 Kembali Ke Menu',       callback_data: 'menu_back'   }]
        ]
      }
    }).catch(() => {});
  }, delayMs);
}

module.exports = { autoMenu };
