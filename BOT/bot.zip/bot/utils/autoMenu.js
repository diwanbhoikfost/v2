// utils/autoMenu.js
'use strict';

function autoMenu(bot, chatId, delayMs = 2000) {
  setTimeout(() => {
    bot.sendMessage(
      chatId,
`╭──────────────────────────╮
        🚀 <b>DIWAN TUNNELING</b>
╰──────────────────────────╯

<blockquote>✅ <b>Akun berhasil dibuat!</b></blockquote>

⚡ <b>Premium VPN & Tunneling</b>

🌐 Server :
   🇮🇩 Indonesia
   🇸🇬 Singapore

✨ <b>Keunggulan</b>
├ ⚡ Kecepatan tinggi
├ 🔒 Aman & Stabil
├ 🎮 Support Gaming
├ 📱 Support Sosmed
└ 🎬 Support Streaming

━━━━━━━━━━━━━━━━━━━━
<b>Silakan pilih layanan di bawah.</b>`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "🛒 ORDER PREMIUM",
                callback_data: "create_menu"
              }
            ],
            [
              {
                text: "🎁 TRIAL GRATIS",
                callback_data: "triall_menu"
              }
            ],
            [
              {
                text: "🇮🇩 SERVER ID",
                callback_data: "server_id"
              },
              {
                text: "🇸🇬 SERVER SG",
                callback_data: "server_sg"
              }
            ],
            [
              {
                text: "🎮 GAMING",
                callback_data: "gaming_info"
              },
              {
                text: "📱 SOSMED",
                callback_data: "sosmed_info"
              }
            ],
            [
              {
                text: "💎 MEMBER VIP",
                callback_data: "vip_menu"
              }
            ],
            [
              {
                text: "👨‍💻 ADMIN",
                url: "https://t.me/diwantunneling"
              },
              {
                text: "🏠 MENU",
                callback_data: "menu_back"
              }
            ]
          ]
        }
      }
    ).catch(() => {});
  }, delayMs);
}

module.exports = { autoMenu };