// cmd/menu_deposit.js
'use strict';

module.exports = function menuDepositCmd(bot, chatId, msgId) {
  const text = `
💳 *TOP UP SALDO*

Selamat datang di menu top up saldo.

📌 *Minimal Top Up:* *Rp10.000*
⚡ Saldo akan masuk *otomatis* setelah pembayaran QRIS berhasil.
💰 Pilih nominal yang tersedia atau gunakan nominal kustom.

👇 *Silakan pilih nominal di bawah ini:*`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: "💵 10K", callback_data: "deposit_10000" },
        { text: "💵 15K", callback_data: "deposit_15000" }
      ],
      [
        { text: "💰 20K", callback_data: "deposit_20000" },
        { text: "💎 30K", callback_data: "deposit_30000" }
      ],
      [
        { text: "🚀 50K", callback_data: "deposit_50000" },
        { text: "👑 100K", callback_data: "deposit_100000" }
      ],
      [
        { text: "✏️ Nominal Kustom", callback_data: "deposit_custom" }
      ],
      [
        { text: "🔙 Kembali ke Menu", callback_data: "menu_back" }
      ]
    ]
  };

  bot.editMessageText(text, {
    chat_id: chatId,
    message_id: msgId,
    parse_mode: "Markdown",
    reply_markup: keyboard
  }).catch(() => {});
};