
const fs = require('fs');
const path = require('path');

const promoPath = path.join(__dirname, '../data/promo.json');
let promoData = JSON.parse(fs.readFileSync(promoPath));

function getActivePromo(service) {
    const today = new Date();
    return promoData.find(promo => 
        promo.service === service && 
        new Date(promo.startDate) <= today && 
        today <= new Date(promo.endDate)
    );
}

module.exports = {
    getActivePromo
};
