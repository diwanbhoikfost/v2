
const fs = require('fs');
const path = require('path');

const sellerPricesPath = path.join(__dirname, '../data/sellerPrices.json');
let sellerPrices = JSON.parse(fs.readFileSync(sellerPricesPath));

module.exports = {
    name: 'setprice',
    description: 'Set harga layanan untuk seller',
    execute(message, args) {
        // args: [service, price]
        const sellerID = message.author.id;
        const [service, price] = args;
        if(!service || !price) return message.reply('Usage: /setprice <service> <price>');
        if(!sellerPrices[sellerID]) sellerPrices[sellerID] = {};
        sellerPrices[sellerID][service] = parseInt(price);
        fs.writeFileSync(sellerPricesPath, JSON.stringify(sellerPrices, null, 4));
        message.reply(`Harga ${service} untuk seller kamu telah di-set: ${price}`);
    }
};
