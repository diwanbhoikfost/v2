
const fs = require('fs');
const path = require('path');

const referralPath = path.join(__dirname, '../data/referral.json');
let referralData = JSON.parse(fs.readFileSync(referralPath));

module.exports = {
    name: 'referral',
    description: 'Referral system: masukkan kode teman atau cek poin',
    execute(message, args) {
        const userID = message.author.id;
        const subcommand = args[0];

        if(subcommand === 'myreferral') {
            const user = referralData[userID] || {referred: [], points: 0};
            return message.reply(`Kamu memiliki poin: ${user.points}\nTeman yang direfer: ${user.referred.join(', ') || 'Tidak ada'}`);
        }

        // subcommand: kode referral teman
        const kode = subcommand;
        if(!kode) return message.reply('Usage: /referral <kode> atau /referral myreferral');
        if(kode === userID) return message.reply('Kamu tidak bisa memakai kode sendiri!');

        if(!referralData[kode]) referralData[kode] = {referred: [], points: 0};
        referralData[kode].referred.push(userID);
        referralData[kode].points += 10; // 10 poin per referral
        fs.writeFileSync(referralPath, JSON.stringify(referralData, null, 4));

        message.reply(`Referral berhasil! ${kode} mendapatkan 10 poin.`);
    }
};
