#!/usr/bin/bash

# ================= CLEAN =================
rm -rf /etc/xray/config.json
rm -rf /etc/nginx/conf.d/xray.conf

# ================= XRAY CONFIG =================
cat > /etc/xray/config.json <<EOF
{
"log": {
  "access": "/var/log/xray/access.log",
  "error": "/var/log/xray/error.log",
  "loglevel": "info"
},

"inbounds": [

    {
      "tag": "vless-ws",
      "listen": "127.0.0.1",
      "port": 10001,
      "protocol": "vless",
      "settings": { "decryption": "none", "clients": [] },
      "streamSettings": {
        "network": "ws",
        "wsSettings": { "path": "/vless" }
      }
    },

    {
      "tag": "vmess-ws",
      "listen": "127.0.0.1",
      "port": 10002,
      "protocol": "vmess",
      "settings": { "clients": [] },
      "streamSettings": {
        "network": "ws",
        "wsSettings": { "path": "/vmess" }
      }
    },

    {
      "tag": "trojan-ws",
      "listen": "127.0.0.1",
      "port": 10003,
      "protocol": "trojan",
      "settings": { "clients": [], "udp": true },
      "streamSettings": {
        "network": "ws",
        "wsSettings": { "path": "/trojan-ws" }
      }
    },

    {
      "tag": "vless-grpc",
      "listen": "127.0.0.1",
      "port": 10005,
      "protocol": "vless",
      "settings": { "decryption": "none", "clients": [] },
      "streamSettings": {
        "network": "grpc",
        "grpcSettings": { "serviceName": "vless-grpc" }
      }
    },

    {
      "tag": "vmess-grpc",
      "listen": "127.0.0.1",
      "port": 10006,
      "protocol": "vmess",
      "settings": { "clients": [] },
      "streamSettings": {
        "network": "grpc",
        "grpcSettings": { "serviceName": "vmess-grpc" }
      }
    },

    {
      "tag": "trojan-grpc",
      "listen": "127.0.0.1",
      "port": 10007,
      "protocol": "trojan",
      "settings": { "clients": [] },
      "streamSettings": {
        "network": "grpc",
        "grpcSettings": { "serviceName": "trojan-grpc" }
      }
    },

    {
      "tag": "api",
      "listen": "127.0.0.1",
      "port": 10085,
      "protocol": "dokodemo-door",
      "settings": {
        "address": "127.0.0.1"
      }
    }

],

"outbounds": [
  { "protocol": "freedom" },
  { "protocol": "blackhole", "tag": "blocked" }
],

"routing": {
  "rules": [
    {
      "type": "field",
      "inboundTag": ["api"],
      "outboundTag": "api"
    }
  ]
},

"stats": {},

"api": {
  "services": ["StatsService"],
  "tag": "api"
},

"policy": {
  "levels": {
    "0": {
      "statsUserDownlink": true,
      "statsUserUplink": true
    }
  },
  "system": {
    "statsInboundUplink": true,
    "statsInboundDownlink": true,
    "statsOutboundUplink": true,
    "statsOutboundDownlink": true
    }
  }

}
EOF

cat > /etc/systemd/system/xray.service <<EOF
[Unit]
Description=Xray Service
After=network.target
[Service]
User=root
ExecStart=/usr/local/bin/xray run -config /etc/xray/config.json
Restart=on-failure
[Install]
WantedBy=multi-user.target
EOF

# ================= NGINX (ALL IN ONE 443) =================
cat > /etc/nginx/conf.d/xray.conf <<'END'
server {
    listen 443 ssl http2;
    server_name _;

    ssl_certificate     /etc/xray/xray.crt;
    ssl_certificate_key /etc/xray/xray.key;

    location /vless {
        proxy_pass http://127.0.0.1:10001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }

    location /vmess {
        proxy_pass http://127.0.0.1:10002;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }

    location /trojan-ws {
        proxy_pass http://127.0.0.1:10003;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }

    location /ssh {
        proxy_pass http://127.0.0.1:10015;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
    }

    location /vless-grpc {
        grpc_pass grpc://127.0.0.1:10005;
    }

    location /vmess-grpc {
        grpc_pass grpc://127.0.0.1:10006;
    }

    location /trojan-grpc {
        grpc_pass grpc://127.0.0.1:10007;
    }

    location / {
        root /var/www/html;
        index index.html;
    }
}
END


cat >/etc/haproxy/haproxy.cfg <<EOF
global
    daemon

defaults
    mode tcp
    timeout connect 10s
    timeout client 60s
    timeout server 60s

# ================= WS PUBLIC =================
frontend http
    bind *:80
    bind *:8080
    bind *:8880
    bind *:2082
    mode tcp

    tcp-request inspect-delay 5s
    tcp-request content accept if HTTP

    acl is_ws hdr(Upgrade) -i websocket
    acl is_vless path_beg /vless
    acl is_vmess path_beg /vmess
    acl is_trojan path_beg /trojan-ws

    # XRAY PRIORITAS
    use_backend vless_ws if is_ws is_vless
    use_backend vmess_ws if is_ws is_vmess
    use_backend trojan_ws if is_ws is_trojan

    # FALLBACK WS → SSH WS
    use_backend ssh_ws if is_ws

    # DEFAULT → SSH BIASA
    default_backend ssh


# ================= SSH TLS (PORT 2083) =================
frontend ssh_tls
    bind *:2083 ssl crt /etc/haproxy/hap.pem
    mode tcp
    default_backend ssh


# ================= BACKEND =================

backend ssh
    server s1 127.0.0.1:109

backend ssh_ws
    server s1 127.0.0.1:10015

backend vless_ws
    server s1 127.0.0.1:10001

backend vmess_ws
    server s1 127.0.0.1:10002

backend trojan_ws
    server s1 127.0.0.1:10003

EOF
# ================= RUN =================
systemctl daemon-reload
systemctl restart xray
systemctl restart nginx