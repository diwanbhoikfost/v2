// db.js — SQLite.js robust restore/save
'use strict';

const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, 'yanbot.db');

let SQL;
let betterDb;

function getDb() {
  if (!betterDb) throw new Error('[DB] Database belum siap');
  return betterDb;
}

// Save DB to disk
function saveDb() {
  try {
    const data = betterDb.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('[DB] 💾 Database saved.');
  } catch (e) {
    console.error('[DB] ❌ Gagal save:', e.message);
  }
}

let saveTimer = null;
function debounceSave() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(saveDb, 500);
}

// Helper: add column if not exists
function addColumnIfNotExists(table, column, type = 'TEXT', defaultValue = '') {
  try {
    const res = betterDb.exec(
      `PRAGMA table_info(${table})`
    );
    const cols = res[0]?.values.map(v => v[1]) || [];
    if (!cols.includes(column)) {
      betterDb.run(`ALTER TABLE ${table} ADD COLUMN ${column} ${type} DEFAULT '${defaultValue}'`);
      console.log(`[DB] ✨ Added column ${column} to ${table}`);
    }
  } catch (err) {
    console.warn(`[DB] ⚠️ Gagal tambah kolom ${column}:`, err.message);
  }
}

async function initDb() {
  SQL = await initSqlJs({ locateFile: file => `https://sql.js.org/dist/${file}` });

  try {
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      betterDb = new SQL.Database(fileBuffer);
      console.log('[DB] ✅ Database loaded:', dbPath);
    } else {
      betterDb = new SQL.Database();
      console.log('[DB] ✅ Database created:', dbPath);
    }
  } catch (err) {
    console.error('[DB] ⚠️ DB file corrupt, creating new:', err.message);
    betterDb = new SQL.Database();
  }

  // PRAGMA settings
  betterDb.run('PRAGMA journal_mode = WAL');
  betterDb.run('PRAGMA synchronous = NORMAL');
  betterDb.run('PRAGMA cache_size = 4000');
  betterDb.run('PRAGMA temp_store = MEMORY');
  betterDb.run('PRAGMA busy_timeout = 5000');

  // Table creation
  betterDb.run(`CREATE TABLE IF NOT EXISTS users (
    chat_id INTEGER PRIMARY KEY,
    saldo INTEGER DEFAULT 0,
    role TEXT DEFAULT 'members',
    created_at TEXT
  )`);

  betterDb.run(`CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    amount INTEGER,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    product_type TEXT DEFAULT ''
  )`);

  // Add columns safely
  addColumnIfNotExists('transactions', 'username', 'TEXT', '');
  addColumnIfNotExists('transactions', 'expired_at', 'TEXT', '');
  addColumnIfNotExists('transactions', 'server_ip', 'TEXT', '');

  // Indexes
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_chat_id ON transactions(chat_id)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_status ON transactions(status)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_created_at ON transactions(created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_status_created ON transactions(status, created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_chatid_status ON transactions(chat_id, status, created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)`);

  betterDb.run(`CREATE TABLE IF NOT EXISTS notif_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    days_before INTEGER,
    sent_at TEXT,
    UNIQUE(order_id, days_before)
  )`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_notif_order ON notif_log(order_id, days_before)`);

  saveDb();
  setInterval(saveDb, 30000);
}

const db = {
  run(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      getDb().run(sql, params);
      debounceSave();
      if (callback) callback(null, { changes: getDb().getRowsModified() });
    } catch (err) {
      if (callback) callback(err);
    }
  },

  get(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      const stmt = getDb().prepare(sql);
      stmt.bind(params);
      let row = null;
      if (stmt.step()) {
        const cols = stmt.getColumnNames();
        const vals = stmt.get();
        row = {};
        cols.forEach((c, i) => row[c] = vals[i]);
      }
      stmt.free();
      callback(null, row);
    } catch (err) {
      if (callback) callback(err, null);
    }
  },

  all(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      const stmt = getDb().prepare(sql);
      stmt.bind(params);
      const rows = [];
      while (stmt.step()) {
        const cols = stmt.getColumnNames();
        const vals = stmt.get();
        const row = {};
        cols.forEach((c, i) => row[c] = vals[i]);
        rows.push(row);
      }
      stmt.free();
      callback(null, rows);
    } catch (err) {
      if (callback) callback(err, []);
    }
  },

  exec(sql, callback) {
    try {
      getDb().exec(sql);
      debounceSave();
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  },

  close(callback) {
    try {
      saveDb();
      getDb().close();
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  },

  ready: initDb()
};

module.exports = db;