// cmd/menu_deposit.js - Optimized v2.3 (Grid Simetris)
'use strict';

module.exports = function menuDepositCmd(bot, chatId, msgId) {
  const text =
`💎 *TOP UP SALDO* 💎

Pilih nominal top up atau masukkan jumlah kustom:

Saldo masuk otomatis setelah pembayaran QRIS lunas. ⚡️
Nikmati bonus setiap transaksi tertentu! 🎁`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: '💸 Rp 10.000', callback_data: 'deposit_10000' },
        { text: '💸 Rp 15.000', callback_data: 'deposit_15000' }
      ],
      [
        { text: '💸 Rp 20.000', callback_data: 'deposit_20000' },
        { text: '💰 Rp 25.000', callback_data: 'deposit_25000' }
      ],
      [
        { text: '💰 Rp 50.000', callback_data: 'deposit_50000' },
        { text: '🚀 Rp 75.000', callback_data: 'deposit_75000' }
      ],
      [
        { text: '🚀 Rp 100.000', callback_data: 'deposit_100000' },
        { text: '✏️ Jumlah Kustom', callback_data: 'deposit_custom' }
      ],
      [
        { text: '🔙 Kembali ke Menu', callback_data: 'menu_back' }
      ]
    ]
  };

  bot.editMessageText(text, {
    chat_id: chatId,
    message_id: msgId,
    parse_mode: 'Markdown',
    reply_markup: keyboard
  }).catch(() => {});
};