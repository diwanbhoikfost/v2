// data/server.js — Daftar VPS server (dikelola otomatis oleh admin panel)
'use strict';

const servers = [];

module.exports = servers;
