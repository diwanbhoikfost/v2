// data/prices.js
// Harga global (fallback jika server tidak punya harga custom)
// Harga per server disimpan di data/server-prices.json

const fs   = require('fs');
const path = require('path');

module.exports = {
  members: {
    ssh:      { perDay: 223 },
    vmess:    { perDay: 223 },
    vless:    { perDay: 223 },
    trojan:   { perDay: 223 },
    udpzivpn: { perDay: 200 }
  },
  reseller: {
    ssh:      { perDay: 200 },
    vmess:    { perDay: 200 },
    vless:    { perDay: 200 },
    trojan:   { perDay: 200 },
    udpzivpn: { perDay: 150 }
  }
};
