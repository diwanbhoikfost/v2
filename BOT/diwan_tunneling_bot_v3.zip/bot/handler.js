// handler.js - OPTIMIZED v4.0 — new menu, admin role, reseller menu, anti-spam
'use strict';

const fs   = require('fs');
const path = require('path');
const db   = require('./data/db');

/* ══════════════════════════════════════════
   PRICES CACHE
══════════════════════════════════════════ */
let _pricesCache = null;
const PRICES_PATH = path.join(__dirname, 'data', 'prices.js');

function loadPrices() {
  try {
    const resolved = require.resolve(PRICES_PATH);
    delete require.cache[resolved];
    _pricesCache = require(PRICES_PATH);
  } catch (e) {
    console.error('[handler] ❌ Gagal load prices.js:', e.message);
    _pricesCache = { reseller: {}, members: {} };
  }
}

loadPrices();
fs.watchFile(PRICES_PATH, { interval: 5000 }, () => { loadPrices(); });

function getPrices() {
  if (!_pricesCache) loadPrices();
  return _pricesCache;
}

function fRp(n) { return n ? Number(n).toLocaleString('id-ID') : '?'; }

const RESELLER_MIN_TOPUP = 30000;
const RESELLER_FREE_IP = 3;

function rp(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }

/* ══════════════════════════════════════════
   OWNER / ADMIN CONFIG
══════════════════════════════════════════ */
let _avars = {};
try { _avars = JSON.parse(fs.readFileSync(path.join(__dirname, 'data/.avars.json'), 'utf8')); } catch (_) {}
const OWNER_ID = String(_avars.owner_id || '');

function getDisplayRole(chatId, dbRole) {
  if (String(chatId) === OWNER_ID) return 'admin';
  return dbRole || 'members';
}

/* ══════════════════════════════════════════
   LAZY REQUIRES
══════════════════════════════════════════ */
let _paymentChecker, _qris, _create, _renew, _triall;
let _menuDepositCmd, _trxCmd, _myaccountCmd, _voucherSvc, _statsCmd, _referralCmd;

function getListServer() {
  /* Always bust cache so server.used reflects latest writes */
  try {
    const p = require.resolve('./data/server');
    delete require.cache[p];
    return require('./data/server');
  } catch (e) { return []; }
}

function getPaymentChecker() {
  if (!_paymentChecker) _paymentChecker = require('./services/paymentChecker');
  return _paymentChecker;
}
function getQRIS()   { if (!_qris)   _qris   = require('./services/qris');      return _qris; }
function getCreate() { if (!_create) _create = require('./cmd/create');          return _create; }
function getRenew()  { if (!_renew)  _renew  = require('./cmd/renew');           return _renew; }
function getTriall() { if (!_triall) _triall = require('./cmd/triall');          return _triall; }
function getMenuDeposit() {
  if (!_menuDepositCmd) _menuDepositCmd = require('./cmd/menu_deposit'); return _menuDepositCmd;
}
function getTrxCmd() {
  if (!_trxCmd) _trxCmd = require('./cmd/trx'); return _trxCmd;
}
function getMyaccount() {
  if (!_myaccountCmd) _myaccountCmd = require('./cmd/myaccount'); return _myaccountCmd;
}
function getVoucherSvc() {
  if (!_voucherSvc) _voucherSvc = require('./services/voucher'); return _voucherSvc;
}
function getStatsCmd() {
  if (!_statsCmd) _statsCmd = require('./cmd/stats'); return _statsCmd;
}
function getReferralCmd() {
  if (!_referralCmd) _referralCmd = require('./cmd/referral'); return _referralCmd;
}

/* ══════════════════════════════════════════
   STATE MAPS — auto-cleanup
══════════════════════════════════════════ */
const userMenus     = new Map();
const userStates    = new Map();
const userTimestamp = new Map();

const processingUsers = new Set();
const userLastMsg     = new Map();
const lastCbTime      = new Map();
const lastCbData      = new Map();

const SESSION_TTL   = 30 * 60 * 1000;
const RATE_LIMIT_MS = 1500;
const CB_DEDUP_MS   = 1000;

const ACTIVE_FLOWS = new Set([
  'create_flow', 'renew_flow', 'triall_flow',
  'deposit_custom', 'tambah_saldo_reseller', 'renew_pick',
  'create_confirm', 'renew_confirm', 'claim_voucher', 'claim_referral'
]);

function touchSession(chatId) {
  userTimestamp.set(chatId, Date.now());
}

function cleanupSessions() {
  const now = Date.now();
  for (const [chatId, ts] of userTimestamp.entries()) {
    if (now - ts > SESSION_TTL) {
      userMenus.delete(chatId);
      userStates.delete(chatId);
      userTimestamp.delete(chatId);
      processingUsers.delete(chatId);
      userLastMsg.delete(chatId);
      lastCbTime.delete(chatId);
      lastCbData.delete(chatId);
    }
  }
}

setInterval(cleanupSessions, 15 * 60 * 1000);

/* ══════════════════════════════════════════
   HELPERS
══════════════════════════════════════════ */
function sendTempMsg(bot, chatId, text, ms = 2500) {
  bot.sendMessage(chatId, text, { parse_mode: 'HTML' })
    .then(m => setTimeout(() => bot.deleteMessage(chatId, m.message_id).catch(() => {}), ms))
    .catch(() => {});
}

async function editMsg(bot, chatId, msgId, text, opts = {}) {
  try {
    await bot.editMessageText(text, { chat_id: chatId, message_id: msgId, ...opts });
    return true;
  } catch (e) {
    if (e.message?.includes('message is not modified')) return true;
    return false;
  }
}

/* ══════════════════════════════════════════
   STATISTIK
══════════════════════════════════════════ */
function getAllStats(chatId) {
  return new Promise(resolve => {
    db.get(`
      SELECT
        COUNT(CASE WHEN status='completed' AND date(created_at)=date('now','localtime') THEN 1 END)                                       AS global_today,
        COUNT(CASE WHEN status='completed' AND strftime('%Y-%W',created_at)=strftime('%Y-%W','now','localtime') THEN 1 END)               AS global_week,
        COUNT(CASE WHEN status='completed' AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime') THEN 1 END)               AS global_month,
        COUNT(CASE WHEN status='completed' AND chat_id=? AND date(created_at)=date('now','localtime') THEN 1 END)                        AS user_today,
        COUNT(CASE WHEN status='completed' AND chat_id=? AND strftime('%Y-%W',created_at)=strftime('%Y-%W','now','localtime') THEN 1 END) AS user_week,
        COUNT(CASE WHEN status='completed' AND chat_id=? AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime') THEN 1 END) AS user_month,
        COALESCE(SUM(CASE WHEN status='completed' AND (order_id GLOB '[0-9]*') AND date(created_at)=date('now','localtime') THEN amount END), 0)                                 AS inc_today,
        COALESCE(SUM(CASE WHEN status='completed' AND (order_id GLOB '[0-9]*') AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime') THEN amount END), 0)        AS inc_month,
        COALESCE(SUM(CASE WHEN status='completed' AND (order_id GLOB '[0-9]*') THEN amount END), 0)                                                                              AS inc_total
      FROM transactions
    `, [chatId, chatId, chatId], (err, row) => {
      if (err || !row) return resolve({ g: { today:0, week:0, month:0 }, u: { today:0, week:0, month:0 }, inc: { today:0, month:0, total:0 } });
      resolve({
        g:   { today: row.global_today, week: row.global_week,  month: row.global_month },
        u:   { today: row.user_today,   week: row.user_week,    month: row.user_month   },
        inc: { today: row.inc_today,    month: row.inc_month,   total: row.inc_total    }
      });
    });
  });
}

/* ══════════════════════════════════════════
   BUILD MENU
══════════════════════════════════════════ */
async function buildMenuData(chatId) {
  const [row, stats] = await Promise.all([
    new Promise(r => db.get('SELECT saldo, role FROM users WHERE chat_id=?', [chatId], (e, v) => r(v || { saldo: 0, role: 'members' }))),
    getAllStats(chatId)
  ]);

  const saldo       = Number(row.saldo) || 0;
  const displayRole = getDisplayRole(chatId, row.role);
  const pr          = getPrices();
  const m           = pr.members  || {};
  const r2          = pr.reseller || {};

  const incomeSection = displayRole === 'admin'
    ? `├─────────────────┤
│ 💵 𝗜𝗡𝗖𝗢𝗠𝗘 𝗔𝗗𝗠𝗜𝗡 <i>(via QRIS)</i>
│ ├ Hari ini   : <b>Rp ${Number(stats.inc.today).toLocaleString('id-ID')}</b>
│ ├ Bulan ini  : <b>Rp ${Number(stats.inc.month).toLocaleString('id-ID')}</b>
│ └ Total      : <b>Rp ${Number(stats.inc.total).toLocaleString('id-ID')}</b>
`
    : '';

  const text = `┏━━━━━━━━━━━━━━━━━━┓
┃ ⚡ DIWAN TUNNELING ⚡ ┃
┗━━━━━━━━━━━━━━━━━━┛

┌─────────────────┐
│ 👤 INFO AKUN
│ Role  : <code>${displayRole.toUpperCase()}</code>
│ ID    : <code>${chatId}</code>
│ Saldo : <code>Rp ${saldo.toLocaleString('id-ID')}</code>
└─────────────────┘

┌─────────────────┐
│ 💰 PRICE LIST / HARI
│ Members
│ ├ SSH & X-Ray : <b>Rp ${fRp(m.vmess?.perDay)}</b>
│ └ UDP ZivPN   : <b>Rp ${fRp(m.udpzivpn?.perDay)}</b>
│ Reseller
│ ├ SSH & X-Ray : <b>Rp ${fRp(r2.vmess?.perDay)}</b>
│ └ UDP ZivPN   : <b>Rp ${fRp(r2.udpzivpn?.perDay)}</b>
└─────────────────┘

┌─────────────────┐
│ 📊 STATISTIK ORDER
│ Global
│ ├ Hari ini   : <b>${stats.g.today}</b>
│ ├ Minggu ini : <b>${stats.g.week}</b>
│ └ Bulan ini  : <b>${stats.g.month}</b>
│ Kamu
│ ├ Hari ini   : <b>${stats.u.today}</b>
│ ├ Minggu ini : <b>${stats.u.week}</b>
│ └ Bulan ini  : <b>${stats.u.month}</b>
${incomeSection}└─────────────────┘
`;

  const keyboard = [
    [
      { text: '📝 Order Akun',    callback_data: 'create_menu'  },
      { text: '🎁 Trial Gratis',  callback_data: 'triall_menu'  }
    ],
    [
      { text: '👤 Akun Saya',     callback_data: 'menu_myaccount'    },
      { text: '📡 Status Server', callback_data: 'menu_server_status' }
    ],
    [
      { text: '📊 Statistik',     callback_data: 'menu_stats'    },
      { text: '🔗 Referral',      callback_data: 'menu_referral' }
    ],
    [{ text: '💎 Reseller / Top Up',    callback_data: 'reseller_menu'     }],
    [{ text: '🎁 Claim Saldo Gratis',   callback_data: 'menu_claim_voucher' }]
  ];

  return { text, keyboard, parse_mode: 'HTML' };
}

/* ══════════════════════════════════════════
   RESELLER MENU
══════════════════════════════════════════ */
function editResellerMenu(bot, chatId, msgId) {
  const text =
    `┌─────────────────┐
│  💎 MENU RESELLER
└─────────────────┘

` +
    `<b>Apa itu Reseller?</b>
` +
    `Reseller mendapat harga lebih murah dan bisa menjual kembali layanan VPN ke pelanggan.

` +
    `<b>Cara menjadi Reseller:</b>
` +
    `├ Top up saldo minimal <b>${rp(RESELLER_MIN_TOPUP)}</b>
` +
    `└ Status reseller aktif otomatis setelah pembayaran sukses

` +
    `<b>Keuntungan Reseller:</b>
` +
    `├ Harga lebih murah dari members
` +
    `├ Limit IP gratis sampai <b>${RESELLER_FREE_IP} IP/akun</b>
` +
    `└ Bisa tambah saldo untuk order pelanggan`;

  return editMsg(bot, chatId, msgId, text, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [{ text: '💰 Top Up Reseller', callback_data: 'menu_deposit' }],
        [{ text: '➕ Tambah Saldo Reseller', callback_data: 'menu_tambah_saldo' }],
        [{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]
      ]
    }
  });
}


function buildServerInfoCard(kind) {
  const LIST_SERVER = getListServer();
  const regex = kind === 'sg' ? /(sg|singapore)/i : /(id|indo|indonesia)/i;
  const title = kind === 'sg' ? '🌐 SERVER SINGAPORE' : '🇮🇩 SERVER INDONESIA';
  const filtered = LIST_SERVER.filter(srv => regex.test(`${srv.name || ''} ${srv.country || ''} ${srv.location || ''}`));
  const rows = (filtered.length ? filtered : LIST_SERVER).slice(0, 8).map((srv, i) => {
    const used = srv.used || 0;
    const limit = srv.limit || 0;
    const status = (limit > 0 && used >= limit) ? 'FULL' : `${used}/${limit || '-'}`;
    return `${i + 1}. ${srv.name || srv.ip || 'Server'} — ${status}`;
  });

  return `┌─────────────────┐\n│  ${title}\n└─────────────────┘\n\n` +
    (rows.length ? rows.join('\n') : 'Belum ada server yang terdaftar.') +
    `\n\nPilih menu Order Akun untuk mulai membuat akun VPN.`;
}

function editInfoMenu(bot, chatId, msgId, type) {
  const cards = {
    gaming_info:
      `┌─────────────────┐\n│  🎮 SUPPORT GAMING\n└─────────────────┘\n\n` +
      `Cocok untuk Mobile Legends, Free Fire, PUBG, Roblox, dan game online lain.\n\n` +
      `Tips: pilih server terdekat dan gunakan limit IP sesuai kebutuhan agar koneksi tetap stabil.`,
    sosmed_info:
      `┌─────────────────┐\n│  📱 SUPPORT SOSMED\n└─────────────────┘\n\n` +
      `Cocok untuk WhatsApp, Telegram, TikTok, Instagram, YouTube, dan browsing harian.\n\n` +
      `Gunakan paket sesuai durasi dan kuota agar saldo lebih hemat.`
  };

  const text = type === 'server_sg' ? buildServerInfoCard('sg') :
               type === 'server_id' ? buildServerInfoCard('id') :
               cards[type];
  if (!text) return false;
  return editMsg(bot, chatId, msgId, text, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: [
      [{ text: '📝 Order Akun', callback_data: 'create_menu' }],
      [{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]
    ] }
  });
}


function progressBar(pct) {
  const n = Math.max(0, Math.min(10, Math.round((Number(pct) || 0) / 10)));
  return '█'.repeat(n) + '░'.repeat(10 - n);
}

async function editServerStatusMenu(bot, chatId, msgId) {
  await editMsg(bot, chatId, msgId, '⏳ <i>Mengecek status server realtime...</i>', { parse_mode: 'HTML' });
  let rows = [];
  try {
    const { getAllServerStatus } = require('./services/ssh-exec');
    rows = await getAllServerStatus();
  } catch (e) {
    console.error('[server_status]', e.message);
  }

  if (!rows.length) {
    return editMsg(bot, chatId, msgId,
      `┌─────────────────────┐
│ 📡 STATUS SERVER
└─────────────────────┘

Belum ada server terdaftar.`,
      { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] } }
    );
  }

  let text = `┌─────────────────────┐
│ 📡 STATUS SERVER REALTIME
└─────────────────────┘

`;
  rows.forEach(({ server, info }, i) => {
    const used = Number(server.used || 0);
    const limit = Number(server.limit || 0);
    const slotPct = limit > 0 ? Math.round((used / limit) * 100) : 0;
    const onlineIcon = info?.online ? '🟢 Online' : '🔴 Offline';
    const load = info?.loadPercent == null ? '-' : `${info.loadPercent}%`;
    const mem = info?.memoryPercent == null ? '-' : `${info.memoryPercent}%`;
    const loc = server.location || server.country || server.region || '-';
    const note = info?.legacyPing ? 'API lama, load belum tersedia' : (info?.reason || '');

    text += `${i + 1}. <b>${server.name || server.ip || 'Server'}</b> — ${onlineIcon}
`;
    text += `   📍 Lokasi : <b>${loc}</b>
`;
    text += `   🌐 IP     : <code>${server.ip || '-'}</code>
`;
    text += `   📊 Load   : <b>${load}</b>${load !== '-' ? ` [${progressBar(info.loadPercent)}]` : ''}
`;
    text += `   🧠 RAM    : <b>${mem}</b>
`;
    text += `   👥 Slot   : <b>${used}/${limit || '-'}</b> (${slotPct}%) [${progressBar(slotPct)}]
`;
    if (note) text += `   ℹ️ ${note}
`;
    text += `
`;
  });
  text += `⏱ Data dicek saat tombol dibuka. Klik refresh untuk cek ulang.`;

  return editMsg(bot, chatId, msgId, text, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: [
      [{ text: '🔄 Refresh Status', callback_data: 'menu_server_status' }],
      [{ text: '📝 Order Akun', callback_data: 'create_menu' }],
      [{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]
    ] }
  });
}

/* ══════════════════════════════════════════
   SEND / EDIT MENU
══════════════════════════════════════════ */
async function sendMainMenu(bot, chatId) {
  touchSession(chatId);

  if (userMenus.has(chatId)) {
    bot.deleteMessage(chatId, userMenus.get(chatId)).catch(() => {});
    userMenus.delete(chatId);
  }

  const loadingMsg = await bot.sendMessage(chatId, '⏳ <i>Memuat menu...</i>', { parse_mode: 'HTML' }).catch(() => null);
  if (!loadingMsg) return;

  const msgId = loadingMsg.message_id;
  userMenus.set(chatId, msgId);

  try {
    const { text, keyboard, parse_mode } = await buildMenuData(chatId);
    await editMsg(bot, chatId, msgId, text, { parse_mode, reply_markup: { inline_keyboard: keyboard } });
  } catch (err) {
    console.error('[sendMainMenu] ❌', err.message);
    bot.editMessageText('❌ Gagal load menu. Ketik /menu untuk coba lagi.', {
      chat_id: chatId, message_id: msgId
    }).catch(() => {});
  }
}

async function editMainMenu(bot, chatId, msgId) {
  touchSession(chatId);
  const ok0 = await editMsg(bot, chatId, msgId, '⏳ <i>Memuat menu...</i>', { parse_mode: 'HTML' });
  if (!ok0) return false;
  try {
    const { text, keyboard, parse_mode } = await buildMenuData(chatId);
    const ok = await editMsg(bot, chatId, msgId, text, { parse_mode, reply_markup: { inline_keyboard: keyboard } });
    if (ok) userMenus.set(chatId, msgId);
    return ok;
  } catch (err) {
    console.error('[editMainMenu] ❌', err.message);
    return false;
  }
}

/* ══════════════════════════════════════════
   SERVER / PROTOCOL MENUS
══════════════════════════════════════════ */
function editServerSelection(bot, chatId, msgId, actionType) {
  const LIST_SERVER = getListServer();
  const keyboard = LIST_SERVER.map((srv, idx) => {
    const used   = srv.used  || 0;
    const limit  = srv.limit || 0;
    const status = (limit > 0 && used >= limit) ? '🔴 FULL' : `🟢 ${used}/${limit}`;
    return [{ text: `${srv.name} — ${status}`, callback_data: `select_${actionType}_${idx}` }];
  });
  keyboard.push([{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]);
  return editMsg(bot, chatId, msgId,
    `┌─────────────────┐\n│  🖥 PILIH SERVER\n└─────────────────┘\n\nPilih server untuk layanan VPN:`,
    { reply_markup: { inline_keyboard: keyboard } }
  );
}

function editCreateMenu(bot, chatId, msgId) {
  const keyboard = [
    [
      { text: '⚪ SSH / OpenVPN', callback_data: 'ssh_create' },
      { text: '🔵 xRay VMess',   callback_data: 'vme_create' }
    ],
    [{ text: '🟢 UDP ZivPN', callback_data: 'ziv_create' }],
    [
      { text: '🟡 xRay VLess',   callback_data: 'vle_create' },
      { text: '🟠 xRay Trojan',  callback_data: 'tro_create' }
    ],
    [{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]
  ];
  return editMsg(bot, chatId, msgId,
    `┌─────────────────┐\n│  🔰 CREATE VPN PREMIUM\n└─────────────────┘\n\nPilih protokol VPN:`,
    { reply_markup: { inline_keyboard: keyboard } }
  );
}

function editTriallMenu(bot, chatId, msgId) {
  const keyboard = [
    [
      { text: '⚪ SSH / OpenVPN', callback_data: 'ssh_triall' },
      { text: '🔵 xRay VMess',   callback_data: 'vme_triall' }
    ],
    [{ text: '🟢 UDP ZivPN', callback_data: 'ziv_triall' }],
    [
      { text: '🟡 xRay VLess',   callback_data: 'vle_triall' },
      { text: '🟠 xRay Trojan',  callback_data: 'tro_triall' }
    ],
    [{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]
  ];
  return editMsg(bot, chatId, msgId,
    `┌─────────────────┐\n│  🎁 TRIAL VPN GRATIS\n└─────────────────┘\n\n⏱ Durasi: 30 menit  🆓 Gratis!\nPilih protokol VPN:`,
    { reply_markup: { inline_keyboard: keyboard } }
  );
}

/* ══════════════════════════════════════════
   WELCOME
══════════════════════════════════════════ */
function sendWelcome(bot, chatId) {
  bot.sendMessage(chatId,
`╔════════════════════════════════════════╗
║          ⚡ DIWAN TUNNELING ⚡         
║      PREMIUM VPN • FAST • SECURE      
╠════════════════════════════════════════╣
║   🚀 Welcome to AutoBot VPN Service   
║                                        
║   Nikmati koneksi super ngebut ⚡      
║   stabil tanpa lemot & anti putus 🔒  
║                                        
║   🌐 SERVER AVAILABLE                  
║   🇸🇬 Singapore Premium                
║   🇮🇩 Indonesia Premium                
║                                        
║   🎮 SUPPORT GAMING                   
║   • Mobile Legends                    
║   • PUBG Mobile                       
║   • Free Fire                         
║   • Valorant & lainnya                
║                                        
║   📱 SUPPORT SOCIAL MEDIA             
║   • TikTok                            
║   • Instagram                         
║   • WhatsApp                          
║   • YouTube & Telegram                
║                                        
║   🔐 PRIVATE • STABLE • HIGH SPEED    
║   📡 Anti Lag & Smooth Connection     
╠════════════════════════════════════════╣
║        👇 TAP BUTTON BELOW 👇          
║          START YOUR CONNECTION         
╚════════════════════════════════════════╝`,
    { reply_markup: { inline_keyboard: [[{ text: '🛒 Ke Menu Utama', callback_data: 'menu_back' }]] } }
  ).catch(err => console.error('[sendWelcome]', err.message));
}

/* ══════════════════════════════════════════
   MAIN HANDLER
══════════════════════════════════════════ */
function handler(bot) {

  /* ── PESAN TEKS ── */
  bot.on('message', async (msg) => {
    try {
      const chatId = msg.chat.id;
      const text   = msg.text?.trim();
      if (!text) return;

      bot.deleteMessage(chatId, msg.message_id).catch(() => {});
      touchSession(chatId);

      /* ── BLACKLIST CHECK ── */
      const banCheck = await new Promise(r =>
        db.get('SELECT is_banned, ban_reason FROM users WHERE chat_id=?', [chatId], (e, row) => r(row || {}))
      );
      if (banCheck.is_banned) {
        bot.sendMessage(chatId,
          `🚫 <b>Akun kamu diblokir.</b>\n\nAlasan: ${banCheck.ban_reason || 'Melanggar ketentuan layanan.'}\n\nHubungi admin jika ada keberatan.`,
          { parse_mode: 'HTML' }
        ).catch(() => {});
        return;
      }

      const stateObj = userStates.get(chatId);
      const state    = stateObj?.state;

      /* RATE LIMITER */
      if (state && ACTIVE_FLOWS.has(state)) {
        const last = userLastMsg.get(chatId);
        const now  = Date.now();
        if (last && (now - last) < RATE_LIMIT_MS) {
          sendTempMsg(bot, chatId, '⏳ <b>Terlalu cepat!</b> Tunggu sebentar ya.', 2000);
          return;
        }
        userLastMsg.set(chatId, now);
      }

      /* PROCESSING LOCK */
      if (processingUsers.has(chatId)) {
        sendTempMsg(bot, chatId, '⌛ <b>Sedang diproses...</b> Tunggu sebentar.', 2000);
        return;
      }

      processingUsers.add(chatId);
      try {
        if (state === 'create_flow') { await getCreate().handleStep(bot, chatId, text, userStates); return; }
        if (state === 'renew_flow')  { await getRenew().handleStep(bot, chatId, text, userStates);  return; }
        if (state === 'triall_flow') { await getTriall().handleStep(bot, chatId, text, userStates); return; }

        if (state === 'deposit_custom') {
          if (!/^\d+$/.test(text)) { sendTempMsg(bot, chatId, '❌ Masukkan angka saja. Contoh: <code>30000</code>', 3000); return; }
          const amount = parseInt(text);
          if (amount < RESELLER_MIN_TOPUP) { sendTempMsg(bot, chatId, `❌ Minimal Top Up <b>${rp(RESELLER_MIN_TOPUP)}</b>`, 3000); return; }
          userStates.delete(chatId);
          getQRIS().generateQRIS(bot, chatId, amount);
          return;
        }

        if (state === 'tambah_saldo_reseller') {
          if (!/^\d+$/.test(text)) { sendTempMsg(bot, chatId, '❌ Masukkan angka saja. Contoh: <code>10000</code>', 3000); return; }
          const amount = parseInt(text);
          if (amount < 10000) { sendTempMsg(bot, chatId, '❌ Minimal top up <b>Rp 10.000</b>', 3000); return; }
          db.get('SELECT role FROM users WHERE chat_id=?', [chatId], (err, row) => {
            if (!row || (row.role !== 'reseller' && row.role !== 'admin')) {
              userStates.delete(chatId);
              sendTempMsg(bot, chatId, '❌ Wajib <b>Reseller</b> terlebih dahulu. Top Up dulu minimal Rp 30.000.', 4000);
              return;
            }
            userStates.delete(chatId);
            getQRIS().generateQRIS(bot, chatId, amount);
          });
          return;
        }

        if (state === 'renew_pick') {
          const num = parseInt(text);
          const { accounts, listMsgId } = stateObj;
          if (isNaN(num) || num < 1 || num > accounts.length) {
            sendTempMsg(bot, chatId, `❌ Pilih angka <b>1</b> sampai <b>${accounts.length}</b>`, 3000);
            return;
          }
          getRenew().initRenew(bot, chatId, userStates, accounts[num - 1], listMsgId);
          return;
        }

        if (state === 'claim_referral') {
          userStates.delete(chatId);
          const claimMsgId = stateObj.msgId;
          const code = text.trim().toUpperCase();
          const { claimReferral } = require('./services/referral');

          claimReferral(chatId, code, (err, result) => {
            const messages = {
              already_claimed: '❌ Kamu sudah pernah menggunakan kode referral.',
              has_topup:       '❌ Kode referral hanya bisa diklaim sebelum top up pertama.',
              own_code:        '❌ Kamu tidak bisa menggunakan kode referralmu sendiri.',
              invalid:         '❌ Kode referral tidak ditemukan. Periksa kembali kodenya.',
              error:           '❌ Terjadi kesalahan. Coba lagi nanti.'
            };

            if (result !== 'ok') {
              const errText = messages[result] || '❌ Klaim gagal.';
              if (claimMsgId) {
                return editMsg(bot, chatId, claimMsgId, errText, {
                  parse_mode: 'HTML',
                  reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
                });
              }
              return sendTempMsg(bot, chatId, errText, 4000);
            }

            const successText =
              `✅ <b>Kode Referral Berhasil Diklaim!</b>\n\n` +
              `🔗 Kode   : <code>${code}</code>\n\n` +
              `Kamu akan mendapat bonus <b>10%</b> dari top up pertamamu!\n\n` +
              `<i>Bonus diberikan ke pemilik kode setelah top up pertamamu berhasil.</i>`;

            if (claimMsgId) {
              return editMsg(bot, chatId, claimMsgId, successText, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
              });
            }
            sendTempMsg(bot, chatId, successText, 5000);
          });
          return;
        }

        if (state === 'claim_voucher') {
          userStates.delete(chatId);
          const claimMsgId = stateObj.msgId;
          const code = text.trim();

          const result = await getVoucherSvc().claimVoucher(code, chatId);

          const reasonMsg = {
            not_found:      '❌ Kode voucher tidak ditemukan.',
            inactive:       '❌ Voucher sudah tidak aktif.',
            exhausted:      '❌ Voucher sudah habis diklaim.',
            already_claimed:'❌ Kamu sudah pernah mengklaim voucher ini.'
          };

          if (!result.ok) {
            const errText = reasonMsg[result.reason] || '❌ Klaim gagal.';
            if (claimMsgId) {
              return editMsg(bot, chatId, claimMsgId, errText, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
              });
            }
            return sendTempMsg(bot, chatId, errText, 4000);
          }

          /* ── Berhasil claim → notif ke admin ── */
          const fromInfo = msg.from;
          const username  = fromInfo?.username  ? `@${fromInfo.username}` : '(no username)';
          const firstName = fromInfo?.first_name || '';
          const notifText =
            `🎁 <b>Voucher Berhasil Diklaim!</b>\n\n` +
            `👤 User     : ${firstName} ${username}\n` +
            `🆔 Telegram ID: <code>${chatId}</code>\n` +
            `🎟 Kode     : <code>${code}</code>\n` +
            `💰 Saldo    : <b>Rp ${Number(result.saldo).toLocaleString('id-ID')}</b>`;
          bot.sendMessage(OWNER_ID, notifText, { parse_mode: 'HTML' }).catch(() => {});

          const successText =
            `✅ <b>Voucher Berhasil Diklaim!</b>\n\n` +
            `┌─────────────────────┐\n` +
            `│ 🎟 Kode  : <code>${code}</code>\n` +
            `│ 💰 Saldo : <b>+Rp ${Number(result.saldo).toLocaleString('id-ID')}</b>\n` +
            `│ 💳 Total : <b>Rp ${Number(result.newSaldo).toLocaleString('id-ID')}</b>\n` +
            `└─────────────────────┘`;

          if (claimMsgId) {
            return editMsg(bot, chatId, claimMsgId, successText, {
              parse_mode: 'HTML',
              reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
            });
          }
          return sendTempMsg(bot, chatId, successText, 5000);
        }

        /* ── OWNER-ONLY COMMANDS ── */
        if (String(chatId) === OWNER_ID) {
          if (text.startsWith('/ban ')) {
            const parts  = text.split(' ');
            const target = parts[1];
            const reason = parts.slice(2).join(' ') || 'Melanggar ketentuan layanan.';
            if (!target || isNaN(Number(target))) {
              sendTempMsg(bot, chatId, '❌ Format: /ban &lt;user_id&gt; [alasan]', 3000);
              return;
            }
            db.run('UPDATE users SET is_banned=1, ban_reason=? WHERE chat_id=?', [reason, target], () => {
              sendTempMsg(bot, chatId, `✅ User <code>${target}</code> diblokir.\nAlasan: ${reason}`, 4000);
            });
            return;
          }

          if (text.startsWith('/unban ')) {
            const target = text.split(' ')[1];
            if (!target || isNaN(Number(target))) {
              sendTempMsg(bot, chatId, '❌ Format: /unban &lt;user_id&gt;', 3000);
              return;
            }
            db.run('UPDATE users SET is_banned=0, ban_reason="" WHERE chat_id=?', [target], () => {
              sendTempMsg(bot, chatId, `✅ User <code>${target}</code> di-unban.`, 4000);
            });
            return;
          }
        }

        if (text === '/start') {
          db.get('SELECT chat_id FROM users WHERE chat_id=?', [chatId], (err, row) => {
            if (!row) {
              db.run(
                "INSERT INTO users (chat_id, saldo, role, created_at) VALUES (?, 0, 'members', datetime('now','localtime'))",
                [chatId]
              );
            }
            sendWelcome(bot, chatId);
          });
        } else if (text === '/menu') {
          sendMainMenu(bot, chatId).catch(err => console.error('[/menu]', err.message));
        } else if (text === '/cancel') {
          userStates.delete(chatId);
          userLastMsg.delete(chatId);
          sendTempMsg(bot, chatId, '❌ Proses dibatalkan. Ketik /menu untuk kembali.', 4000);
        } else if (text === '/contact' || text?.startsWith('/contact')) {
          bot.sendMessage(chatId,
`📞 <b>HUBUNGI ADMIN</b>

👤 <b>SeorangWann</b>

📱 WhatsApp:
<a href="https://wa.me/6281312868913">wa.me/6281312868913</a>

💬 Telegram: @diwanvpn

<i>Admin siap membantu 24 jam!</i>`,
            { parse_mode: 'HTML', disable_web_page_preview: true }
          ).catch(() => {});
        }
      } finally {
        processingUsers.delete(chatId);
      }

    } catch (err) {
      console.error('[message handler] ❌', err.message);
      processingUsers.delete(msg?.chat?.id);
    }
  });

  /* ── CALLBACK QUERY ── */
  bot.on('callback_query', async (query) => {
    try {
      const chatId = query.message.chat.id;
      const msgId  = query.message.message_id;
      const data   = query.data;

      if (data.startsWith('adm_')) return;

      /* CALLBACK DEDUP */
      const now      = Date.now();
      const prevTime = lastCbTime.get(chatId);
      const prevData = lastCbData.get(chatId);
      if (prevData === data && prevTime && (now - prevTime) < CB_DEDUP_MS) {
        bot.answerCallbackQuery(query.id, { text: '⏳ Tunggu sebentar...', show_alert: false }).catch(() => {});
        return;
      }
      lastCbTime.set(chatId, now);
      lastCbData.set(chatId, data);

      bot.answerCallbackQuery(query.id).catch(() => {});
      touchSession(chatId);

      /* ── NAVIGASI ── */
      if (data === 'menu_back') {
        userStates.delete(chatId);
        userLastMsg.delete(chatId);
        const ok = await editMainMenu(bot, chatId, msgId);
        if (!ok) await sendMainMenu(bot, chatId);
        return;
      }

      if (data === 'create_menu') return editServerSelection(bot, chatId, msgId, 'create');
      if (data === 'triall_menu') return editServerSelection(bot, chatId, msgId, 'triall');
      if (data === 'renew_menu')  return getRenew().showAccountList(bot, chatId, msgId, userStates);
      if (data === 'reseller_menu') return editResellerMenu(bot, chatId, msgId);
      if (['server_sg', 'server_id', 'gaming_info', 'sosmed_info'].includes(data)) return editInfoMenu(bot, chatId, msgId, data);

      if (data.startsWith('select_')) {
        const parts = data.split('_'), type = parts[1], idx = parseInt(parts[2]);
        const LIST_SERVER = getListServer();
        const stateData = userStates.get(chatId) || {};
        userStates.set(chatId, { ...stateData, state: null, serverIp: LIST_SERVER[idx]?.ip });
        if (type === 'create') return editCreateMenu(bot, chatId, msgId);
        if (type === 'triall') return editTriallMenu(bot, chatId, msgId);
        return;
      }

      if (data.startsWith('ssh_') || data.startsWith('vme_') || data.startsWith('vle_') ||
          data.startsWith('tro_') || data.startsWith('ziv_')) {
        const [proto, action] = data.split('_');
        const typeMap = { ssh: 'ssh', vme: 'vmess', vle: 'vless', tro: 'trojan', ziv: 'zivpn' };
        const type = typeMap[proto];
        if (!type) return;

        if (action === 'create') {
          const createMod = getCreate();
          const fnMap = {
            ssh: createMod.createSSH, vmess: createMod.createVMess,
            vless: createMod.createVLess, trojan: createMod.createTrojan, zivpn: createMod.createZivpn
          };
          return fnMap[type]?.(bot, chatId, userStates, msgId);
        }
        if (action === 'triall') {
          const triallMod = getTriall();
          const fnMap = {
            ssh: triallMod.triallSSH, vmess: triallMod.triallVMess,
            vless: triallMod.triallVLess, trojan: triallMod.triallTrojan, zivpn: triallMod.triallZivpn
          };
          return fnMap[type]?.(bot, chatId, userStates, msgId);
        }
      }

      if (data === 'confirm_order') {
        const st = userStates.get(chatId);
        if (!st || st.state !== 'create_confirm') return;
        return getCreate().executeCreate(bot, chatId, userStates, st);
      }

      if (data === 'cancel_order') {
        userStates.delete(chatId);
        userLastMsg.delete(chatId);
        return editMsg(bot, chatId, msgId, '❌ Order dibatalkan.', {
          reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
        });
      }

      if (data === 'confirm_renew') {
        const st = userStates.get(chatId);
        if (!st || st.state !== 'renew_confirm') return;
        return getRenew().executeRenew(bot, chatId, userStates, st);
      }

      if (data === 'cancel_renew') {
        userStates.delete(chatId);
        userLastMsg.delete(chatId);
        return editMsg(bot, chatId, msgId, '❌ Extend dibatalkan.', {
          reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
        });
      }

      if (data === 'menu_claim_voucher') {
        userStates.set(chatId, { state: 'claim_voucher', msgId });
        return editMsg(bot, chatId, msgId,
          `┌─────────────────────┐\n` +
          `│  🎁 CLAIM SALDO GRATIS\n` +
          `└─────────────────────┘\n\n` +
          `Kamu bisa mendapatkan saldo gratis dengan kode <b>Voucher</b> yang dibagikan oleh admin.\n\n` +
          `📌 <b>Format kode:</b> <code>yan_XXXXXXX</code>\n\n` +
          `✍️ Ketik kode voucher kamu di bawah:`,
          {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_back' }]] }
          }
        );
      }

      if (data === 'menu_history')   return getTrxCmd()(bot, chatId, msgId, 0);
      if (data.startsWith('trx_p_')) {
        const page = parseInt(data.replace('trx_p_', '')) || 0;
        return getTrxCmd()(bot, chatId, msgId, page);
      }
      if (data === 'menu_stats')     return getStatsCmd()(bot, chatId, msgId);
      if (data === 'menu_referral')  return getReferralCmd()(bot, chatId, msgId);
      if (data === 'referral_claim') {
        userStates.set(chatId, { state: 'claim_referral', msgId });
        return editMsg(bot, chatId, msgId,
          `┌─────────────────────┐\n│  🔗 CLAIM KODE REFERRAL\n└─────────────────────┘\n\n` +
          `Masukkan kode referral yang kamu dapatkan dari temanmu.\n\n` +
          `📌 <b>Format:</b> <code>REF_XXXXXX</code>\n\n` +
          `✍️ Ketik kode di bawah:`,
          {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_referral' }]] }
          }
        );
      }

      /* ── Quick Reorder (buat akun baru dengan data akun sebelumnya) ── */
      if (data.startsWith('quick_reorder_')) {
        const orderId = data.replace('quick_reorder_', '');
        db.get(
          "SELECT product_type, server_ip FROM transactions WHERE order_id=? AND chat_id=?",
          [orderId, chatId],
          (err, row) => {
            if (!row) {
              return bot.sendMessage(chatId, '❌ Data akun tidak ditemukan.', {
                reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
              }).catch(() => {});
            }
            /* Simpan server IP ke state lalu arahkan ke pilihan protokol */
            const stateData = userStates.get(chatId) || {};
            userStates.set(chatId, { ...stateData, state: null, serverIp: row.server_ip });
            editCreateMenu(bot, chatId, msgId);
          }
        );
        return;
      }

      if (data === 'menu_myaccount') return getMyaccount()(bot, chatId, msgId, 0);
      if (data.startsWith('myacc_p_')) {
        const page = parseInt(data.replace('myacc_p_', '')) || 0;
        return getMyaccount()(bot, chatId, msgId, page);
      }
      if (data === 'menu_deposit')   return getMenuDeposit()(bot, chatId, msgId);

      if (data === 'menu_tambah_saldo') {
        return db.get('SELECT role FROM users WHERE chat_id=?', [chatId], async (err, row) => {
          if (!row || (row.role !== 'reseller' && row.role !== 'admin')) {
            return editMsg(bot, chatId, msgId,
              `❌ <b>Fitur ini khusus untuk Reseller.</b>\n\nTop Up minimal <b>${rp(RESELLER_MIN_TOPUP)}</b> untuk mendapatkan status Reseller secara otomatis.\n\nKlik tombol di bawah untuk top up:`,
              { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                [{ text: '💰 Top Up Sekarang', callback_data: 'menu_deposit' }],
                [{ text: '🔃 Kembali',         callback_data: 'reseller_menu' }]
              ]}}
            );
          }
          userStates.set(chatId, { state: 'tambah_saldo_reseller' });
          return editMsg(bot, chatId, msgId,
            `💰 <b>TAMBAH SALDO RESELLER</b>\n\nMasukkan jumlah top up (minimal Rp 10.000):\n<i>contoh: 50000</i>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_back' }]] } }
          );
        });
      }

      if (data.startsWith('deposit_')) {
        const amount = parseInt(data.replace('deposit_', ''));
        if (!isNaN(amount) && amount >= RESELLER_MIN_TOPUP) {
          return getQRIS().generateQRIS(bot, chatId, amount);
        }
        if (data === 'deposit_custom') {
          userStates.set(chatId, { state: 'deposit_custom' });
          return editMsg(bot, chatId, msgId,
            `✏️ <b>TOP UP KUSTOM</b>\n\nMasukkan jumlah top up (minimal ${rp(RESELLER_MIN_TOPUP)}):\n<i>contoh: 35000</i>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_back' }]] } }
          );
        }
      }

      if (data.startsWith('refresh_')) {
        const orderId = data.replace('refresh_', '');
        return getPaymentChecker().handleRefresh(bot, chatId, orderId);
      }

      /* ── BATAL QRIS ── */
      if (data.startsWith('cancel_qris_')) {
        const orderId = data.replace('cancel_qris_', '');
        try { const { clearQrisCountdown } = getQRIS(); clearQrisCountdown(orderId); } catch (_) {}
        getPaymentChecker().removePendingOrder(orderId);
        db.run("UPDATE transactions SET status='canceled' WHERE order_id=?", [orderId]);
        /* QRIS dikirim sebagai photo → pakai editMessageCaption bukan editMessageText */
        return bot.editMessageCaption(
          `❌ <b>QRIS Dibatalkan</b>\n\n` +
          `Order ID: <code>${orderId}</code>\n\n` +
          `Pembayaran dibatalkan oleh pengguna.\n` +
          `Buat order baru melalui menu di bawah.`,
          {
            chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
          }
        ).catch(() => {
          /* Fallback: kirim pesan baru jika edit gagal */
          bot.sendMessage(chatId,
            `❌ <b>QRIS Dibatalkan</b>\n\nOrder ID: <code>${orderId}</code>\n\nKetik /menu untuk buat order baru.`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] } }
          ).catch(() => {});
        });
      }

    } catch (err) {
      console.error('[callback_query] ❌', err.message);
    }
  });
}

module.exports = handler;
