// cmd/myaccount.js - v5.0 — parallel queries, no loading msg, N+1 pagination
'use strict';

const db = require('../data/db');

const PAGE_SIZE = 5;

const LABEL = {
  SSH: '⚪ SSH', VMESS: '🔵 VMess', VLESS: '🟡 VLess',
  TROJAN: '🟠 Trojan', ZIVPN: '🟢 ZivPN'
};

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) =>
    db.get(sql, params, (err, row) => err ? reject(err) : resolve(row || null))
  );
}

function dbAll(sql, params = []) {
  return new Promise((resolve, reject) =>
    db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows || []))
  );
}

function formatRow(r) {
  const now     = new Date();
  const exp     = new Date(r.expired_at);
  const sisa    = exp > now ? Math.ceil((exp - now) / 86400000) : 0;
  const isTrial = (r.product_type || '').includes('TRIAL');
  const statusIco = isTrial
    ? (sisa > 0 ? `🟡 ${sisa}hr TRIAL` : '❌ Expired')
    : (sisa > 3 ? `🟢 ${sisa}hr` : sisa > 0 ? `🟡 ${sisa}hr` : '🔴 Expired');
  const baseType = (r.product_type || '')
    .replace('RENEW ', '').replace('TRIAL-', '').replace('TRIAL ', '');
  const label = LABEL[baseType] || baseType || '?';
  return `│  ${label}: <b>${r.username || '-'}</b>\n│  📅 ${(r.expired_at || '').slice(0, 10) || '-'}  ${statusIco}\n│\n`;
}

module.exports = async function myaccountCmd(bot, chatId, msgId, page = 0) {
  try {
    const safePage = Math.max(0, page);

    /* ── Jalankan semua query paralel sekaligus ── */
    const [userRow, rows] = await Promise.all([
      dbGet('SELECT saldo, role, created_at FROM users WHERE chat_id=?', [chatId]),
      dbAll(
        "SELECT product_type, username, expired_at FROM transactions WHERE chat_id=? AND status='completed' AND product_type NOT IN ('', 'TOPUP') ORDER BY expired_at DESC LIMIT ? OFFSET ?",
        [chatId, PAGE_SIZE + 1, safePage * PAGE_SIZE]
      )
    ]);

    if (!userRow) {
      return bot.editMessageText('❌ User tidak ditemukan. Ketik /start', {
        chat_id: chatId, message_id: msgId,
        reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
      }).catch(() => {});
    }

    /* ── N+1 trick: cek ada halaman berikutnya ── */
    const hasNext  = rows.length > PAGE_SIZE;
    const pageRows = hasNext ? rows.slice(0, PAGE_SIZE) : rows;
    const hasPrev  = safePage > 0;

    /* Edge case: halaman kosong karena data berubah → mundur ke halaman sebelumnya */
    if (pageRows.length === 0 && safePage > 0) {
      return myaccountCmd(bot, chatId, msgId, safePage - 1);
    }

    const saldo    = Number(userRow.saldo) || 0;
    const role     = userRow.role || 'members';
    const joinDate = userRow.created_at ? userRow.created_at.slice(0, 10) : '-';

    let akunText = '';
    if (!pageRows.length) {
      akunText = '│  📭 Belum ada akun aktif\n';
    } else {
      pageRows.forEach(r => { akunText += formatRow(r); });
    }

    const pageLabel = (hasPrev || hasNext)
      ? `Halaman ${safePage + 1}${hasNext ? '' : ' (terakhir)'}`
      : `${pageRows.length} akun`;

    const text =
`┌─────────────────┐
│  👤 MY ACCOUNT
└─────────────────┘
│  🆔 Chat ID  : <code>${chatId}</code>
│  👑 Role     : <b>${role.toUpperCase()}</b>
│  💰 Saldo    : <b>Rp ${saldo.toLocaleString('id-ID')}</b>
│  📅 Join     : ${joinDate}
├─────────────────┤
│  📦 AKUN (${pageLabel})
├─────────────────┤
${akunText}└─────────────────┘`;

    /* ── Tombol navigasi ── */
    const navRow = [];
    if (hasPrev) navRow.push({ text: '◀️ Sebelumnya', callback_data: `myacc_p_${safePage - 1}` });
    if (hasNext) navRow.push({ text: '▶️ Berikutnya', callback_data: `myacc_p_${safePage + 1}` });

    const keyboard = [];
    if (navRow.length) keyboard.push(navRow);
    keyboard.push([
      { text: '🔄 Extend Akun',    callback_data: 'renew_menu'   },
      { text: '📜 Riwayat',        callback_data: 'menu_history' }
    ]);
    keyboard.push([{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]);

    await bot.editMessageText(text, {
      chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });

  } catch (err) {
    console.error('[myaccount]', err.message);
    bot.editMessageText('❌ Gagal memuat data. Coba lagi.', {
      chat_id: chatId, message_id: msgId,
      reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
    }).catch(() => {});
  }
};

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const protokol=args[1] // zivpn, vmess, vless, trojan
    const harga=parseInt(args[2])
    if(!global.db.pricing) global.db.pricing={member:{},seller:{}}
    if(!['member','seller'].includes(tipe)) return reply('Tipe harus member atau seller')
    if(!['zivpn','vmess','vless','trojan'].includes(protokol)) return reply('Protokol harus zivpn, vmess, vless, atau trojan')
    global.db.pricing[tipe][protokol]=harga
    reply(`✅ Harga ${protokol} untuk ${tipe} berhasil diatur menjadi Rp${harga}`)
}
break
