// cmd/menu_deposit.js - Optimized v2.0
'use strict';

module.exports = function menuDepositCmd(bot, chatId, msgId) {
  const text =
`┌─────────────────┐
│  💰 TOPUP SALDO
└─────────────────┘

Pilih nominal top up atau masukkan jumlah kustom:

Saldo masuk otomatis setelah pembayaran QRIS lunas.`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: '💸 Rp 15.000',  callback_data: 'deposit_15000'  },
        { text: '💸 Rp 20.000',  callback_data: 'deposit_20000'  }
      ],
      [
        { text: '💸 Rp 25.000',  callback_data: 'deposit_25000'  },
        { text: '💸 Rp 50.000',  callback_data: 'deposit_50000'  }
      ],
      [
        { text: '💸 Rp 75.000',  callback_data: 'deposit_75000'  },
        { text: '💸 Rp 100.000', callback_data: 'deposit_100000' }
      ],
      [{ text: '✏️ Jumlah Kustom', callback_data: 'deposit_custom'  }],
      [{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back'     }]
    ]
  };

  bot.editMessageText(text, {
    chat_id: chatId, message_id: msgId,
    reply_markup: keyboard
  }).catch(() => {});
};

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const protokol=args[1] // zivpn, vmess, vless, trojan
    const harga=parseInt(args[2])
    if(!global.db.pricing) global.db.pricing={member:{},seller:{}}
    if(!['member','seller'].includes(tipe)) return reply('Tipe harus member atau seller')
    if(!['zivpn','vmess','vless','trojan'].includes(protokol)) return reply('Protokol harus zivpn, vmess, vless, atau trojan')
    global.db.pricing[tipe][protokol]=harga
    reply(`✅ Harga ${protokol} untuk ${tipe} berhasil diatur menjadi Rp${harga}`)
}
break
