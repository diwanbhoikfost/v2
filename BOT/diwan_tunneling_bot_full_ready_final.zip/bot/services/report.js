// services/report.js
'use strict';

const db   = require('../data/db');
const fs   = require('fs');
const path = require('path');

let avars = {};
try {
  avars = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8'));
} catch (e) {
  console.warn('[report] .avars.json tidak ditemukan, laporan harian dinonaktifkan.');
}

const OWNER_ID = Number(avars.owner_id);

function sendDailyReport(bot) {
  if (!OWNER_ID) return;

  db.get(`
    SELECT COUNT(*) as total_tx, SUM(amount) as total_income
    FROM transactions
    WHERE status='completed' AND date(created_at) = date('now','localtime')
  `, [], async (err, row) => {
    const total  = row?.total_income || 0;
    const trx    = row?.total_tx    || 0;
    const tanggal = new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

    bot.sendMessage(OWNER_ID,
`📊 <b>LAPORAN HARIAN</b>

📅 ${tanggal}

💰 Total Income     : <b>Rp ${total.toLocaleString('id-ID')}</b>
📦 Total Transaksi  : <b>${trx}</b>

🔥 Keep grinding!`,
      { parse_mode: 'HTML' }
    ).catch(err => console.error('[report] Gagal kirim laporan:', err.message));
  });
}

function scheduleNextReport(bot) {
  const now  = new Date();
  const next = new Date();
  next.setHours(23, 59, 0, 0);
  if (next <= now) next.setDate(next.getDate() + 1);
  const delay = next - now;

  setTimeout(() => {
    sendDailyReport(bot);
    scheduleNextReport(bot);
  }, delay);
}

function startDailyReport(bot) {
  if (!OWNER_ID) return;
  scheduleNextReport(bot);
  console.log('[report] ✅ Daily report scheduler aktif');
}

module.exports = { startDailyReport };

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const protokol=args[1] // zivpn, vmess, vless, trojan
    const harga=parseInt(args[2])
    if(!global.db.pricing) global.db.pricing={member:{},seller:{}}
    if(!['member','seller'].includes(tipe)) return reply('Tipe harus member atau seller')
    if(!['zivpn','vmess','vless','trojan'].includes(protokol)) return reply('Protokol harus zivpn, vmess, vless, atau trojan')
    global.db.pricing[tipe][protokol]=harga
    reply(`✅ Harga ${protokol} untuk ${tipe} berhasil diatur menjadi Rp${harga}`)
}
break
