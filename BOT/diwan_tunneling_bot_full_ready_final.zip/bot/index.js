const fs = require('fs');
const path = require('path');
const TelegramBot = require('node-telegram-bot-api');

const avarsPath = path.join(__dirname, 'data', '.avars.json');
let avars;
try {
  avars = fs.existsSync(avarsPath)
    ? JSON.parse(fs.readFileSync(avarsPath, 'utf8'))
    : {};
} catch (err) {
  console.error('[BOT] ❌ Gagal baca .avars.json:', err.message);
  avars = {};
}

const token = process.env.TELEGRAM_BOT_TOKEN || avars.token;
if (!token) {
  console.error('[BOT] ❌ Token bot tidak ditemukan! Set TELEGRAM_BOT_TOKEN env var atau isi data/.avars.json');
  process.exit(1);
}

avars.token = token;

const db = require('./data/db');

db.ready.then(() => {
  console.log('[DB] ✅ Database siap, memulai bot...');

  const bot = new TelegramBot(token, {
    polling: {
      interval: 100,
      autoStart: true,
      params: { timeout: 30, allowed_updates: ['message', 'callback_query'] }
    }
  });

  bot.on('polling_error', (err) => {
    if (err.code === 'ETELEGRAM' && err.message?.includes('409')) {
      console.warn('[BOT] ⚠️ Polling conflict 409 — pastikan tidak ada instance lain berjalan.');
      return;
    }
    if (err.code === 'EFATAL') {
      console.error('[BOT] ❌ Fatal polling error, restarting in 5s:', err.message);
      setTimeout(() => process.exit(1), 5000);
      return;
    }
    console.error(`[BOT] ⚠️ Polling error: ${err.code} - ${err.message}`);
  });

  const { startDailyReport } = require('./services/report');
  startDailyReport(bot);

  const OWNER_ID_STR = String(avars.owner_id || '');

  const defaultCmds = [
    { command: 'start',   description: '🚀 Mulai Bot'      },
    { command: 'menu',    description: '📋 Menu Utama'     },
    { command: 'contact', description: '📞 Hubungi Admin'  },
  ];
  const adminCmds = [
    ...defaultCmds,
    { command: 'admin',   description: '🀄 Panel Admin'    },
    { command: 'cancel',  description: '❌ Batalkan Proses' },
  ];

  bot.setMyCommands(defaultCmds)
    .then(() => console.log('[BOT] ✅ Bot commands (default) set'))
    .catch(err => console.warn('[BOT] ⚠️ setMyCommands default:', err.message));

  if (OWNER_ID_STR) {
    bot.setMyCommands(adminCmds, { scope: { type: 'chat', chat_id: Number(OWNER_ID_STR) } })
      .then(() => console.log('[BOT] ✅ Bot commands (admin) set'))
      .catch(err => console.warn('[BOT] ⚠️ setMyCommands admin:', err.message));
  }

  console.log(`\n[${avars.bot_name || 'BOT'}] ✅ Status: Online 🚀`);

  if (avars.owner_id) {
    db.run(
      "INSERT OR IGNORE INTO users (chat_id, saldo, role, created_at) VALUES (?, 0, 'admin', datetime('now','localtime'))",
      [String(avars.owner_id)],
      () => {
        db.run("UPDATE users SET role='admin' WHERE chat_id=? AND role != 'admin'", [String(avars.owner_id)]);
      }
    );
  }

  try {
    const admin = require('./cmd/admin');
    admin(bot);
    console.log('[BOT] ✅ Admin panel aktif');
  } catch (err) {
    console.error('[BOT] ❌ Gagal load admin:', err.message);
  }

  try {
    const runHandler = require('./handler');
    runHandler(bot);
    console.log('[BOT] ✅ Handler loaded');
  } catch (err) {
    console.error('[BOT] ❌ Gagal load handler:', err.message);
  }

  try {
    const { startPaymentChecker } = require('./services/paymentChecker');
    startPaymentChecker(bot);
    console.log('[BOT] ✅ Payment checker aktif');
  } catch (err) {
    console.error('[BOT] ❌ Gagal start payment checker:', err.message);
  }

  try {
    const { startExpiredNotif } = require('./services/expiredNotif');
    startExpiredNotif(bot);
    console.log('[BOT] ✅ Expired notif aktif');
  } catch (err) {
    console.error('[BOT] ❌ Gagal start expired notif:', err.message);
  }

  try {
    const { startAutoDelete } = require('./services/autoDelete');
    startAutoDelete(bot);
    console.log('[BOT] ✅ Auto-delete akun expired aktif');
  } catch (err) {
    console.error('[BOT] ❌ Gagal start auto-delete:', err.message);
  }

  console.log('[BOT] 🚀 Bot running, siap melayani order!\n');

}).catch(err => {
  console.error('[DB] ❌ Gagal init database:', err.message);
  process.exit(1);
});

process.on('uncaughtException', (err) => {
  console.error('[BOT] 🔥 Uncaught Exception:', err.stack || err.message);
});

process.on('unhandledRejection', (reason) => {
  console.error('[BOT] 🔥 Unhandled Rejection:', reason?.stack || reason);
});

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const protokol=args[1] // zivpn, vmess, vless, trojan
    const harga=parseInt(args[2])
    if(!global.db.pricing) global.db.pricing={member:{},seller:{}}
    if(!['member','seller'].includes(tipe)) return reply('Tipe harus member atau seller')
    if(!['zivpn','vmess','vless','trojan'].includes(protokol)) return reply('Protokol harus zivpn, vmess, vless, atau trojan')
    global.db.pricing[tipe][protokol]=harga
    reply(`✅ Harga ${protokol} untuk ${tipe} berhasil diatur menjadi Rp${harga}`)
}
break
