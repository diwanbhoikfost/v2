// services/qris.js - v4.0 — 10min countdown live seconds, cancel button
'use strict';

const axios  = require('axios');
const QRCode = require('qrcode');
const fs     = require('fs');
const path   = require('path');
const db     = require('../data/db');

let avars = {};
try {
  avars = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/.avars.json'), 'utf8'));
} catch (e) {
  console.warn('[qris] .avars.json tidak ditemukan.');
}

const QRIS_EXPIRY_MS  = 10 * 60 * 1000;  // 10 menit
const UPDATE_INTERVAL = 10 * 1000;        // update tiap 10 detik (countdown terlihat berjalan)

/* Map untuk menyimpan countdown intervals agar bisa di-cancel saat bayar */
const countdownIntervals = new Map();

function clearCountdown(orderId) {
  const iv = countdownIntervals.get(orderId);
  if (iv) { clearInterval(iv); countdownIntervals.delete(orderId); }
}

module.exports.clearQrisCountdown = clearCountdown;

async function generateQRIS(bot, chatId, amount, pendingInfo = {}) {
  const orderId = `${chatId}_${Date.now()}`;

  const apiKey = process.env.PAKASIR_API_KEY || avars.pakasir_api_key;
  if (!avars.pakasir_slug || !apiKey) {
    return bot.sendMessage(chatId, '❌ Konfigurasi payment belum lengkap. Hubungi admin.');
  }

  try {
    const createRes = await axios.post('https://app.pakasir.com/api/transactioncreate/qris', {
      project:  avars.pakasir_slug,
      order_id: orderId,
      amount,
      api_key:  apiKey
    }, { timeout: 15000 });

    const txData = createRes.data;
    if (!txData.payment?.payment_number) throw new Error('Gagal dapat QR string dari Pakasir');

    const qrBuffer = await QRCode.toBuffer(txData.payment.payment_number, { width: 350 });

    const productType = pendingInfo.productType || '';
    db.run(
      "INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type) VALUES (?, ?, ?, 'pending', datetime('now','localtime'), ?)",
      [chatId, orderId, amount, productType]
    );

    const isCreate = !!pendingInfo.accountCreate;
    const isRenew  = !!pendingInfo.accountRenew;

    function buildCaption(remainingMs) {
      const totalSecs = Math.max(0, Math.floor(remainingMs / 1000));
      const mm  = String(Math.floor(totalSecs / 60)).padStart(2, '0');
      const ss  = String(totalSecs % 60).padStart(2, '0');
      const pct = Math.max(0, remainingMs / QRIS_EXPIRY_MS);  // 1.0 → 0.0

      const bar = pct >= 0.80 ? '🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩'
        : pct >= 0.60 ? '🟩🟩🟩🟩🟩🟩🟩🟩⬜⬜'
        : pct >= 0.40 ? '🟩🟩🟩🟩🟩🟩⬜⬜⬜⬜'
        : pct >= 0.20 ? '🟨🟨🟨🟨⬜⬜⬜⬜⬜⬜'
        : '🟥🟥⬜⬜⬜⬜⬜⬜⬜⬜';

      let typeLabel = '';
      if (isCreate)     typeLabel = `💳 <b>PEMBAYARAN AKUN ${pendingInfo.productName || ''}</b>`;
      else if (isRenew) typeLabel = `💳 <b>PEMBAYARAN EXTEND ${pendingInfo.productName || ''}</b>`;
      else              typeLabel = `💳 <b>TOP UP SALDO</b>`;

      return `${typeLabel}\n\n` +
        `💰 Nominal  : <b>Rp ${amount.toLocaleString('id-ID')}</b>\n` +
        `🧾 Order ID : <code>${orderId}</code>\n\n` +
        `⏰ Kadaluarsa : <b>${mm}:${ss}</b>\n` +
        `${bar}\n\n` +
        `⚡ ${isCreate ? 'Akun <b>otomatis dibuat</b>' : isRenew ? 'Akun <b>otomatis di-extend</b>' : 'Saldo <b>otomatis masuk</b>'} setelah lunas!\n\n` +
        `<i>Scan QR di atas dengan aplikasi dompet digital Anda.</i>`;
    }

    const cancelKeyboard = {
      inline_keyboard: [
        [{ text: '🔄 Cek Status Bayar', callback_data: `refresh_${orderId}` }],
        [{ text: '❌ Batalkan QRIS',    callback_data: `cancel_qris_${orderId}` }]
      ]
    };

    const startTime = Date.now();
    const photoMsg  = await bot.sendPhoto(chatId, qrBuffer, {
      caption:    buildCaption(QRIS_EXPIRY_MS),
      parse_mode: 'HTML',
      reply_markup: cancelKeyboard
    });

    const qrMsgId = photoMsg?.message_id;

    /* ── COUNTDOWN setiap 10 detik ── */
    const iv = setInterval(() => {
      const elapsed   = Date.now() - startTime;
      const remaining = QRIS_EXPIRY_MS - elapsed;

      if (remaining <= 0) {
        clearInterval(iv);
        countdownIntervals.delete(orderId);
        bot.editMessageCaption(`❌ <b>QRIS Kadaluarsa</b>\n\nOrder ID: <code>${orderId}</code>\n\nBuat order baru melalui /menu.`, {
          chat_id: chatId, message_id: qrMsgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali ke Menu', callback_data: 'menu_back' }]] }
        }).catch(() => {});
        return;
      }

      bot.editMessageCaption(buildCaption(remaining), {
        chat_id: chatId, message_id: qrMsgId, parse_mode: 'HTML',
        reply_markup: cancelKeyboard
      }).catch(() => {});
    }, UPDATE_INTERVAL);

    countdownIntervals.set(orderId, iv);

    const { addPendingOrder } = require('./paymentChecker');
    addPendingOrder(orderId, {
      chatId,
      amount,
      qrMsgId,
      productName:   pendingInfo.productName   || 'Topup Saldo',
      productType,
      accountCreate: pendingInfo.accountCreate || null,
      accountRenew:  pendingInfo.accountRenew  || null
    });

  } catch (err) {
    console.error('[generateQRIS] ❌', err.message);
    bot.sendMessage(chatId, '❌ Gagal membuat QRIS: ' + err.message);
  }
}

module.exports.generateQRIS = generateQRIS;

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const harga=parseInt(args[1])
    if(!global.db.pricing) global.db.pricing={member:0,seller:0}
    if(tipe==='member') global.db.pricing.member=harga
    if(tipe==='seller') global.db.pricing.seller=harga
    reply(`✅ Harga ${tipe} telah diatur menjadi Rp${harga}`)
}
break
