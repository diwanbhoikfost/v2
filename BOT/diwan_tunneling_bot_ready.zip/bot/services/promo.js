// services/promo.js
'use strict';

const fs   = require('fs');
const path = require('path');

const file   = path.join(__dirname, '../data/promo.json');
let _cache   = null;

function getPromo() {
  if (!_cache) {
    try { _cache = JSON.parse(fs.readFileSync(file, 'utf8')); }
    catch (e) { _cache = { active: false, bonus: 20, min: 15000 }; }
  }
  return _cache;
}

function setPromo(status) {
  const data  = getPromo();
  data.active = status;
  _cache      = data;
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function updatePromo(bonus, min) {
  const data = getPromo();
  data.bonus = bonus;
  data.min   = min;
  _cache     = data;
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function calculateBonus(amount) {
  const promo = getPromo();
  if (!promo.active) return amount;
  const min         = Number(promo.min) || 0;
  const bonusPct    = Number(promo.bonus) || 0;
  if (amount < min) return amount;
  const bonus = Math.floor(amount * bonusPct / 100);
  return amount + bonus;
}

module.exports = { getPromo, setPromo, updatePromo, calculateBonus };

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const harga=parseInt(args[1])
    if(!global.db.pricing) global.db.pricing={member:0,seller:0}
    if(tipe==='member') global.db.pricing.member=harga
    if(tipe==='seller') global.db.pricing.seller=harga
    reply(`✅ Harga ${tipe} telah diatur menjadi Rp${harga}`)
}
break
