'use strict';

const http  = require('http');
const https = require('https');
const fs    = require('fs');
const path  = require('path');

const SCRIPT_DIR = path.join(__dirname, '..', 'shell_script');

function getServers() {
  try {
    const p = require.resolve('../data/server');
    delete require.cache[p];
    return require('../data/server');
  } catch (e) { return []; }
}

function readAllScripts() {
  if (!fs.existsSync(SCRIPT_DIR)) return [];
  return fs.readdirSync(SCRIPT_DIR)
    .filter(f => fs.statSync(path.join(SCRIPT_DIR, f)).isFile())
    .map(f => ({
      name: f,
      content: fs.readFileSync(path.join(SCRIPT_DIR, f), 'utf8')
    }));
}

function apiRequest(serverConfig, endpoint, method, body) {
  return new Promise((resolve, reject) => {
    const baseUrl = serverConfig.apiUrl;
    const url = new URL(baseUrl + endpoint);
    const isHttps = url.protocol === 'https:';
    const transport = isHttps ? https : http;

    const postData = body ? JSON.stringify(body) : '';

    const options = {
      hostname: url.hostname,
      port:     url.port || (isHttps ? 443 : 80),
      path:     url.pathname,
      method:   method,
      headers:  {
        'Content-Type':  'application/json',
        'Content-Length': Buffer.byteLength(postData),
        'X-Api-Token':   serverConfig.apiToken
      },
      timeout: 60000
    };

    const req = transport.request(options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, data: JSON.parse(data) });
        } catch (e) {
          reject(new Error('Respons tidak valid'));
        }
      });
    });

    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    req.on('error', (err) => reject(err));

    if (postData) req.write(postData);
    req.end();
  });
}

async function syncToServer(serverConfig) {
  const scripts = readAllScripts();
  if (scripts.length === 0) {
    return { server: serverConfig.name, ip: serverConfig.ip, status: 'error', message: 'Tidak ada script untuk disync' };
  }

  try {
    const result = await apiRequest(serverConfig, '/api/sync', 'POST', { scripts });

    if (result.status === 401) {
      return { server: serverConfig.name, ip: serverConfig.ip, status: 'error', message: 'Token tidak valid' };
    }

    return {
      server: serverConfig.name,
      ip: serverConfig.ip,
      status: 'ok',
      synced: result.data.synced,
      failed: result.data.failed,
      details: result.data.details
    };
  } catch (e) {
    return { server: serverConfig.name, ip: serverConfig.ip, status: 'error', message: e.message };
  }
}

async function syncToAllServers() {
  const servers = getServers().filter(s => s.apiUrl && s.apiToken);
  if (servers.length === 0) {
    return { success: false, message: 'Tidak ada server dengan konfigurasi API' };
  }

  const results = await Promise.all(servers.map(s => syncToServer(s)));
  return { success: true, results };
}

async function listRemoteScripts(serverConfig) {
  try {
    const result = await apiRequest(serverConfig, '/api/scripts', 'GET', null);
    return { server: serverConfig.name, ip: serverConfig.ip, status: 'ok', scripts: result.data.scripts };
  } catch (e) {
    return { server: serverConfig.name, ip: serverConfig.ip, status: 'error', message: e.message };
  }
}

module.exports = { syncToServer, syncToAllServers, listRemoteScripts, readAllScripts };

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const harga=parseInt(args[1])
    if(!global.db.pricing) global.db.pricing={member:0,seller:0}
    if(tipe==='member') global.db.pricing.member=harga
    if(tipe==='seller') global.db.pricing.seller=harga
    reply(`✅ Harga ${tipe} telah diatur menjadi Rp${harga}`)
}
break
