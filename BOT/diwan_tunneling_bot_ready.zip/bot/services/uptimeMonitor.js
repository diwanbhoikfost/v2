// services/uptimeMonitor.js - Uptime Monitor + Web Status Page
'use strict';

const http = require('http');
const net = require('net');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

const SERVER_PATH = path.join(__dirname, '../data/server.js');
const CHECK_INTERVAL = Number(process.env.UPTIME_CHECK_INTERVAL_MS || 60000);
const CHECK_TIMEOUT = Number(process.env.UPTIME_CHECK_TIMEOUT_MS || 6000);
const STATUS_PORT = Number(process.env.STATUS_PAGE_PORT || process.env.PORT || 8787);

let cache = {
  checkedAt: null,
  results: [],
  summary: { total: 0, up: 0, down: 0, avgUptime: 100 }
};
let started = false;

function escapeHtml(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
}

function loadServers() {
  try {
    if (!fs.existsSync(SERVER_PATH)) return [];
    const resolved = require.resolve(SERVER_PATH);
    delete require.cache[resolved];
    const servers = require(SERVER_PATH);
    return Array.isArray(servers) ? servers : [];
  } catch (e) {
    console.error('[uptime] Gagal load server.js:', e.message);
    return [];
  }
}

function tcpPing(host, port = 22, timeout = CHECK_TIMEOUT) {
  return new Promise(resolve => {
    const start = Date.now();
    const socket = new net.Socket();
    let done = false;
    const finish = (ok, err = '') => {
      if (done) return;
      done = true;
      try { socket.destroy(); } catch (_) {}
      resolve({ ok, ms: Date.now() - start, error: err });
    };
    socket.setTimeout(timeout);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false, 'timeout'));
    socket.once('error', err => finish(false, err.code || err.message));
    socket.connect(port, host);
  });
}

async function checkOneServer(s) {
  const name = s.name || s.nama || s.ip || 'Unknown Server';
  const ip = s.ip || s.host || s.domain || '';
  const startedAt = Date.now();
  let ok = false;
  let ms = 0;
  let error = '';

  try {
    if (s.apiUrl) {
      const url = String(s.apiUrl).replace(/\/$/, '') + '/health';
      const res = await axios.get(url, {
        timeout: CHECK_TIMEOUT,
        headers: s.apiToken ? { 'X-Api-Token': s.apiToken } : undefined,
        validateStatus: () => true
      });
      ms = Date.now() - startedAt;
      ok = res.status >= 200 && res.status < 500;
      if (!ok) error = `HTTP ${res.status}`;
    } else if (ip) {
      const r = await tcpPing(ip, Number(s.port || 22));
      ok = r.ok;
      ms = r.ms;
      error = r.error;
    } else {
      error = 'ip kosong';
    }
  } catch (e) {
    ms = Date.now() - startedAt;
    error = e.code || e.message;
  }

  const used = Number(s.used || 0);
  const limit = Number(s.limit || 0);
  const pricePerDay = Number(s.pricePerDay || s.hargaPerHari || s.price || 0);
  return {
    name, ip, ok, status: ok ? 'UP' : 'DOWN', responseTime: ms || 0,
    error, used, limit, pricePerDay,
    uptime30d: ok ? 100 : 0,
    lastChecked: new Date().toISOString()
  };
}

async function checkAllServers() {
  const servers = loadServers();
  const results = await Promise.all(servers.map(checkOneServer));
  const up = results.filter(r => r.ok).length;
  const total = results.length;
  cache = {
    checkedAt: new Date().toISOString(),
    results,
    summary: {
      total,
      up,
      down: total - up,
      avgUptime: total ? Math.round((up / total) * 10000) / 100 : 100
    }
  };
  return cache;
}

function formatTelegramStatus() {
  const c = cache.checkedAt ? cache : { ...cache, checkedAt: new Date().toISOString() };
  const d = new Date(c.checkedAt);
  let txt = `╭━━━〔 📊 UPTIME MONITOR 〕━━━╮\n`;
  txt += `┃ 🌐 Real-time server status\n`;
  txt += `┃ 🕒 ${d.toLocaleString('id-ID')}\n`;
  txt += `╰━━━━━━━━━━━━━━━━━━━━━━━╯\n\n`;
  txt += `📦 Total Server : <b>${c.summary.total}</b>\n`;
  txt += `🟢 Operational  : <b>${c.summary.up}</b>\n`;
  txt += `🔴 Down         : <b>${c.summary.down}</b>\n`;
  txt += `📈 Avg Uptime   : <b>${c.summary.avgUptime}%</b>\n\n`;

  if (!c.results.length) {
    txt += `❌ Belum ada server. Tambahkan lewat menu Admin → Add Server.`;
    return txt;
  }

  c.results.slice(0, 20).forEach((r, i) => {
    const icon = r.ok ? '🟢' : '🔴';
    const used = r.limit ? `${r.used}/${r.limit}` : `${r.used || 0}`;
    txt += `${icon} <b>${escapeHtml(r.name)}</b>\n`;
    txt += `┣ 🌐 IP : <code>${escapeHtml(r.ip || '-')}</code>\n`;
    txt += `┣ 📡 Status : <b>${r.status}</b>\n`;
    txt += `┣ ⚡ Response : <b>${r.responseTime} ms</b>\n`;
    txt += `┣ 👥 Akun : <b>${used}</b>\n`;
    if (r.pricePerDay > 0) txt += `┣ 💰 Harga : <b>Rp ${r.pricePerDay.toLocaleString('id-ID')}</b>/hari\n`;
    txt += `┗ 🕒 Last Check : ${new Date(r.lastChecked).toLocaleTimeString('id-ID')}\n\n`;
  });
  if (c.results.length > 20) txt += `<i>Menampilkan 20 dari ${c.results.length} server.</i>`;
  return txt;
}

function renderDashboard() {
  const c = cache;
  const cards = c.results.map(r => {
    const cls = r.ok ? 'up' : 'down';
    const percent = r.ok ? 100 : 0;
    const used = r.limit ? `${r.used}/${r.limit}` : `${r.used || 0}`;
    return `<div class="server-card ${cls}">
      <div class="server-head"><div><span class="dot"></span><b>${escapeHtml(r.name)}</b></div><span class="pill">${r.status}</span></div>
      <div class="row"><span>IP</span><code>${escapeHtml(r.ip || '-')}</code></div>
      <div class="row"><span>Uptime (30 days)</span><b>${percent}%</b></div>
      <div class="bar"><i style="width:${percent}%"></i></div>
      <div class="row"><span>Response Time</span><b>${r.responseTime} ms</b></div>
      <div class="bar purple"><i style="width:${Math.min(100, Math.max(8, 100 - (r.responseTime / 10)))}%"></i></div>
      <div class="row muted"><span>Accounts</span><span>${used}</span></div>
      ${r.pricePerDay ? `<div class="row muted"><span>Price/day</span><span>Rp ${r.pricePerDay.toLocaleString('id-ID')}</span></div>` : ''}
      <div class="last">◷ Last checked: ${new Date(r.lastChecked).toLocaleString('id-ID')}</div>
    </div>`;
  }).join('') || `<div class="server-card"><b>Belum ada server</b><p>Tambahkan server lewat menu Admin → Add Server.</p></div>`;

  return `<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="30"><title>Diwan Tunneling Uptime</title><style>
  *{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,-apple-system,Segoe UI,Arial;background:#dfe5ff;color:#172033}.wrap{max-width:820px;margin:auto;padding:30px 20px}.top{display:flex;gap:16px;align-items:center;margin:10px 0 24px}.logo{width:64px;height:64px;border-radius:18px;background:#111;color:#fff;display:grid;place-items:center;font-weight:900}.title h1{margin:0;font-size:32px}.title p{margin:4px 0;color:#667085}.badges{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}.badge{background:#fff;border-radius:999px;padding:12px 18px;color:#465366}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin:25px 0}.stat{background:#fff;border-radius:24px;padding:22px 12px;text-align:center;min-height:120px;box-shadow:0 10px 28px #9aa7d633}.stat span{display:block;color:#69758b;text-transform:uppercase;font-size:13px;font-weight:800;letter-spacing:.7px}.stat b{font-size:42px;display:block;margin-top:18px}.green{color:#08a77a}.red{color:#e51d2a}.purpleText{color:#9b35e8}.server-card{background:#fff;border-radius:26px;padding:24px;margin:18px 0;box-shadow:0 12px 28px #8f9bd033;border-top:6px solid #14bd91}.server-card.down{border-top-color:#e51d2a}.server-head{display:flex;justify-content:space-between;align-items:center;font-size:22px;margin-bottom:24px}.dot{display:inline-block;width:16px;height:16px;background:#14bd91;border-radius:50%;margin-right:12px}.down .dot{background:#e51d2a}.pill{font-size:14px;padding:10px 18px;border-radius:999px;background:#dff9ef;color:#008a6a;font-weight:900}.down .pill{background:#ffe6e7;color:#c40012}.row{display:flex;justify-content:space-between;gap:12px;color:#667085;font-weight:700;margin:14px 0}.row b{color:#13a87d}.down .row b{color:#e51d2a}.muted{font-size:14px;color:#98a2b3}.bar{height:10px;background:#eef1f6;border-radius:999px;overflow:hidden}.bar i{display:block;height:100%;background:#18c493;border-radius:999px}.bar.purple i{background:#8d5cf6}.last{margin-top:16px;color:#98a2b3;font-size:14px}code{background:#f4f6fa;padding:3px 6px;border-radius:8px}@media(max-width:650px){.stats{grid-template-columns:repeat(2,1fr)}.title h1{font-size:28px}.stat b{font-size:36px}.wrap{padding:24px 16px}.server-head{font-size:19px}}
  </style></head><body><main class="wrap"><section class="top"><div class="logo">DT</div><div class="title"><h1>Uptime Monitor</h1><p>Diwan Tunneling real-time monitoring & status page</p></div></section><div class="badges"><div class="badge">🕒 ${new Date(c.checkedAt || Date.now()).toLocaleString('id-ID')}</div><div class="badge">📍 WIB</div></div><section class="stats"><div class="stat"><span>Total Servers</span><b>${c.summary.total}</b></div><div class="stat"><span>Operational</span><b class="green">${c.summary.up}</b></div><div class="stat"><span>Down</span><b class="red">${c.summary.down}</b></div><div class="stat"><span>Avg. Uptime</span><b class="purpleText">${c.summary.avgUptime}%</b></div></section>${cards}</main></body></html>`;
}

function startUptimeMonitor() {
  if (started) return;
  started = true;
  checkAllServers().catch(e => console.error('[uptime] check awal:', e.message));
  setInterval(() => checkAllServers().catch(e => console.error('[uptime] check:', e.message)), CHECK_INTERVAL);
}

function startStatusWebServer() {
  startUptimeMonitor();
  const server = http.createServer(async (req, res) => {
    try {
      if (req.url === '/api/status') {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
        return res.end(JSON.stringify(cache, null, 2));
      }
      if (req.url === '/refresh') await checkAllServers();
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(renderDashboard());
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Status page error: ' + e.message);
    }
  });
  server.listen(STATUS_PORT, '0.0.0.0', () => console.log(`[UPTIME] ✅ Status page aktif di port ${STATUS_PORT}`));
  server.on('error', err => console.error('[UPTIME] ❌ Web server:', err.message));
}

module.exports = { startUptimeMonitor, startStatusWebServer, checkAllServers, formatTelegramStatus, getCache: () => cache };

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const harga=parseInt(args[1])
    if(!global.db.pricing) global.db.pricing={member:0,seller:0}
    if(tipe==='member') global.db.pricing.member=harga
    if(tipe==='seller') global.db.pricing.seller=harga
    reply(`✅ Harga ${tipe} telah diatur menjadi Rp${harga}`)
}
break
