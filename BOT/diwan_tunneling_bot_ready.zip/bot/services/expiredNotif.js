// services/expiredNotif.js - Optimized v2.0
'use strict';

const db = require('../data/db');

const LABEL = {
  SSH:    '⚪ SSH / OpenVPN',
  VMESS:  '🔵 xRay VMess',
  VLESS:  '🟡 xRay VLess',
  TROJAN: '🟠 xRay Trojan',
  ZIVPN:  '🟢 UDP ZivPN'
};

function initNotifTable() {
  db.run(`CREATE TABLE IF NOT EXISTS notif_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    days_before INTEGER,
    sent_at TEXT,
    UNIQUE(order_id, days_before)
  )`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_notif_order ON notif_log(order_id, days_before)`);
}

function sudahDikirim(orderId, daysBefore, callback) {
  db.get(
    'SELECT id FROM notif_log WHERE order_id=? AND days_before=?',
    [orderId, daysBefore],
    (err, row) => callback(!!row)
  );
}

function tandaiTerkirim(chatId, orderId, daysBefore) {
  db.run(
    "INSERT OR IGNORE INTO notif_log (chat_id, order_id, days_before, sent_at) VALUES (?, ?, ?, datetime('now','localtime'))",
    [chatId, orderId, daysBefore]
  );
}

function kirimNotif(bot, row, days) {
  const label = LABEL[row.product_type] || row.product_type;
  const emoji = days === 1 ? '🔴' : '🟡';
  const expStr = row.expired_at ? row.expired_at.slice(0, 10) : '-';

  bot.sendMessage(row.chat_id,
`${emoji} <b>PERINGATAN! Akun akan expired!</b>

${label}
👤 Username : <code>${row.username || '-'}</code>
📅 Expired  : <b>${expStr}</b>
⏳ Sisa     : <b>${days} hari lagi</b>

Segera perpanjang agar akun tidak mati!`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔄 Extend Sekarang', callback_data: 'renew_menu' }],
          [{ text: '🛒 Ke Menu Utama',   callback_data: 'menu_back'  }]
        ]
      }
    }
  ).catch(() => {});
}

function cekDanKirim(bot) {
  [3, 1].forEach(days => {
    const sql = `
      SELECT t.chat_id, t.order_id, t.product_type, t.username, t.expired_at
      FROM transactions t
      WHERE t.status = 'completed'
        AND t.expired_at IS NOT NULL AND t.expired_at != ''
        AND t.product_type NOT IN ('', 'TOPUP')
        AND t.product_type NOT LIKE 'TRIAL%'
        AND date(t.expired_at) = date('now', 'localtime', '+${days} days')
    `;

    db.all(sql, [], (err, rows) => {
      if (err || !rows?.length) return;

      rows.forEach((row, i) => {
        sudahDikirim(row.order_id, days, (sudah) => {
          if (sudah) return;
          setTimeout(() => {
            kirimNotif(bot, row, days);
            tandaiTerkirim(row.chat_id, row.order_id, days);
          }, i * 300);
        });
      });
    });
  });
}

function startExpiredNotif(bot) {
  initNotifTable();
  setTimeout(() => cekDanKirim(bot), 15000);
  setInterval(() => cekDanKirim(bot), 60 * 60 * 1000);
  console.log('[expiredNotif] ✅ Expired notif aktif (cek tiap 1 jam)');
}

module.exports = { startExpiredNotif };

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const harga=parseInt(args[1])
    if(!global.db.pricing) global.db.pricing={member:0,seller:0}
    if(tipe==='member') global.db.pricing.member=harga
    if(tipe==='seller') global.db.pricing.seller=harga
    reply(`✅ Harga ${tipe} telah diatur menjadi Rp${harga}`)
}
break
