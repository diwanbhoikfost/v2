const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, 'yanbot.db');

let SQL;
let betterDb;

function getDb() {
  if (!betterDb) throw new Error('Database belum siap');
  return betterDb;
}

function saveDb() {
  try {
    const data = betterDb.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  } catch (e) {
    console.error('[DB] ❌ Gagal save:', e.message);
  }
}

let saveTimer = null;
function debounceSave() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(saveDb, 500);
}

async function initDb() {
  SQL = await initSqlJs();
  try {
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      betterDb = new SQL.Database(fileBuffer);
      console.log('[DB] ✅ Database loaded:', dbPath);
    } else {
      betterDb = new SQL.Database();
      console.log('[DB] ✅ Database created:', dbPath);
    }
  } catch (err) {
    console.error('[DB] ⚠️ DB file corrupt, creating new:', err.message);
    betterDb = new SQL.Database();
  }

  betterDb.run('PRAGMA journal_mode = WAL');
  betterDb.run('PRAGMA synchronous = NORMAL');
  betterDb.run('PRAGMA cache_size = 4000');
  betterDb.run('PRAGMA temp_store = MEMORY');
  betterDb.run('PRAGMA busy_timeout = 5000');

  betterDb.run(`CREATE TABLE IF NOT EXISTS users (
    chat_id INTEGER PRIMARY KEY,
    saldo INTEGER DEFAULT 0,
    role TEXT DEFAULT 'members',
    created_at TEXT
  )`);

  betterDb.run(`CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    amount INTEGER,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    product_type TEXT DEFAULT ''
  )`);

  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN username TEXT DEFAULT ''`); } catch {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN expired_at TEXT DEFAULT ''`); } catch {}
  try { betterDb.run(`ALTER TABLE transactions ADD COLUMN server_ip TEXT DEFAULT ''`); } catch {}

  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_chat_id ON transactions(chat_id)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_status ON transactions(status)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_created_at ON transactions(created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_status_created ON transactions(status, created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_trx_chatid_status ON transactions(chat_id, status, created_at)`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)`);

  betterDb.run(`CREATE TABLE IF NOT EXISTS notif_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    days_before INTEGER,
    sent_at TEXT,
    UNIQUE(order_id, days_before)
  )`);
  betterDb.run(`CREATE INDEX IF NOT EXISTS idx_notif_order ON notif_log(order_id, days_before)`);

  saveDb();

  setInterval(saveDb, 30000);
}

const db = {
  run(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      getDb().run(sql, params);
      const info = { lastID: 0, changes: getDb().getRowsModified() };
      debounceSave();
      if (callback) callback.call(info, null);
    } catch (err) {
      if (callback) callback.call({}, err);
    }
  },

  get(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      const stmt = getDb().prepare(sql);
      stmt.bind(params);
      let row = null;
      if (stmt.step()) {
        const cols = stmt.getColumnNames();
        const vals = stmt.get();
        row = {};
        cols.forEach((c, i) => { row[c] = vals[i]; });
      }
      stmt.free();
      if (callback) callback(null, row);
    } catch (err) {
      if (callback) callback(err, null);
    }
  },

  all(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    params = params || [];
    try {
      const stmt = getDb().prepare(sql);
      stmt.bind(params);
      const rows = [];
      while (stmt.step()) {
        const cols = stmt.getColumnNames();
        const vals = stmt.get();
        const row = {};
        cols.forEach((c, i) => { row[c] = vals[i]; });
        rows.push(row);
      }
      stmt.free();
      if (callback) callback(null, rows);
    } catch (err) {
      if (callback) callback(err, []);
    }
  },

  exec(sql, callback) {
    try {
      getDb().exec(sql);
      debounceSave();
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  },

  serialize(fn) {
    if (fn) fn();
  },

  close(callback) {
    try {
      saveDb();
      getDb().close();
      if (callback) callback(null);
    } catch (err) {
      if (callback) callback(err);
    }
  },

  ready: initDb()
};

module.exports = db;

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const harga=parseInt(args[1])
    if(!global.db.pricing) global.db.pricing={member:0,seller:0}
    if(tipe==='member') global.db.pricing.member=harga
    if(tipe==='seller') global.db.pricing.seller=harga
    reply(`✅ Harga ${tipe} telah diatur menjadi Rp${harga}`)
}
break
