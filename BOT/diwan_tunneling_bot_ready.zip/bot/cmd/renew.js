// cmd/renew.js - v4.0 — admin free, reseller 3 IP, 100% first, filter output
'use strict';

const db   = require('../data/db');
const path = require('path');
const fs   = require('fs');
const { executeScriptRemote } = require('../services/ssh-exec');
const { generateQRIS } = require('../services/qris');
const { autoMenu }     = require('../utils/autoMenu');
const { friendlyError, hasErrorCode } = require('../services/error-messages');

/* ─────────────── PRICES CACHE ─────────────── */
const PRICES_PATH = path.join(__dirname, '../data/prices.js');
const { resolvePrice } = require('../utils/priceManager');
let _pricesCache  = null;
function getPrices() {
  if (!_pricesCache) {
    try { const p = require.resolve(PRICES_PATH); delete require.cache[p]; _pricesCache = require(PRICES_PATH); }
    catch (e) { return { reseller: {}, members: {} }; }
  }
  return _pricesCache;
}
fs.watchFile(PRICES_PATH, { interval: 5000 }, () => { _pricesCache = null; });

/* ─────────────── DEFAULTS ─────────────── */
const DEFAULT_IP    = 1;
const DEFAULT_QUOTA = 1;

const SCRIPT_MAP = {
  SSH:    { scriptName: 'sshRENEW', priceKey: 'ssh',      isXray: false },
  VMESS:  { scriptName: 'vmeRENEW', priceKey: 'vmess',    isXray: true  },
  VLESS:  { scriptName: 'vleRENEW', priceKey: 'vless',    isXray: true  },
  TROJAN: { scriptName: 'troRENEW', priceKey: 'trojan',   isXray: true  },
  ZIVPN:  { scriptName: 'zivRENEW', priceKey: 'udpzivpn', isXray: false }
};

const TYPE_LABEL = {
  SSH:    '⚪ SSH / OpenVPN',
  VMESS:  '🔵 xRay VMess',
  VLESS:  '🟡 xRay VLess',
  TROJAN: '🟠 xRay Trojan',
  ZIVPN:  '🟢 UDP ZivPN'
};

function getServerByIp(serverIp) {
  try {
    const sp = require.resolve('../data/server');
    delete require.cache[sp];
    const servers = require('../data/server');
    return servers.find(s => s.ip === serverIp) || null;
  } catch (e) { return null; }
}

function getPrice(role, priceKey, serverIp, limitIp) {
  const server = getServerByIp(serverIp);
  return resolvePrice({ role, protocol: priceKey, server, limitIp });
}

function formatRp(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }

/* admin: gratis; reseller: 3 free IP; members: 1 free IP */
function calcExtraIP(role, limitIp) {
  if (role === 'admin') return 0;
  const freeIPs = role === 'reseller' ? 3 : 1;
  return limitIp > freeIPs ? (limitIp - freeIPs) * 500 : 0;
}

function quotaSurcharge(quota) {
  if (!quota || quota === 0 || quota <= 200) return 0;
  return Math.ceil((quota - 200) / 100) * 1000;
}

function getStepHint(step, role) {
  const ipHint = role === 'admin'
    ? 'bebas, tanpa biaya tambahan'
    : role === 'reseller'
      ? `default ${DEFAULT_IP}  (3 gratis, lebih: +Rp 500/IP)`
      : `default ${DEFAULT_IP}  (1 gratis, lebih: +Rp 500/IP)`;
  return {
    days:    `contoh: 30`,
    limitip: ipHint,
    quota:   `dalam GB, default ${DEFAULT_QUOTA}  (0 = unlimited)`
  }[step] || '';
}

/* Bersihkan noise dari output SSH */
function cleanOutput(raw) {
  return (raw || '')
    .split('\n')
    .filter(l => {
      const t = l.trim();
      if (!t) return false;
      if (/TERM environment/i.test(t)) return false;
      if (/tput:/i.test(t))            return false;
      if (/setlocale/i.test(t))        return false;
      if (/cannot change locale/i.test(t)) return false;
      if (/^bash:.*warning:/i.test(t)) return false;
      return true;
    })
    .join('\n')
    .trim();
}

function buildCard(account, step, data, role, totalEstimate) {
  const cfg         = SCRIPT_MAP[account.product_type] || {};
  const pricePerDay = getPrice(role, cfg.priceKey || 'ssh', account.server_ip, account.limit_ip || account.limitIp);
  const label       = TYPE_LABEL[account.product_type] || account.product_type;

  let filled = '';
  if (data.days    !== undefined) filled += `\n│  📅 Hari     : ${data.days} hari`;
  if (data.limitIp !== undefined) filled += `\n│  🔢 Limit IP : ${data.limitIp}`;
  if (data.quota   !== undefined) {
    const qLabel = data.quota === 0 ? 'Unlimited' : `${data.quota} GB`;
    filled += `\n│  💾 Quota    : ${qLabel}`;
  }

  const promptLine  = step ? `\n│\n│  ▶ ${step === 'days' ? '📅 Berapa hari extend?' : step === 'limitip' ? '🔢 Limit IP baru?' : '💾 Quota baru (GB)?'}\n│    ${getStepHint(step, role)}` : '';
  const priceLine   = role === 'admin'
    ? `\n│  💰 Harga    : GRATIS (Admin)`
    : totalEstimate !== undefined
      ? `\n│  🧮 Total    : ${formatRp(totalEstimate)}`
      : `\n│  💰 Harga    : ${formatRp(pricePerDay)}/hari`;

  return (
    `┌─────────────────────┐\n` +
    `│  🔄 EXTEND ACCOUNT\n` +
    `│  ${label}\n` +
    `│  🆔 Username : ${account.username}\n` +
    `│  🖥 Server   : ${account.server_ip || '-'}\n` +
    `│  👑 Role     : ${role.toUpperCase()}` +
    priceLine +
    filled +
    promptLine +
    `\n└─────────────────────┘`
  );
}

function buildConfirmCard(account, data, role, totalHarga, pricePerDay, extraIPCharge, extraQuotaCharge, saldo) {
  const label = TYPE_LABEL[account.product_type] || account.product_type;

  const salLabel = role === 'admin'
    ? `👑 Admin — Extend GRATIS!`
    : saldo >= totalHarga
      ? `✅ Saldo cukup`
      : `⚠️ Kurang ${formatRp(totalHarga - saldo)} → bayar via QRIS`;

  let hargaDetail = '';
  if (role === 'admin') {
    hargaDetail = `│  💰 TOTAL      : GRATIS (Admin)\n`;
  } else {
    hargaDetail = `│  💰 ${formatRp(pricePerDay)}/hari × ${data.days} hari\n`;
    if (extraIPCharge > 0)    hargaDetail += `│  ➕ Extra IP    : +${formatRp(extraIPCharge)}\n`;
    if (extraQuotaCharge > 0) hargaDetail += `│  ➕ Extra Quota : +${formatRp(extraQuotaCharge)}\n`;
    hargaDetail += `│  🧮 TOTAL      : ${formatRp(totalHarga)}\n`;
  }

  let detail = `│  📅 Extend     : ${data.days} hari\n`;
  detail += `│  🔢 Limit IP   : ${data.limitIp}\n`;
  if (data.quota !== undefined) detail += `│  💾 Quota      : ${data.quota === 0 ? 'Unlimited' : data.quota + ' GB'}\n`;

  return (
    `┌────────────────┐\n` +
    `│   🀄 KONFIRMASI EXTEND 🀄\n` +
    `├────────────────┤\n` +
    `│  Protocol : ${label}\n` +
    `│  Username : ${account.username}\n` +
    `│  Server   : ${account.server_ip || '-'}\n` +
    `│  Role     : ${role.toUpperCase()}\n` +
    `├────────────────┤\n` +
    detail +
    `├────────────────┤\n` +
    hargaDetail +
    `│  ${salLabel}\n` +
    `└────────────────┘\n\n` +
    `Lanjutkan extend akun ini?`
  );
}

async function showAccountList(bot, chatId, msgId, userStates) {
  await bot.editMessageText('⏳ <i>Memuat daftar akun...</i>', {
    chat_id: chatId, message_id: msgId, parse_mode: 'HTML'
  }).catch(() => {});

  db.all(
    "SELECT order_id, product_type, username, expired_at, server_ip FROM transactions WHERE chat_id=? AND status='completed' AND product_type NOT IN ('', 'TOPUP') AND product_type NOT LIKE 'TRIAL%' ORDER BY expired_at DESC LIMIT 10",
    [chatId],
    async (err, rows) => {
      if (!rows?.length) {
        return bot.editMessageText('❌ Tidak ada akun aktif.\n\nBeli dulu di menu Orders Account.', {
          chat_id: chatId, message_id: msgId,
          reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
        }).catch(() => {});
      }

      let text = `┌─────────────────┐\n│  🔄 PILIH AKUN EXTEND\n└─────────────────┘\n\n`;
      rows.forEach((r, i) => {
        const expStr   = r.expired_at ? r.expired_at.slice(0, 10) : '-';
        const now      = new Date();
        const exp      = new Date(r.expired_at);
        const sisaHari = exp > now ? Math.ceil((exp - now) / 86400000) : 0;
        const status   = sisaHari > 0 ? `✅ ${sisaHari}hr` : '❌ Expired';
        const label    = TYPE_LABEL[r.product_type] || r.product_type;
        text += `${i + 1}. ${label}\n   👤 ${r.username || '-'}  📅 ${expStr}  ${status}\n\n`;
      });
      text += `Ketik nomor akun yang mau di-extend (1-${rows.length}):`;

      userStates.set(chatId, { state: 'renew_pick', accounts: rows, listMsgId: msgId });

      bot.editMessageText(text, {
        chat_id: chatId, message_id: msgId,
        reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_back' }]] }
      }).catch(() => {});
    }
  );
}

async function initRenew(bot, chatId, userStates, account, listMsgId) {
  db.get('SELECT saldo, role FROM users WHERE chat_id=?', [chatId], async (err, row) => {
    if (!row) return bot.sendMessage(chatId, '❌ User tidak ditemukan. Ketik /start');

    const role  = row.role  || 'members';
    const saldo = Number(row.saldo) || 0;
    const cfg   = SCRIPT_MAP[account.product_type];

    if (!cfg) return bot.sendMessage(chatId, `❌ Tipe akun ${account.product_type} tidak dikenali.`);
    if (listMsgId) bot.deleteMessage(chatId, listMsgId).catch(() => {});

    const steps     = cfg.isXray ? ['days', 'limitip', 'quota'] : ['days', 'limitip'];
    const firstStep = steps[0];
    const text      = buildCard(account, firstStep, {}, role);
    const msg       = await bot.sendMessage(chatId, text).catch(() => null);
    if (!msg) return;

    userStates.set(chatId, {
      state: 'renew_flow',
      account, role, saldo,
      data: {}, steps,
      stepIndex: 0,
      msgId: msg.message_id
    });
  });
}

async function handleStep(bot, chatId, text, userStates) {
  const st = userStates.get(chatId);
  if (!st || st.state !== 'renew_flow') return;

  /* INSTANT FEEDBACK */
  const loadEmoji = st.stepIndex % 2 === 0 ? '⌛' : '⏳';
  await bot.editMessageText(`${loadEmoji} <i>Memproses input...</i>`, {
    chat_id: chatId, message_id: st.msgId, parse_mode: 'HTML'
  }).catch(() => {});

  const currentStep = st.steps[st.stepIndex];
  let errMsg = null;

  if (currentStep === 'days') {
    const n = parseInt(text);
    if (isNaN(n) || n < 1) errMsg = '⚠️ Masukkan jumlah hari yang valid. Contoh: 30';
    else st.data.days = n;
  } else if (currentStep === 'limitip') {
    const raw = (text || '').trim();
    if (raw === '' || raw === '0') {
      st.data.limitIp = DEFAULT_IP;
    } else {
      const n = parseInt(raw);
      if (isNaN(n) || n < 1) errMsg = `⚠️ Minimal 1. Ketik 0 untuk default (${DEFAULT_IP}).`;
      else st.data.limitIp = n;
    }
  } else if (currentStep === 'quota') {
    const raw = (text || '').trim();
    if (raw === '') {
      st.data.quota = DEFAULT_QUOTA;
    } else {
      const n = parseInt(raw);
      if (isNaN(n) || n < 0) errMsg = `⚠️ Masukkan angka. 0 = unlimited.`;
      else st.data.quota = n;
    }
  }

  if (errMsg) {
    return bot.editMessageText(
      buildCard(st.account, currentStep, st.data, st.role) + `\n\n${errMsg}`,
      { chat_id: chatId, message_id: st.msgId }
    ).catch(() => {});
  }

  st.stepIndex++;
  userStates.set(chatId, st);

  if (st.stepIndex < st.steps.length) {
    return bot.editMessageText(
      buildCard(st.account, st.steps[st.stepIndex], st.data, st.role),
      { chat_id: chatId, message_id: st.msgId }
    ).catch(() => {});
  }

  await showConfirmRenew(bot, chatId, userStates, st);
}

async function showConfirmRenew(bot, chatId, userStates, st) {
  const cfg              = SCRIPT_MAP[st.account.product_type];
  const pricePerDay      = getPrice(st.role, cfg.priceKey, st.account.server_ip, st.account.limit_ip || st.account.limitIp || st.data?.limitIp);
  const limitIp          = st.data.limitIp ?? DEFAULT_IP;
  const quota            = st.data.quota   ?? DEFAULT_QUOTA;
  const extraIPCharge    = calcExtraIP(st.role, limitIp);
  let   extraQuotaCharge = 0;

  if (cfg.isXray && quota > 200) {
    extraQuotaCharge = quotaSurcharge(quota);
  }

  const totalHarga = st.role === 'admin'
    ? 0
    : pricePerDay * st.data.days + extraIPCharge + extraQuotaCharge;

  const confirmText = buildConfirmCard(
    st.account, { ...st.data, limitIp, quota }, st.role, totalHarga,
    pricePerDay, extraIPCharge, extraQuotaCharge, st.saldo
  );

  st.state             = 'renew_confirm';
  st.totalHarga        = totalHarga;
  st.pricePerDay       = pricePerDay;
  st.extraIPCharge     = extraIPCharge;
  st.extraQuotaCharge  = extraQuotaCharge;
  st.data.limitIp      = limitIp;
  st.data.quota        = quota;
  userStates.set(chatId, st);

  const opts = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Konfirmasi', callback_data: 'confirm_renew' },
          { text: '❌ Batal',      callback_data: 'cancel_renew'  }
        ]
      ]
    }
  };

  bot.editMessageText(confirmText, { chat_id: chatId, message_id: st.msgId, ...opts })
    .catch(() => bot.sendMessage(chatId, confirmText, opts));
}

async function executeRenew(bot, chatId, userStates, st) {
  userStates.delete(chatId);

  const cfg        = SCRIPT_MAP[st.account.product_type];
  const totalHarga = st.totalHarga;

  /* Admin atau saldo cukup → langsung extend */
  if (st.role === 'admin' || st.saldo >= totalHarga) {
    doRenewAccount(bot, chatId, st, cfg, totalHarga, st.pricePerDay, st.msgId);
  } else {
    bot.editMessageText('⌛ Saldo kurang, membuat QRIS...', { chat_id: chatId, message_id: st.msgId }).catch(() => {});
    await generateQRIS(bot, chatId, totalHarga, {
      productName:  `EXTEND ${cfg.scriptName}`,
      productType:  `RENEW ${st.account.product_type}`,
      accountRenew: {
        account: st.account, data: st.data,
        scriptName: cfg.scriptName, label: TYPE_LABEL[st.account.product_type] || st.account.product_type,
        totalHarga, pricePerDay: st.pricePerDay
      }
    });
  }
}

/* ─────────────── PROGRESS ANIMATION ─────────────── */
function buildProgress(pct, label) {
  const total  = 10;
  const filled = Math.round(pct / 10);
  const bar    = '▰'.repeat(filled) + '▱'.repeat(total - filled);
  return `${label}\n<code>${bar}</code>  <b>${pct}%</b>`;
}

async function doRenewAccount(bot, chatId, st, cfg, totalHarga, pricePerDay, msgId) {
  await bot.editMessageText(
    buildProgress(0, '⏳ <b>Menghubungkan ke server...</b>'),
    { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
  ).catch(() => {});

  let animStep = 1;
  const FRAMES = [
    { pct: 30, label: `🔄 <b>Memperpanjang ${st.account.username}...</b>` },
    { pct: 60, label: '⚙️ <b>Memperbarui konfigurasi...</b>'              },
    { pct: 70, label: '📝 <b>Menyimpan perubahan...</b>'                  }
  ];

  const animInterval = setInterval(() => {
    if (animStep - 1 < FRAMES.length) {
      const f = FRAMES[animStep - 1];
      bot.editMessageText(buildProgress(f.pct, f.label), {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML'
      }).catch(() => {});
      animStep++;
    }
  }, 2500);

  const limitIp = st.data.limitIp ?? DEFAULT_IP;
  const quota   = st.data.quota   ?? DEFAULT_QUOTA;
  let args = [];

  if (st.account.product_type === 'SSH') {
    args = [st.account.username, st.data.days, limitIp];
  } else if (['VMESS', 'VLESS', 'TROJAN'].includes(st.account.product_type)) {
    args = [st.account.username, st.data.days, quota, limitIp];
  } else if (st.account.product_type === 'ZIVPN') {
    args = [st.account.username, st.data.days, limitIp];
  }

  executeScriptRemote(st.account.server_ip, cfg.scriptName, args, (err, rawOutput) => {
    clearInterval(animInterval);
    const output = cleanOutput(rawOutput);

    if (err) {
      console.error('[doRenewAccount] ❌', err.message);
      const friendly = friendlyError(err.message) || err.message;
      return bot.editMessageText(
        `❌ <b>Gagal extend akun</b>\n\n${friendly}\n\nSaldo tidak terpotong.`,
        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
      ).catch(() => bot.sendMessage(chatId, '❌ Gagal extend: ' + friendly));
    }

    if (hasErrorCode(output)) {
      const friendly = friendlyError(output) || output || 'Output script kosong';
      const errText = `❌ <b>EXTEND GAGAL</b>\n\n${friendly}\n\nSaldo tidak terpotong. Hubungi admin.`;
      if (msgId) bot.editMessageText(errText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }).catch(() => bot.sendMessage(chatId, errText, { parse_mode: 'HTML' }));
      else bot.sendMessage(chatId, errText, { parse_mode: 'HTML' });
      return;
    }

    const hasRenewResult = /RENEW_RESULT_START[\s\S]*RENEW_RESULT_END/.test(output || '');

    if (cfg.isXray && !hasRenewResult) {
      const friendly = friendlyError(output) || output || 'Output script kosong';
      const errText = `❌ <b>EXTEND GAGAL</b>\n\n${friendly}\n\nSaldo tidak terpotong. Hubungi admin.`;
      if (msgId) bot.editMessageText(errText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }).catch(() => bot.sendMessage(chatId, errText, { parse_mode: 'HTML' }));
      else bot.sendMessage(chatId, errText, { parse_mode: 'HTML' });
      return;
    }

    if (totalHarga > 0) {
      db.run('UPDATE users SET saldo = saldo - ? WHERE chat_id=?', [totalHarga, chatId]);
    }

    const renewData = {};
    if (hasRenewResult) {
      const renewBlock = (output || '').match(/RENEW_RESULT_START([\s\S]*?)RENEW_RESULT_END/);
      if (renewBlock) {
        renewBlock[1].trim().split('\n').forEach(line => {
          const idx = line.indexOf(':');
          if (idx > 0) renewData[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
        });
      }
    }

    const expiredAt = new Date(Date.now() + st.data.days * 86400000)
      .toISOString().slice(0, 19).replace('T', ' ');
    const label = TYPE_LABEL[st.account.product_type] || st.account.product_type;

    db.run(
      "INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type, username, expired_at, server_ip) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), ?, ?, ?, ?)",
      [chatId, `RENEW-${st.account.product_type}-${Date.now()}`, totalHarga,
       `RENEW ${st.account.product_type}`, st.account.username, expiredAt, st.account.server_ip]
    );

    const renewExpired = renewData.EXPIRED || '-';
    const renewQuota   = renewData.QUOTA   || '-';
    const renewIpLimit = renewData.IP_LIMIT || '-';

    let detailText;
    if (hasRenewResult) {
      detailText =
        `✅ <b>EXTEND ${label} BERHASIL!</b>\n\n` +
        `🆔 Username  : ${st.account.username}\n` +
        `📅 Extend    : ${st.data.days} hari\n` +
        `📆 Expired   : ${renewExpired}\n` +
        `📦 Quota     : ${renewQuota} GB\n` +
        `📱 Limit IP  : ${renewIpLimit}\n` +
        (st.role !== 'admin' ? `🧮 Total     : ${formatRp(totalHarga)}\n` : `👑 Gratis (Admin)\n`);
    } else {
      detailText =
        `✅ <b>EXTEND ${label} BERHASIL!</b>\n\n` +
        (output ? `<pre>${output}</pre>\n\n` : '') +
        `🆔 Username : ${st.account.username}\n` +
        `📅 Extend   : ${st.data.days} hari\n` +
        (st.role !== 'admin' ? `🧮 Total    : ${formatRp(totalHarga)}\n` : `👑 Gratis (Admin)\n`);
    }

    bot.editMessageText(
      buildProgress(100, `✅ <b>EXTEND ${label} BERHASIL!</b>`),
      { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
    ).catch(() => {}).finally(() => {
      setTimeout(() => {
        bot.editMessageText(detailText, {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] }
        }).catch(() => bot.sendMessage(chatId, detailText, {
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] }
        }));

        autoMenu(bot, chatId, 1500);
      }, 800);
    });
  });
}

module.exports = { initRenew, handleStep, showConfirmRenew, executeRenew, showAccountList };

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const harga=parseInt(args[1])
    if(!global.db.pricing) global.db.pricing={member:0,seller:0}
    if(tipe==='member') global.db.pricing.member=harga
    if(tipe==='seller') global.db.pricing.seller=harga
    reply(`✅ Harga ${tipe} telah diatur menjadi Rp${harga}`)
}
break
