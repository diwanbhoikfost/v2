// cmd/cekstatus.js - Optimized v2.0
'use strict';

const db = require('../data/db');

module.exports = function cekstatusCmd(bot, chatId, msgId) {
  bot.editMessageText('⏳ <i>Mengecek status akun...</i>', {
    chat_id: chatId, message_id: msgId, parse_mode: 'HTML'
  }).catch(() => {});

  const LABEL = {
    SSH: '⚪ SSH / OpenVPN', VMESS: '🔵 xRay VMess',
    VLESS: '🟡 xRay VLess', TROJAN: '🟠 xRay Trojan', ZIVPN: '🟢 UDP ZivPN'
  };

  db.all(
    "SELECT product_type, username, expired_at, server_ip FROM transactions WHERE chat_id=? AND status='completed' AND product_type NOT IN ('', 'TOPUP') ORDER BY expired_at DESC LIMIT 10",
    [chatId],
    (err, rows) => {
      if (err) {
        console.error('[cekstatusCmd] ❌', err.message);
        return bot.editMessageText('❌ Gagal cek status.', {
          chat_id: chatId, message_id: msgId,
          reply_markup: { inline_keyboard: [[{ text: '🔃 Kembali', callback_data: 'menu_back' }]] }
        }).catch(() => {});
      }

      let text = `┌─────────────────┐\n│  📋 STATUS AKUN\n└─────────────────┘\n\n`;

      if (!rows?.length) {
        text += '📭 Belum ada akun.\n\nBeli sekarang di menu Orders Account!';
      } else {
        const now = new Date();
        rows.forEach((r, i) => {
          const exp        = r.expired_at ? new Date(r.expired_at) : null;
          const sisaHari   = exp && exp > now ? Math.ceil((exp - now) / 86400000) : 0;
          const expStr     = r.expired_at ? r.expired_at.slice(0, 16) : '-';
          const statusIcon = sisaHari > 3 ? '🟢' : sisaHari > 0 ? '🟡' : '🔴';
          const label      = LABEL[r.product_type] || r.product_type;

          text +=
            `${i + 1}. ${statusIcon} <b>${label}</b>\n` +
            `   👤 ${r.username || '-'}\n` +
            `   📅 Expired: ${expStr}\n` +
            `   ⏱ Sisa: ${sisaHari > 0 ? sisaHari + ' hari' : '<b>EXPIRED</b>'}\n\n`;
        });
      }

      bot.editMessageText(text, {
        chat_id: chatId, message_id: msgId, parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔄 Extend Akun', callback_data: 'renew_menu'   }],
            [{ text: '🔃 Kembali',     callback_data: 'menu_back'    }]
          ]
        }
      }).catch(() => {});
    }
  );
};

case 'perpanjang': {
    if (!isAdmin && !isMember) return reply('Kamu belum terdaftar.')
    const targetUser = args[0]
    const tambahHari = parseInt(args[1]) || 1
    const akun = global.db.users[targetUser]
    if (!akun) return reply('Akun tidak ditemukan.')
    const now = new Date()
    const expiredDate = new Date(akun.expired || now)
    expiredDate.setDate(expiredDate.getDate() + tambahHari)
    akun.expired = expiredDate.toISOString()
    reply(`✅ Akun ${akun.username || targetUser} telah berhasil diperpanjang ${tambahHari} hari.  
🗓 Expired baru: ${expiredDate.toLocaleDateString('id-ID')}`)
}
break

case 'topproduk': {
    if (!isAdmin) return reply('Khusus admin.')
    const produk = Object.entries(global.db.products || {}).sort((a,b)=>b[1].sold-a[1].sold).slice(0,5)
    let teks='📈 Top Produk Terlaris\n\n'
    produk.forEach(([nama,data],i)=>{teks+=`${i+1}. ${nama} - Terjual: ${data.sold}\n`})
    reply(teks)
}
break

function checkMultiLogin(userId, ip){
    const akun = global.db.users[userId]
    if(!akun) return false
    if(!akun.ipList) akun.ipList=[]
    if(!akun.ipList.includes(ip)) akun.ipList.push(ip)
    if(akun.ipList.length>1){
        bot.sendMessage(userId, `⚠️ Multi Login terdeteksi. Akun kamu sedang digunakan di beberapa IP: ${akun.ipList.join(', ')}`)
        return true
    }
    return false
}

case 'addserver': {
    if(!isAdmin) return reply('Khusus admin.')
    const serverId=args[0]
    const slotInput=parseInt(args[1])||0
    if(!global.db.servers) global.db.servers={}
    if(!global.db.servers[serverId]) global.db.servers[serverId]={slot:0,users:[]}
    const server=global.db.servers[serverId]
    const currentUsers=Object.values(global.db.users||{}).filter(u=>u.server===serverId)
    server.slot=Math.max(slotInput,currentUsers.length)
    server.users=currentUsers.map(u=>u.username)
    reply(`✅ Server ${serverId} berhasil ditambahkan dengan slot: ${server.slot}\nJumlah user yang sudah ada: ${currentUsers.length}`)
}
break

case 'seller': {
    const userId = msg.from.id
    const user = global.db.users[userId]
    if(!user) return reply('User tidak ditemukan.')
    if(user.saldo>=30000 && !user.isSeller){
        user.isSeller=true
        reply('🎉 Selamat! Kamu kini menjadi Seller Diwan Tunneling')
    }
    let teks='📋 Menu Seller\n'
    teks+='💰 Buat akun dengan harga seller\n'
    teks+='🆓 Free IP 1-4\n'
    teks+='🎁 Trial tanpa batas\n'
    teks+='📊 Statistik penjualan\n'
    reply(teks)
}
break

case 'cekserver': {
    const serverId=args[0]
    const server = global.db.servers[serverId]
    if(!server) return reply('Server tidak ditemukan')
    reply(`📡 Status Server: ${serverId}
🟢 Online
⏱ Ping: ${server.ping||'--'} ms
💾 RAM: ${server.ram||'--'}
⚡ CPU: ${server.cpu||'--'}
📶 Bandwidth: ${server.bandwidth||'--'}`)
}
break

case 'setharga': {
    if(!isAdmin) return reply('Khusus admin.')
    const tipe=args[0] // member / seller
    const harga=parseInt(args[1])
    if(!global.db.pricing) global.db.pricing={member:0,seller:0}
    if(tipe==='member') global.db.pricing.member=harga
    if(tipe==='seller') global.db.pricing.seller=harga
    reply(`✅ Harga ${tipe} telah diatur menjadi Rp${harga}`)
}
break
